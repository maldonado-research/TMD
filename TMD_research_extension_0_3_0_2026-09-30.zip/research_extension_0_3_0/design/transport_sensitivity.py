#!/usr/bin/env python3
"""Planning and partial identification for independent four-arm route counts.

Standard interval arithmetic and multinomial delta method, not novel theorems.
Route order Wsp, Aws, Mws. No measured data or biological evidence is supplied.
"""
from __future__ import annotations
import json
import math
from numbers import Real
from pathlib import Path
from statistics import NormalDist

V = (-0.5, 1.0, -0.5)
ARMS = ('baseline', 'selected', 'baseline_control', 'selected_control')


def vector(values, name='vector'):
    if len(values) != 3 or any(isinstance(x, bool) or not isinstance(x, Real) for x in values):
        raise ValueError(f'{name} needs three finite numeric values')
    values = tuple(float(x) for x in values)
    if not all(math.isfinite(x) for x in values):
        raise ValueError(f'{name} must be finite')
    return values


def probability(values):
    values = vector(values, 'probability')
    if any(x <= 0 for x in values) or not math.isclose(sum(values), 1., abs_tol=1e-10, rel_tol=0):
        raise ValueError('Strictly positive probabilities summing to one required')
    return values


def corrected_contrast(arms, r0, r1):
    if len(arms) != 4:
        raise ValueError('Four arms required')
    b, t, a0, a1 = [probability(p) for p in arms]
    r0, r1 = probability(r0), probability(r1)
    return sum(w*(math.log(ti)-math.log(bi)-math.log(a1i)+math.log(r1i)
                  +math.log(a0i)-math.log(r0i))
               for w, bi, ti, a0i, a1i, r0i, r1i in zip(V, b, t, a0, a1, r0, r1))


def transport_bias_bounds(lower, upper):
    """Sharp box bounds on v dot rho, absent additional joint restrictions."""
    lower, upper = vector(lower, 'lower bounds'), vector(upper, 'upper bounds')
    if any(a > b for a, b in zip(lower, upper)):
        raise ValueError('Each lower bound must be no greater than its upper bound')
    low = sum(w*(a if w >= 0 else b) for w, a, b in zip(V, lower, upper))
    high = sum(w*(b if w >= 0 else a) for w, a, b in zip(V, lower, upper))
    return low, high


def biological_theta_interval(corrected_theta, lower=None, upper=None):
    """theta_corrected = theta_biological + bias; unknown transport is unbounded."""
    if isinstance(corrected_theta, bool) or not isinstance(corrected_theta, Real) or not math.isfinite(float(corrected_theta)):
        raise ValueError('Finite corrected theta required')
    if lower is None and upper is None:
        return {'status': 'unidentified_transport', 'interval': [None, None],
                'interpretation': 'No finite biological theta bounds without transport restrictions'}
    if lower is None or upper is None:
        raise ValueError('Supply both lower and upper transport bounds, or neither')
    low, high = transport_bias_bounds(lower, upper)
    return {'status': 'bounded_given_assumptions', 'bias_interval': [low, high],
            'interval': [float(corrected_theta)-high, float(corrected_theta)-low],
            'interpretation': 'Population-level structural bounds, not a confidence interval'}


def common_theta_compatibility(intervals):
    if not intervals:
        raise ValueError('At least one finite interval required')
    for interval in intervals:
        if len(interval) != 2 or any(isinstance(x, bool) or not isinstance(x, Real) or not math.isfinite(float(x)) for x in interval):
            raise ValueError('Finite interval endpoints required')
        if interval[0] > interval[1]:
            raise ValueError('Invalid interval order')
    low, high = max(float(x[0]) for x in intervals), min(float(x[1]) for x in intervals)
    return {'compatible': low <= high, 'intersection': [low, high] if low <= high else None,
            'interpretation': 'Compatibility under supplied bounds; not confirmation of a shared mechanism'}


def variance_coefficient(p):
    p = probability(p)
    return sum(w*w/pi for w, pi in zip(V, p))


def four_arm_variance(arms, totals):
    if len(arms) != 4 or len(totals) != 4:
        raise ValueError('Four arms and totals required')
    if any(isinstance(n, bool) or not isinstance(n, Real) or not math.isfinite(float(n)) or n <= 0 for n in totals):
        raise ValueError('Positive finite totals required')
    components = [variance_coefficient(p)/n for p, n in zip(arms, totals)]
    return {'variance': sum(components), 'standard_error': math.sqrt(sum(components)),
            'components': dict(zip(ARMS, components)),
            'assumption': 'Independent multinomial samples; known input compositions'}


def optimal_allocation(arms, budget, costs=(1., 1., 1., 1.)):
    """Continuous optimum of sum A_g/n_g with sum c_g*n_g=budget."""
    if len(arms) != 4 or len(costs) != 4:
        raise ValueError('Four arms and costs required')
    if isinstance(budget, bool) or not isinstance(budget, Real) or not math.isfinite(float(budget)) or budget <= 0:
        raise ValueError('Positive finite budget required')
    if any(isinstance(c, bool) or not isinstance(c, Real) or not math.isfinite(float(c)) or c <= 0 for c in costs):
        raise ValueError('Positive finite costs required')
    coefficients = [variance_coefficient(p) for p in arms]
    denom = sum(math.sqrt(a*c) for a, c in zip(coefficients, costs))
    allocation = [budget*math.sqrt(a/c)/denom for a, c in zip(coefficients, costs)]
    return {'continuous_totals': dict(zip(ARMS, allocation)), 'budget': float(budget),
            'costs': list(costs), 'minimum_delta_variance': denom*denom/budget,
            'interpretation': 'Planning only: round with budget checks; measure actual costs/yields and validate independence'}


def simultaneous_sensitive_intervals(contexts, alpha=0.05, independent_arms=False):
    """Positive-count asymptotic Bonferroni intervals widened by transport bounds.

    Each context: counts (four triads), known r0/r1, lower/upper transport bounds.
    Output has approximate regular-model coverage only, never exact coverage.
    Bonferroni across contexts does not itself require independence across contexts.
    """
    if independent_arms is not True:
        raise ValueError('Explicit independent_arms=True declaration required')
    if not contexts or isinstance(alpha, bool) or not isinstance(alpha, Real) or not 0 < alpha < 1:
        raise ValueError('Contexts and alpha between zero and one required')
    critical = NormalDist().inv_cdf(1-alpha/(2*len(contexts)))
    output = []
    for context in contexts:
        counts = context['counts']
        if len(counts) != 4:
            raise ValueError('Four count arms required')
        for arm in counts:
            arm = vector(arm, 'counts')
            if any(x <= 0 or x != math.floor(x) or x > 2**52 for x in arm) or sum(arm) > 2**52:
                raise ValueError('Positive exactly representable integer counts required; zero cells unsupported')
        totals = [sum(arm) for arm in counts]
        probs = [[x/n for x in arm] for arm, n in zip(counts, totals)]
        theta = corrected_contrast(probs, context['r0'], context['r1'])
        variance = four_arm_variance(probs, totals)
        radius = critical*variance['standard_error']
        low, high = transport_bias_bounds(context['lower'], context['upper'])
        output.append({'corrected_theta': theta, 'standard_error_regular': variance['standard_error'],
                       'sampling_interval_regular': [theta-radius, theta+radius],
                       'biological_theta_interval_regular_and_sensitive': [theta-radius-high, theta+radius-low],
                       'transport_bias_interval': [low, high]})
    intersection = common_theta_compatibility([r['biological_theta_interval_regular_and_sensitive'] for r in output])
    return {'alpha': alpha, 'critical_value': critical, 'contexts': output, 'compatibility': intersection,
            'interpretation': 'Asymptotic Bonferroni construction widened by assumed transport bounds. '
              'Sparse probabilities, dependence, unknown input compositions or transport outside bounds can invalidate coverage. '
              'Intersection is a compatibility screen, not the joint likelihood test or biological validation.'}


def demonstration():
    p = (1/3, 1/3, 1/3)
    full = four_arm_variance([p]*4, [100]*4)
    bias = transport_bias_bounds([-.1]*3, [.1]*3)
    return {'provenance': 'analytic_planning_examples_not_measurements',
            'uniform_four_arms_100_each': full,
            'incorrectly_treating_controls_as_known_standard_error': math.sqrt(.09),
            'four_arm_standard_error_increase_ratio': full['standard_error']/math.sqrt(.09),
            'symmetric_route_transport_log_bound_0_1': {'bias_interval': list(bias),
                                                       'largest_abs_cross_context_difference_absorbable': 0.4},
            'equal_cost_budget_400': optimal_allocation([p]*4, 400),
            'unequal_cost_budget_400': optimal_allocation([p]*4, 400, [1, 1, 2, 2]),
            'unbounded_transport': biological_theta_interval(.4),
            'two_population_contrasts_0_4_and_minus_0_293147_with_epsilon_0_1':
                common_theta_compatibility([biological_theta_interval(t,[-.1]*3,[.1]*3)['interval']
                                            for t in [.4, .4-math.log(2)]]),
            'externally_novel_math_claimed': False, 'biological_validation': False}


if __name__ == '__main__':
    result = demonstration()
    (Path(__file__).parent/'transport_sensitivity_results.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
