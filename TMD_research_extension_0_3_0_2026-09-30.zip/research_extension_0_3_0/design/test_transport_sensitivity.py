import itertools
import math
import random
import unittest
from transport_sensitivity import (V, probability, transport_bias_bounds, biological_theta_interval,
    common_theta_compatibility, four_arm_variance, optimal_allocation,
    corrected_contrast, simultaneous_sensitive_intervals)


class SensitivityTests(unittest.TestCase):
    def test_box_extrema_match_all_corners_including_negative_weights(self):
        rng = random.Random(418)
        for _ in range(25):
            lower = [rng.uniform(-2, 0) for _ in range(3)]
            upper = [rng.uniform(0, 3) for _ in range(3)]
            corners = [sum(w*x for w, x in zip(V, point)) for point in itertools.product(*zip(lower, upper))]
            bound = transport_bias_bounds(lower, upper)
            self.assertAlmostEqual(bound[0], min(corners))
            self.assertAlmostEqual(bound[1], max(corners))

    def test_signed_interval_and_scale_cancellation(self):
        interval = biological_theta_interval(.4, [0, 0, 0], [0, 1, 0])
        self.assertEqual(interval['interval'], [-.6, .4])
        self.assertAlmostEqual(transport_bias_bounds([.7]*3, [.7]*3)[0], 0)

    def test_unknown_transport_has_no_finite_identification(self):
        result = biological_theta_interval(.4)
        self.assertEqual(result['status'], 'unidentified_transport')
        self.assertEqual(result['interval'], [None, None])

    def test_common_intersection_is_structural(self):
        self.assertEqual(common_theta_compatibility([[0, 2], [1, 3]])['intersection'], [1, 2])
        self.assertFalse(common_theta_compatibility([[0, 1], [2, 3]])['compatible'])
        self.assertTrue(common_theta_compatibility([[0, 1], [1, 3]])['compatible'])

    def test_all_control_uncertainty_counts(self):
        p = [1/3]*3
        full = four_arm_variance([p]*4, [100]*4)
        self.assertAlmostEqual(full['variance'], .18)
        self.assertAlmostEqual(full['standard_error'], math.sqrt(.18))
        self.assertAlmostEqual(full['standard_error']/math.sqrt(.09), math.sqrt(2))

    def test_cost_allocation_satisfies_budget_and_stationarity(self):
        arms = [[.1, .7, .2], [.2, .3, .5], [.4, .1, .5], [.3, .6, .1]]
        costs = [1, 4, 2, .5]
        result = optimal_allocation(arms, 900, costs)
        totals = list(result['continuous_totals'].values())
        self.assertAlmostEqual(sum(n*c for n, c in zip(totals, costs)), 900)
        coefficients = [sum(w*w/pi for w, pi in zip(V, p)) for p in arms]
        multipliers = [a/(n*n*c) for a, n, c in zip(coefficients, totals, costs)]
        self.assertLess(max(multipliers)-min(multipliers), 1e-12)
        actual = sum(a/n for a, n in zip(coefficients, totals))
        self.assertAlmostEqual(actual, result['minimum_delta_variance'])
        changed = totals.copy()
        changed[0] += 10
        changed[1] -= 10*costs[0]/costs[1]
        self.assertGreater(sum(a/n for a, n in zip(coefficients, changed)), actual)

    def test_known_compositions_recover_contrast_independently(self):
        q, p = [.2, .5, .3], [.4, .5, .1]
        r0, r1 = [.1, .2, .7], [.5, .2, .3]
        d0, d1 = [.4, .8, .2], [.7, .3, .5]
        def measured(composition, recovery):
            raw = [x*d for x, d in zip(composition, recovery)]
            return [x/sum(raw) for x in raw]
        arms = [measured(q, d0), measured(p, d1), measured(r0, d0), measured(r1, d1)]
        expected = sum(w*math.log(pi/qi) for w, pi, qi in zip(V, p, q))
        self.assertAlmostEqual(corrected_contrast(arms, r0, r1), expected)

    def test_sensitive_intervals_include_sampling_and_box_uncertainty(self):
        context = {'counts': [[100]*3]*4, 'r0': [1/3]*3, 'r1': [1/3]*3,
                   'lower': [-.1]*3, 'upper': [.1]*3}
        result = simultaneous_sensitive_intervals([context]*2, independent_arms=True)
        row = result['contexts'][0]
        self.assertAlmostEqual(row['corrected_theta'], 0)
        self.assertAlmostEqual(row['biological_theta_interval_regular_and_sensitive'][1],
                               row['sampling_interval_regular'][1]+.2)
        self.assertGreater(result['critical_value'], 1.96)
        self.assertTrue(result['compatibility']['compatible'])

    def test_invalid_and_zero_inputs_declined(self):
        with self.assertRaises(ValueError):
            transport_bias_bounds([0]*3, [-1]*3)
        with self.assertRaises(ValueError):
            probability([0, .5, .5])
        with self.assertRaises(ValueError):
            optimal_allocation([[1/3]*3]*4, -1)
        context = {'counts': [[0, 2, 3]]*4, 'r0': [1/3]*3, 'r1': [1/3]*3,
                   'lower': [0]*3, 'upper': [0]*3}
        with self.assertRaises(ValueError):
            simultaneous_sensitive_intervals([context], independent_arms=True)
        with self.assertRaises(ValueError):
            simultaneous_sensitive_intervals([context])
        string_context = dict(context, counts=[['1', '2', '3']]*4)
        with self.assertRaises(ValueError):
            simultaneous_sensitive_intervals([string_context], independent_arms=True)


if __name__ == '__main__':
    unittest.main()
