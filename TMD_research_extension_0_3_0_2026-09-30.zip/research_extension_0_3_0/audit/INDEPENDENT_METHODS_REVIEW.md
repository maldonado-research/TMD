# Independent methods review for extension 0.3.0

Status: independent agent review of the stated numerical/statistical implementation, not external peer review, biological validation, experiment authentication or novelty certification. Original references were preserved. Review is based on the file versions hashed below.

## Outcome and verification

No substantive mathematical, observation-contract or inference-claim error was found in the reviewed final files. The independent bundled-Python run passed16 inference tests and9 design tests. Earlier helper validation concerns were corrected: public contrast/variance helpers now require valid probability simplexes, and design helpers reject numeric strings instead of validating converted counts but using their original values.

Reviewed the prospective protocol, formal methods, transport/precision note, numerical likelihood primitives, entry-point code and tests. The plain-language and scientific-progress summaries preserve the distinction between deterministic fixtures, repeated-sample calibration, and biological evidence; their numerical examples agree with the formal-methods report. Draft root-document links were scheduled for correction before packaging and are outside this numerical review receipt. Test coverage includes independent product-ratio reconstruction, numeric derivatives, inverse-information identity, known-composition offsets, information failure, zero-cell and missing-arm refusal, control-design rejection, transport confounding, and unresolved bootstrap accounting. These checks establish behavior of the implementation on chosen inputs, not general finite-sample size or power.

## Independent mathematical check

Write F(h)=log(h_A/h_M)−0.5log(h_W/h_M). The independently reconstructed routewise product is Z_i=t_i*a0_i*r1_i/(b_i*a1_i*r0_i). The corrected contrast is log[Z_A/sqrt(Z_W*Z_M)] and its squared invariant is Z_A²/(Z_W*Z_M). Under branch-matched route-relative recovery, q normalizes b*r0/a0 and p normalizes t*r1/a1. Thus the contrast equals v·(log p−log q), v=(−0.5,1,−0.5). Unknown assay-wide scales cancel. Arbitrary differential sample/control transport produces the additional contrast v·rho and remains confounded with biological theta.

Let delta_r=F(r1)−F(r0). Then theta=F(t)−F(b)−F(a1)+F(a0)+delta_r. Solving for selected A-reference log odds gives theta+0.5*T_W+B_A−0.5*B_W+A1_A−0.5*A1_W−A0_A+0.5*A0_W−delta_r. This independently verifies every constraint sign and the negative known-composition offset in the implemented design.

Four positive three-category observed compositions give8C unconstrained coordinates. With one common corrected contrast, each context retains seven nuisance coordinates and there is one shared scalar:7C+1. This imposes C−1 restrictions relative to the saturated model. C=1 imposes none. No hidden absolute-recovery constraint reduces this count: any positive relative-recovery vector admits a sufficiently small common efficiency scale bounded by one.

For finite known offsets, positive cells and full design rank, multinomial log-sum-exp is strictly convex and coercive. A finite unique null estimate is justified. Numerical score, line-search, multiple-start agreement and positive information checks are appropriate; they are not biological admission checks.

The multinomial covariance independently gives Var[F(h_hat)]≈[sum(v_i²/h_i)−(sum v_i)²]/H. The second term vanishes. Independence therefore yields four variance contributions, including both random control arms. At the shared model, inverse-variance information combines contexts. This agrees with the information identity exercised by the tests.

Cauchy–Schwarz yields sum(A_g/n_g)*sum(c_g*n_g)≥[sum sqrt(A_g*c_g)]². Equality requires n_g proportional to sqrt(A_g/c_g), giving the documented allocation. Unit counts are recovered categorical observations, not introduced fixed-route units; laboratory costs require a recovery/yield model.

Signed box endpoints and reversal when subtracting bias are correct. Symmetric routewise |rho_i|≤epsilon permits contrast bias±2epsilon and two-context differences up to4epsilon. Approximate Bonferroni sampling intervals widened by these assumed bounds are valid only under the stated regular-model assumptions and genuinely covering bounds; compatibility is not confirmation.

## Observation and inference limits preserved

The protocol correctly distinguishes independent random input-route mixtures, conditional on recovered total, from fixed per-route introduced counts. The former yields the implemented recovered-label multinomial; the latter generally needs separate binomial successes/trials. Known pre-recovery mixture composition is essential. Noisy compositions, barcode/read amplification, route misclassification, shared batches, clonal expansion and mixture-dependent recovery require additional likelihoods or justified sensitivity treatment.

Controls added at one processing stage cannot identify losses or evolutionary establishment before that stage. Relative recovery must transfer from controls to actual biological units, not merely across two artificial mixtures. The proposed held-out mixture test can challenge that narrower transfer assumption, but cannot prove biological transport. A known neutral reference is an additional assumption, not a conclusion from the same counts.

The zero-cell policy is accurately described as unsupported computation, not proof of a boundary estimate. No pseudocount substitute is reported. Every bootstrap arm is resampled; unresolved draws remain in computational exceedance bounds. Estimated-null composite bootstrap and its plus-one convention are accurately labeled approximate. No exact finite-sample coverage, universal calibration, sparse-data confidence interval or mechanism identification is claimed.

The deterministic recovery-rescue and strong-departure fixtures are appropriate arithmetic/software demonstrations. Their bootstrap minimum p-values resolve only to1/200 for199 draws; nonrejection does not validate controls or prove the restriction. Operating-characteristic studies for sparse/weak-effect designs and real independent control observations remain necessary.

## Reviewed file hashes

- `inference/recovery_control_inference.py`: `cb2ab49891e97dc5e29ddcdf05ea727fec33eaa2ccb8dcc145d091069433a0f9`
- `inference/_convex_multinomial.py`: `97648119e264ba06d97b5e146a10f28382ac7e2ab118f3c201daafae8bef65d8`
- `inference/test_recovery_control_inference.py`: `240a0203351224a831f44d9f721b7b6dc7b507e2cfb75d4f271e5fbbab88f76c`
- `design/transport_sensitivity.py`: `a584f1484eb25b7d5eaf0a5a0ef1a08d8d4bb7a58fdd08642fe83862ac3b0ddd`
- `design/test_transport_sensitivity.py`: `9b4bf7c62c8db58219b4d20dee7c4406ddf64ffa6673edff1005f3e5b991b818`
- `methods/RECOVERY_CONTROL_BRIDGE.md`: `b75088b3d66e5f4e712e0add49729700d630351155b8ce59e266f89bded01e09`
- `design/TRANSPORTABILITY_AND_PRECISION.md`: `7c956c8ec97a661e32901a6a7fdd7fff22896ad95d61e26708ddcca63394da2d`
- `PROSPECTIVE_RECOVERY_PROTOCOL.md`: `b353c3ed0bde89288bc4bf59f90ce670e22f2cedf17a8422188c26d73968dbd2`
