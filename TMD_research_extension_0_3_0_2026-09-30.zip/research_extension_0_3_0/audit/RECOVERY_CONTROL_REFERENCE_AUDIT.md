# Local audit for a recovery-control extension

Scope: TMD research archive and its TMD-specific D-Blast vector-store subfolder; read-only originals. Reused the 0.2.0 audit inventory rather than treating repeated software release outputs as experiments. Labels `TMD_ARCHIVE/` and `TMD_VECTOR_STORE/` represent local reference roots; this report and inventory contain no private absolute paths.

## Findings that affect the next method

No authenticated independent recovery-control counts, matched new supply observations, or prior explicit route-specific recovery-control likelihood were found in the inspected local material outside the published 0.2.0 work. The next extension therefore still requires synthetic validation and a prospective data contract. A negative scoped search does not establish that uninspected archives, unavailable project sources or unpublished laboratory records contain no data.

Detection bias is already recognized locally. The TMD vector-store handoff `TMD_COMPLETE_RESEARCH_HANDOFF_AND_100_EXPLORE_QUESTIONS_2026-09-08-2.md`, line 640, says sequencing thresholds and route classification can distort counts and times. Nearby lines 626–648 distinguish hazards from mutation probabilities, first appearance from detection/fixation, overlapping mechanistic factors, batch effects and synthetic provenance. These are useful constraints, not measured recovery rates. The same handoff's categorical statement about route-specific frailty breaking independence is superseded by the counterexamples in the 0.1.0 release and should not be copied as a general theorem.

A generic older reviewer checklist requests negative controls and spike-ins. This means controls are not a new project idea. It does not supply an operational route-recovery assay, matched exposure denominator, independence record or experimental result. The new advance can reasonably be described as an explicit recovery-control observation model and its identifiability/data requirements, not the invention of controls or binomial inference.

## Strongest concrete prior designs

| Reference label | Evidence | What can be reused / what is missing |
|---|---|---|
| `TMD_ARCHIVE/untitled folder 194/TMD_H482R_count_assay_template_v0_1.csv` | Header includes LB/SMM successes and totals, alpha and beta. Its only row has `use=0` and blank outcome counts. | Useful successes/trials schema. This is a conditional H482-family route assay, not an independent recovery-control sample. |
| Same folder, `TMD_H482R_ratio_assay_template_v0_1.csv` | All rows have `use=0`, and three ratio summaries equal1. | Disabled placeholders for supply, accessibility and persistence; no measured values. |
| Same folder, `TMD_H482R_assay_to_bits_converter_note_v0_1_2026-03-11.md`, lines40–53 | Separate Beta distributions for LB/SMM route fractions; endpoint-quantile ratio bounds. | Existing binomial uncertainty and ratio transformation. No recovery normalization, no joint control likelihood, and those constructed bounds are not an exact95% posterior interval for the ratio. Do not import a nominal95% ratio claim. |
| Same note, lines26–35 and74–75 | Corrections must represent non-overlapping multiplicative factors; do not sum duplicate assay views. | Important constraint: a recovery factor already embedded in q or fitness cannot be added again. The old extra-bits controller is not the biological likelihood. |
| `TMD_ARCHIVE/old mutation files/untitled folder 11/TMD_submission_pack_v1/05_Reviewer_Checklist.md`, line4 | Generic negative controls and spike-ins. | Supports measuring controls independently, but contains neither a tested route protocol nor observed trial counts. |
| `TMD_ARCHIVE/new mutation 8 GOOD/TMD_v1_5/templates/G1_counts_template.csv` | Example D2O/class counts plus callable bases. | Exposure-denominator convention is useful. Template numerals lack source/lineage records and cannot be promoted to measured recovery counts. |
| `TMD_ARCHIVE/untitled folder 167/TMD_OSF_prereg_block_WS_flagship_v0_1.md`, lines8,28,84–95,110–116 | Fixed supply q, WS model, optional winner-time gate. | Historical restriction already exists. Its pooled timing and `p>=0.05` independence gate are superseded; nonrejection cannot demonstrate independence. No new supply or controls were recorded. |

The prior 0.2.0 audit identified only three Lind2019 mutation-rate summaries and selected-route outcomes from another study. They remain incompatible with an invented matched recovery dataset. Pathway-isolated sequencing totals and fluctuation-assay colonies are still not automatically independent route-probability controls.

## Design consequences

An explicit proposed recovery contract should distinguish introduced independent control units from recovered positives for every prespecified route, context and assay branch. Label assay branch as baseline versus selected, define the recovery endpoint and time window, document the lineage/block, preserve failures, and prevent reuse of controls as independent selected outcomes. Any existing route mixture needs independently verified composition and route classification.

The interpretation requires the controls' recovery probability to represent recovery of the biological units in the assay. Clonal expansion, route-dependent viability, enrichment, censoring, concentration effects or repeated measurements may invalidate independent Bernoulli/binomial sampling. A spike-in recovery rate measured after selection cannot silently represent establishment before selection. Independent controls do not fix an invalid mutation-supply observation model.

Unknown absolute common recovery within one branch can cancel from a log contrast; route-dependent relative recovery is the identifiable target relevant to the WS contrast. Equal losses in baseline and selected branches may cancel, so the new model must retain both branches and their uncertainty. Recovery zeros need a support/identifiability analysis rather than arbitrary tiny replacements. If controls and outcomes share batches, the covariance cannot be assumed zero merely because CSV rows are separate.

These are proposed statistical/design consequences of the existing measurement-bias derivation. No laboratory protocol is authenticated here and no mechanistic factor is newly measured. The most useful advancement is a data contract, likelihood, boundary checks and synthetic experiments showing when independently justified controls identify the target contrast, and when confounding remains.

## Search boundary and inventory

Listed only relevant TMD research roots first, screened861 unique text files under300,000bytes for narrow recovery/detection terms, and read the strongest candidates. Excluded validation outputs, recent copies of the already-reviewed 2026 progress releases, and nontext files. Eight files contained strong-term hits; seven directly read evidence items appear with hashes and line references in `inventory.json`. No archived scripts were executed, no original files changed, and no unrelated personal folders searched.
