# Mutation by Natural Dominance: methods extension 0.3.0

**Independent recovery controls and transport sensitivity.** This package adds a four-arm observation model to the 0.2.0 joint route-count test. It is reproducible methods research and synthetic validation, not new biological confirmation. Author: Ricardo Maldonado, with AI-assisted analysis; research date 30 September 2026.

Read [In More Basic Terms](IN_MORE_BASIC_TERMS.md), then [scientific progress](SCIENTIFIC_PROGRESS.md). For the formal result use [recovery-control mathematics](methods/RECOVERY_CONTROL_BRIDGE.md), [transportability and precision](design/TRANSPORTABILITY_AND_PRECISION.md), and the [proposed experiment/data contract](PROSPECTIVE_RECOVERY_PROTOCOL.md). The [literature review](literature/LITERATURE_UPDATE.md) and [archive audit](audit/RECOVERY_CONTROL_REFERENCE_AUDIT.md) explain the evidence boundary.

## Reproduce

Python 3.10+ and NumPy are required for inference. The design helper uses only the standard library. Exact tested versions and counts are recorded in `VALIDATION.json`; dependencies are listed in `requirements.txt`. Run from the extracted package root:

```sh
python3 -m unittest discover -s inference -p 'test_recovery_control_inference.py' -v
python3 -m unittest discover -s design -p 'test_transport_sensitivity.py' -v
python3 inference/recovery_control_inference.py \
  inference/fixtures/recovery_artifact_shared_theta.json \
  --bootstrap 199 --seed 20261001 --output regenerated_recovery_example.json
python3 design/transport_sensitivity.py
```

Use a working copy to regenerate outputs while preserving original checksums. The `inference/run_synthetic_validation.py` and `calibration/` scripts document synthetic comparisons and repeated-sample checks. All included fixtures and numerical examples are synthetic or analytic planning examples; their metadata is not authenticated experimental evidence.

## What this implementation admits

Route order W,A,M means Wsp,Aws,Mws. Four arms are biological baseline, selected outcomes, baseline recovery controls and selected recovery controls. Every supported context needs positive independent multinomial counts, independently known positive randomized control input compositions and a justified transfer argument. The CLI enforces explicit design declarations; they do not prove that the experiment satisfies them. API users must enforce the same data contract. Absolute efficiency and causal factorization remain unidentified.

Fixed per-route introduced totals with recovery successes need a binomial model, not this conditional-mixture likelihood. Raw fluctuation colonies, pathway-isolated strain totals and sequencing reads are not automatically independent categorical units. Shared-batch, unknown-composition, time-of-detection and zero-cell designs require methods outside this prototype. All observed zero cells are conservatively declined, without a claim that their MLE must be on the boundary.

The fitted-null parametric bootstrap resamples all four arms and retains unresolved draws in computational p-value bounds. It is approximate for a composite null. Corrected nonrejection and structural interval overlap do not establish transport, causality or TMD.

## Versions and reuse

This package is **0.3.0**. The downloadable 0.2.0 package, expanded 0.1.0 report and archived software v2.6.5 remain separate historical records. No earlier DOI is assigned to this package. Cite the version-specific `CITATION.cff` and separately cite primary sources. `SHA256SUMS.txt` checks file integrity, not scientific truth.

New software is MIT licensed; new explanatory writing is CC BY 4.0, with third-party rights preserved in [LICENSING.md](LICENSING.md). No primary paper, publisher figure, source workbook or new biological dataset is redistributed. Neither EDISON 675419 nor MOSBRI 101004806 funded TMD; this independently developed extension makes no claim to those grants.
