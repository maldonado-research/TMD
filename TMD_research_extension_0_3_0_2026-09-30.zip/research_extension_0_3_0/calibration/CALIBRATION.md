# Limited repeated-sample calibration and stress test

This is a synthetic numerical check of the unmodified 0.3.0 recovery-control inference API. It contains no biological observations and does not certify nominal test size, power, control transport or TMD.

For each of the two supplied fixtures, we generated 40 independent datasets. Each dataset has four contexts, four independent multinomial arms per context and three routes, with **600 recovered observations in every context/arm**. Probabilities are the exact rational proportions encoded by the fixture integer counts; the fixture's larger, unequal deterministic totals were not used as sample sizes. Known mixture compositions `r0` and `r1` were supplied to inference. Control recovery transports to its paired outcome branch exactly by construction.

The shared scenario has corrected theta = log(2) in all contexts. The departure fixture has theta = log(4) in context four and log(2) elsewhere: a log(2) departure. The other supplied generating features remain fixed. These are two particular scenarios, rather than a range of biological effects or sampling designs.

Every evaluable dataset received 99 estimated-null four-arm parametric bootstrap draws. The decision rule was the plus-one p-value <= 0.05. With 99 draws, p-value resolution is 0.01, and rejection requires at most four exceedances. Outer datasets and inner bootstrap draws have separate deterministic seeds descended from master seed `2026100103`.

| Synthetic scenario | Rejections at 5% | Estimated rejection fraction | Two-sided 95% Wilson interval |
|---|---:|---:|---:|
| Shared latent theta with route recovery artifact | 0/40 | 0% | 0–8.76% |
| Supplied context departure | 24/40 | 60% | 44.60–73.65% |

All 80 dataset fits and all 7,920 bootstrap draws resolved. No datasets or draws were replaced or discarded on the basis of numerical status or statistical outcome. The script also supports unresolved cases: it retains their statuses and reasons, uses lower/upper computational p-value bounds for incomplete bootstraps, marks an ambiguous decision unresolved, and keeps all 40 datasets in rejection-count bounds. Those computational bounds are not confidence intervals. Missing fits would leave their bootstrap draws explicitly unattempted, rather than silently reduce the requested denominator.

The Wilson intervals describe binomial uncertainty across independent datasets **for these fixed synthetic probabilities and this finite-bootstrap decision procedure**. They do not cover uncertainty in biological contexts, unknown composition, transport violations or an ideal infinite-bootstrap test. Zero rejections does not establish an exactly 5% or conservative test: 5% lies within the interval. The 60% departure result is a limited stress-test rejection rate, not a general sample-size or power claim. The estimated-null bootstrap remains an approximate composite-null calibration, and 99 draws give coarse decisions near the threshold. No sparse, zero-support, misspecified transport, dependent-arm or weak-control scenarios were assessed here.

## Reproduction and provenance

Run with Python and NumPy:

```sh
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python3 output/research_extension_0_3_0/calibration/run_repeated_sample_calibration.py
```

The recorded run used the bundled Python runtime. Exact Python/NumPy versions, all sampled count tables, seed pairs, fit diagnostics, resolved bootstrap statistics, unresolved counts, summaries and generating rational probabilities are in `repeated_sample_results.json`. Its `source_sha256` records the calibration script, inference module, solver and both fixtures. The script checks these hashes again before writing results; elapsed runtime is the only timing-dependent output field. The saved hashes were compared with the final frozen inference/solver and matched. During preparation, a source change triggered an identical-seed restart before results were emitted; no new datasets were selected.

Only this calibration folder was changed. The inference API, solver, fixture files, design and biological protocol were not edited by this validation task.
