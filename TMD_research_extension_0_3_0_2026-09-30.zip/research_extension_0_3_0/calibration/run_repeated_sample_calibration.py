#!/usr/bin/env python3
"""Limited synthetic repeated-sample calibration; no biological observations.

Copyright (c) 2026 Ricardo Maldonado. MIT; see ../inference/LICENSE.
Runs the unmodified 0.3.0 inference API on independent four-arm multinomials.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
INFERENCE = ROOT.parent / "inference"
sys.path.insert(0, str(INFERENCE))
from recovery_control_inference import (  # noqa: E402
    bootstrap_recovery_bridge, corrected_contrast, validate_document,
)

DATASETS = 40
BOOTSTRAPS = 99
TOTAL_PER_ARM = 600
ALPHA = 0.05
MASTER_SEED = 2026100103
SCENARIOS = (
    ("shared_latent_theta", "recovery_artifact_shared_theta.json"),
    ("context_departure", "genuine_theta_departure.json"),
)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def wilson(successes, trials):
    """Two-sided 95% Wilson score interval for an independent binomial count."""
    if trials <= 0:
        return None
    z = 1.959963984540054
    rate = successes / trials
    denominator = 1 + z * z / trials
    center = (rate + z * z / (2 * trials)) / denominator
    half = z * math.sqrt(rate * (1 - rate) / trials + z * z / (4 * trials * trials)) / denominator
    return [max(0.0, center - half), min(1.0, center + half)]


def load_scenario(filename):
    path = INFERENCE / "fixtures" / filename
    doc = json.loads(path.read_text())
    names, counts, r0, r1 = validate_document(doc)
    assert counts.shape == (4, 4, 3)
    # Each deterministic table encodes an exact rational probability vector.
    # Normalize the integer counts BEFORE sampling; ignore original arm totals.
    fractions = [
        [[Fraction(int(cell), int(sum(arm))) for cell in arm] for arm in context]
        for context in counts
    ]
    probabilities = np.array([[[float(cell) for cell in arm] for arm in context] for context in fractions])
    assert np.all(probabilities > 0)
    assert np.allclose(probabilities.sum(axis=2), 1.0, rtol=0, atol=1e-14)
    theta = corrected_contrast(probabilities, r0, r1)
    assert np.allclose(theta, [row["theta"] for row in doc["generating_parameters"]], rtol=0, atol=1e-12)
    return path, names, probabilities, fractions, r0, r1, theta


def summarize(records):
    decisions = Counter(record["decision_at_5_percent"] for record in records)
    statuses = Counter(record["bootstrap_result"]["status"] for record in records)
    rejected = decisions["reject"]
    ambiguous = decisions["unresolved"]
    possible = rejected + ambiguous
    completed_draws = sum(record["bootstrap_result"].get("replicates", 0) for record in records)
    unresolved_draws = sum(record["bootstrap_result"].get("unresolved_replicates", 0) for record in records)
    not_run = BOOTSTRAPS * DATASETS - completed_draws
    reasons = Counter()
    for record in records:
        reasons.update(record["bootstrap_result"].get("unresolved_reasons", {}))
    return {
        "datasets_requested_and_retained": len(records),
        "bootstrap_status_counts": dict(statuses),
        "decision_counts": {key: decisions[key] for key in ("reject", "do_not_reject", "unresolved")},
        "rejection_count_computational_bounds": [rejected, possible],
        "rejection_fraction_computational_bounds_all_40": [rejected / DATASETS, possible / DATASETS],
        "binomial_wilson_95_percent_interval": wilson(rejected, DATASETS) if ambiguous == 0 else None,
        "wilson_envelope_when_decisions_unresolved": [wilson(rejected, DATASETS)[0], wilson(possible, DATASETS)[1]] if ambiguous else None,
        "wilson_interpretation": "Repeated-dataset uncertainty for this fixed synthetic scenario; not uncertainty over biological contexts. If decisions are unresolved, the envelope combines Wilson endpoints for definite and possible counts and is not an exact nominal confidence interval.",
        "bootstrap_draws_requested": BOOTSTRAPS * DATASETS,
        "bootstrap_draws_attempted": completed_draws,
        "bootstrap_draws_not_attempted_due_to_dataset_fit": not_run,
        "bootstrap_draws_unresolved": unresolved_draws,
        "unresolved_draw_reasons": dict(reasons),
    }


def main():
    started = time.monotonic()
    paths = [Path(__file__).resolve(), INFERENCE / "recovery_control_inference.py", INFERENCE / "_convex_multinomial.py"]
    initial_hashes = {str(path.relative_to(ROOT.parent)): sha256(path) for path in paths}
    scenario_seeds = np.random.SeedSequence(MASTER_SEED).spawn(len(SCENARIOS))
    output = {
        "schema_version": "0.3.0",
        "provenance": "synthetic_repeated_sampling_only",
        "purpose": "Limited calibration/stress test; not certified test size, power or biological validation.",
        "software": {"python": platform.python_version(), "numpy": np.__version__},
        "configuration": {"contexts": 4, "arms": 4, "routes": 3, "total_each_context_arm": TOTAL_PER_ARM, "datasets_each_scenario": DATASETS, "four_arm_bootstraps_each_evaluable_dataset": BOOTSTRAPS, "nominal_alpha": ALPHA, "master_seed": MASTER_SEED, "p_value_rule": "plus-one bootstrap p <= 0.05; with unresolved draws reject only if upper computational bound <= 0.05, nonreject only if lower bound > 0.05", "resampling_policy": "No dataset replacement or failed-draw replacement; all random datasets retained."},
        "source_sha256": initial_hashes,
        "scenarios": [],
    }
    for (label, filename), scenario_seed in zip(SCENARIOS, scenario_seeds):
        path, names, probabilities, fractions, r0, r1, theta = load_scenario(filename)
        output["source_sha256"][str(path.relative_to(ROOT.parent))] = sha256(path)
        scenario = {"scenario": label, "source_fixture": str(path.relative_to(ROOT.parent)), "context_names": names, "observed_probabilities_exact_rational": [[[str(value) for value in arm] for arm in context] for context in fractions], "observed_probabilities": probabilities.tolist(), "known_r0": r0.tolist(), "known_r1": r1.tolist(), "generating_corrected_theta": theta.tolist(), "transport_assumption": "Exact by construction; control and corresponding outcome arm use the same relative recovery.", "records": []}
        for index, dataset_seed in enumerate(scenario_seed.spawn(DATASETS)):
            data_seed, bootstrap_seed_seq = dataset_seed.spawn(2)
            data_seed_int = int(data_seed.generate_state(1, dtype=np.uint64)[0])
            bootstrap_seed = int(bootstrap_seed_seq.generate_state(1, dtype=np.uint64)[0])
            rng = np.random.default_rng(data_seed_int)
            sampled = np.array([[rng.multinomial(TOTAL_PER_ARM, prob) for prob in context] for context in probabilities])
            assert sampled.shape == (4, 4, 3)
            assert np.all(sampled.sum(axis=2) == TOTAL_PER_ARM)
            result = bootstrap_recovery_bridge(sampled, r0, r1, replicates=BOOTSTRAPS, seed=bootstrap_seed)
            bounds = result.get("p_value_computational_bounds")
            decision = "unresolved" if bounds is None else ("reject" if bounds[1] <= ALPHA else ("do_not_reject" if bounds[0] > ALPHA else "unresolved"))
            scenario["records"].append({"dataset_index": index, "dataset_seed": data_seed_int, "bootstrap_seed": bootstrap_seed, "sampled_counts": sampled.tolist(), "decision_at_5_percent": decision, "bootstrap_result": result})
            if (index + 1) % 10 == 0:
                print(f"{label}: {index + 1}/{DATASETS} datasets retained", flush=True)
        scenario["summary"] = summarize(scenario["records"])
        output["scenarios"].append(scenario)
    for relative, expected in output["source_sha256"].items():
        assert sha256(ROOT.parent / relative) == expected, f"Source changed during run: {relative}"
    output["elapsed_seconds"] = time.monotonic() - started
    destination = ROOT / "repeated_sample_results.json"
    destination.write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"results": destination.name, "summaries": {item["scenario"]: item["summary"] for item in output["scenarios"]}}, indent=2), flush=True)


if __name__ == "__main__":
    main()
