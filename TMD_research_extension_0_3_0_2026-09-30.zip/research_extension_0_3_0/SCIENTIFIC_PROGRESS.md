# TMD 0.3.0: independent recovery controls and transport sensitivity

Research date: 30 September 2026, America/Los_Angeles. Author: Ricardo Maldonado, with AI-assisted analysis. This methods extension follows the published 0.2.0 package; it is separate from archived software v2.6.5 and the expanded 0.1.0 report.

## The problem resolved mathematically

The 0.2.0 observation-bias identity showed that differences in route-specific recovery can masquerade as context-specific biological contrasts. That release propagated baseline/selected sampling uncertainty but did not estimate recovery from controls. The present extension supplies an explicit **four-arm conditional multinomial likelihood**, identifies the adjusted contrast under stated transfer assumptions, propagates all four samples' uncertainty, and quantifies residual confounding if transfer fails.

This is an advance within the project. Controls, multinomial likelihoods, log contrasts, convex optimization, interval arithmetic and the delta method are established mathematics. External novelty or priority is not claimed. Searching selected papers and archives cannot establish priority.

## The conditional result

Let observed biological baseline and selected mixes be b and t. Let independent control outputs a0 and a1 arise from known randomized input compositions r0 and r1, processed with the corresponding branch recovery. With v = (−1/2,1,−1/2), the corrected contrast is:

```text
theta_corr = v · [log(t) − log(b) − log(a1) + log(r1) + log(a0) − log(r0)]
```

If route-relative recovery transfers from controls to biological units, this equals v·[log(p)−log(q)], the biological contrast. Normalizers cancel. The four-arm likelihood has 7C+1 null dimensions against 8C saturated dimensions for C contexts, hence C−1 regular restrictions. One context gives a descriptive contrast but no constancy test. The numerical implementation uses a convex linear-logit parameterization with analytic gradient and Hessian.

The corrected biological distribution is identifiable only given the admitted baseline likelihood, known input compositions, positive support and transfer assumptions. Absolute recovery probabilities, opportunity flux, mutation/fitness/accessibility factorization and causal mechanism remain unidentified. A shared contrast can arise under explanations other than TMD. The test addresses the specified contrast restriction, not all possible versions of the hypothesis.

## Synthetic demonstrations

The exact rational fixtures use four contexts with nonuniform control mixtures and differential route recovery. They are constructed expected-frequency tables, not random biological data; their bootstrap values illustrate the algorithm only.

| Constructed scenario | Ignoring recovery | Joint correction |
|---|---|---|
| Shared biological theta = log(2) | Apparent context contrasts 0.0000, 0.3466, 2.0794 and −1.0397; deviance 695.100; approximate bootstrap p=0.005 | Corrected contrasts all 0.6931; deviance 0; p=1.000 |
| Fourth context biological theta changes from log(2) to log(4) | Deviance 511.956; p=0.005 | Corrected fourth contrast 1.3863; deviance 20.794; p=0.005 |

Each comparison uses 199 estimated-null bootstrap draws, minimum resolution 0.005, with zero unresolved draws. The p=1.000 value follows a deliberately noiseless shared-null construction; it is not affirmative evidence for biology or a typical random-study outcome. The minimum p values mean no simulated bootstrap statistic exceeded the observed statistic at that Monte Carlo resolution; they are not exact tail probabilities. See [full fixture summaries](inference/fixtures/synthetic_comparison_summary.json) and [methods](methods/RECOVERY_CONTROL_BRIDGE.md).

The separate [repeated-sample check](calibration/CALIBRATION.md) sampled 40 random datasets per scenario with four contexts, 600 observations per arm/context and 99 bootstrap draws per dataset. At the 5% threshold, the shared-theta scenario rejected 0/40 (95% Wilson interval 0–8.76%); the fourth-context departure rejected 24/40 (60%, interval 44.60–73.65%). All 80 datasets and 7,920 bootstrap draws resolved, with none replaced or discarded. These broad intervals and two selected scenarios do not certify nominal size or broad power. Unlike the deterministic examples, this check exposes finite-sample uncertainty: a true departure was missed in 16/40 of these simulated studies. Sparse routes, weak effects and imperfect transport remain uncalibrated.

## Transfer becomes a reported uncertainty

If controls transfer imperfectly, theta_corr = theta_bio + v·rho, where rho is the difference between selected and baseline control-to-biological log recovery mismatch. Routewise bounds on rho give sharp structural bounds on biological theta over the supplied box. With no defensible finite bound, the biological contrast remains unidentified. The [sensitivity and precision analysis](design/TRANSPORTABILITY_AND_PRECISION.md) includes sign-aware bounds, optional regular sampling intervals, and cost-aware four-arm allocation.

In an analytic equal-frequency example, 100 recovered categorical observations per arm give standard error 0.4243. Holding the measured controls artificially fixed would give 0.3000. The method properly retains control uncertainty. These numbers are planning examples only.

## New literature and local evidence

A targeted [primary-source review](literature/LITERATURE_UPDATE.md) adds four studies absent from earlier reviews: barcode processing bias, environmental memory, stress-response heterogeneity and an independently calibrated engineered replication system. These provide methodological constraints and useful measurement ideas; none supplies admissible WS recovery data or validates TMD. Dates and restricted read scope are recorded per source.

The scoped [local audit](audit/RECOVERY_CONTROL_REFERENCE_AUDIT.md) found earlier detection-bias cautions, generic spike-in requests and blank count-assay templates. It found no authenticated independent matched recovery observations. Historical endpoint-quantile ratio bounds and nonrejection-as-independence claims are not imported. Reference archives were read without modification; unavailable or uninspected sources remain outside the claim.

## The next empirical falsifier

The [prospective protocol](PROSPECTIVE_RECOVERY_PROTOCOL.md) defines independent units, randomized known-mixture recovery controls, cross-mixture hold-out checks, transport bounds, admission rules, and a selected-outcome prediction locked before data. Fixed-route exposed/success totals need a different binomial likelihood; barcode reads need an appropriate processing model. Neither can be silently inserted here. A weak control test's nonrejection cannot authenticate transfer.

No new biological data were collected, no laboratory protocol was executed, and no connection to quantum mechanics, relativity or a unified physical theory is established by this statistical extension. The meaningful result is a more falsifiable and measurement-aware biological research program.
