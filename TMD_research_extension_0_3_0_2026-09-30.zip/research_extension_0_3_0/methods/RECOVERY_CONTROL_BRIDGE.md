# A recovery-control bridge for the WS contrast

**Status:** proposed observation model and tested software prototype 0.3.0. No new laboratory observations, externally novel mathematics, biological validation or executed preregistration is claimed. This implements standard multinomial exponential-family likelihood theory for a new explicit measurement design. Version 0.2.0 propagated independent supply-calibration uncertainty but could not resolve unknown differential recovery. Version 0.3.0 adds independently sampled recovery controls under stated transport assumptions.

## 1. Four samples and the observation rule

For each prespecified context c, let q_c be the true baseline route composition. Write the selected composition as

\[
p_{ci}\propto q_{ci}\exp(\theta_c I_{i=A}+\eta_c s_i),\quad
s=(1,0,-1),\quad i=(W,A,M).
\]

The null is shared theta_c=theta. A free eta_c absorbs the W/M tilt within each context. This is a restriction on route distributions under a locked winner-observation rule, not an identification of a biological mechanism or a fully held-out forecast.

Let d0_ci,d1_ci be positive baseline- and selected-assay recovery factors. For probability interpretations they are in (0,1]; their unknown common scales cannot be inferred from recovered-category proportions. Assume observed baseline and selected distributions

\[
b_{ci}=\frac{q_{ci}d0_{ci}}{\sum_jq_{cj}d0_{cj}},\qquad
t_{ci}=\frac{p_{ci}d1_{ci}}{\sum_jp_{cj}d1_{cj}}.
\]

Two independent control samples have known positive input compositions r0_c,r1_c and observed recovered compositions

\[
a0_{ci}\propto r0_{ci}d0_{ci},\qquad
a1_{ci}\propto r1_{ci}d1_{ci}.
\]

The central assumption is **transport of route-relative recovery** from each control to its corresponding actual sample. Controls may have their own unknown assay-wide scalar factor: a0 proportional to r0*k0*d0 and a1 proportional to r1*k1*d1 gives the same normalized compositions. No equality of absolute recovery is needed. No transport across different contexts is presumed; each context has its own controls.

The implementation takes four independent categorical samples, in baseline, selected, baseline-control, selected-control order:

\[
Y_{cg}\sim\operatorname{Multinomial}(H_{cg},z_{cg}),\quad
z_c=(b_c,t_c,a0_c,a1_c),\quad g=0,1,2,3.
\]

H is the number of eligible recovered observations in that arm. The independent multinomial contract must be justified for each arm, not inferred from its row of three numbers. Calibration from fluctuation-culture colony totals needs a culture/growth likelihood; pathway-isolated mutant totals do not automatically estimate q. Correlated cultures, reused calibration observations or pooled sequencing counts need another sampling model. Controls must represent recovery and classification under the same operational endpoint as the actual sample; effects of biological selection on controls must not be silently reclassified as recovery.

**Random mixture versus fixed inputs matters.** If each control input has an independent route label drawn from known r, and recovery is conditionally route-specific, recovered labels have composition normalize(r*d). Conditioning on their total gives the stated multinomial model. Equivalently, a justified independent Poisson input-mixture construction gives that conditional likelihood. If the experiment fixes L_i input units for each route instead, recovered route counts follow separate Binomial(L_i,d_i) models; conditional on the total they are generally not this multinomial. Such fixed-input control data are explicitly rejected by this prototype. Input failure totals and absolute recovery could add information in a separate binomial/input-denominator likelihood; they are not used here.

All arms must use identical, prespecified route definitions and an exhaustive triad or explicit common triad conditioning. Other outcomes, missing labels, detection lag and recovery-dependent inclusion cannot be silently removed. Known r must describe the pre-recovery input mixture; using the observed recovered mixture as r would erase the correction. Physical mixing uncertainty, genotype-dependent survival or uncertain purity makes r uncertain and requires additional data or a sensitivity model.

## 2. The exact corrected contrast

Let v=(-1/2,1,-1/2), whose entries sum to zero. Taking logs cancels every normalization constant. Hence

\[
\begin{aligned}
\theta_c
&=v^T(\log p_c-\log q_c)\\
&=v^T(\log t_c-\log b_c-\log a1_c+\log r1_c
       +\log a0_c-\log r0_c).
\end{aligned}
\tag{1}
\]

The slope eta disappears because v^T s=0 and v^T I_A=1. The corrected invariant is J_c=exp(2 theta_c). This is an algebraic identity under the observation model; zero empirical cells may not be substituted into these log ratios.

All positive q,p are reconstructed from observable population compositions and known controls:

\[
q_c=\operatorname{normalize}(b_c r0_c/a0_c),\qquad
p_c=\operatorname{normalize}(t_c r1_c/a1_c).
\tag{2}
\]

Relative recovery is identified, for example

\[
\log(d0_{ci}/d0_{cM})=
\log(a0_{ci}/r0_{ci})-\log(a0_{cM}/r0_{cM}).
\]

Absolute recovery is not identified: multiplying every d0 by any admissible common scalar leaves b and a0 unchanged, and similarly for d1. Probability bounds d<=1 do not remove this ambiguity because a sufficiently small common scalar is always admissible. Only the relative route compositions, theta and eta are identified under the stated assumptions. Opportunity flux, mutation/accessibility/establishment decomposition and unrecorded competing routes remain unidentified.

The shared-theta restriction has an exact converse. Given positive b,t,a0,a1 and known r, recover q,p by (2), define theta_c by (1), and set eta_c=(1/2)log(p_W q_M/(p_M q_W)). These two contrasts reconstruct every positive triad p. Therefore a shared corrected theta is precisely the WS restriction in this observation model. The alternative with theta_c free is saturated in all four observed multinomials.

## 3. What control transport does not identify

Allow actual recovery d0^S,d1^S and control recovery d0^C,d1^C. Applying the proposed correction then gives

\[
\theta^{corr}_c=\theta_c+
 v^T\log(d1^S_c/d1^C_c)-v^T\log(d0^S_c/d0^C_c).
\tag{3}
\]

Arbitrary unknown route-specific transport errors remain exactly confounded with theta. More endpoint counts can narrow sampling error around the wrong corrected value without resolving this bias. An unknown fixed route-specific shift common across contexts preserves constancy while changing theta's level. A context-dependent shift can create or hide a departure. If nominal compositions r^nom are used in place of true input mixtures, an additional error is

\[
v^T[\log(r1^{nom}/r1^{true})-\log(r0^{nom}/r0^{true})].
\]

Off-diagonal route misclassification, recovery that depends on mixture composition or density, and unequal genotype behavior within a declared route need different observation models. Multiplicative route-specific recovery is not a general correction for these processes.

A useful falsifier uses two independently sampled, known input mixtures r^(k),r^(l) at the **same** assay stage. If a common route-relative recovery vector transports between them, then for each reference route M,

\[
\log\frac{a_i^{(k)}r_M^{(k)}}{a_M^{(k)}r_i^{(k)}}
=\log\frac{a_i^{(l)}r_M^{(l)}}{a_M^{(l)}r_i^{(l)}}.
\tag{4}
\]

Failure challenges that control transport model. Agreement tests only the exercised mixtures and conditions; it does not prove transport to the actual biological sample. With K independent mixtures at one stage, free observed compositions have 2K parameters and common relative recovery has 2, giving regular difference 2(K-1). This additional control-only diagnostic is a proposed validation branch, not implemented by the four-arm WS test.

An independently justified no-selection reference can provide a negative control: if its true biological contrast is known to be zero, a corrected nonzero contrast reveals a failure of at least one neutrality, calibration or recovery assumption. Its biological neutrality cannot be established from the same endpoint counts. The cross-context shared-theta LRT alone is not a test of theta=0 or of control validity. The protocol and sensitivity workflow in the design directory should specify these checks prospectively.

## 4. A convex likelihood with known offsets

The parameter-dependent joint log likelihood is

\[
\ell=\sum_{c,g,i}Y_{cgi}\log z_{cgi}.
\]

Multinomial coefficients are omitted from both compared models. No probability or count smoothing enters this likelihood. r0,r1 are known input compositions, not estimated parameters in this prototype.

Use M-reference log odds for b,t,a0,a1. Define seven nuisance coordinates per context

\[
(B_W,B_A,T_W,A0_W,A0_A,A1_W,A1_A)
\]

and one shared theta. Let delta_c=v^T(log r1_c-log r0_c). Equation (1) sets selected A log odds to

\[
T_A=\theta+\tfrac12T_W+B_A-\tfrac12B_W
     +A1_A-\tfrac12A1_W-A0_A+\tfrac12A0_W-\delta_c.
\tag{5}
\]

Every arm then uses softmax(logit_W,logit_A,0). All unknown logits are linear in beta, with a known selected-A offset -delta. The negative likelihood is convex log-sum-exp in **7C+1** unknowns. Its analytic gradient and Hessian are

\[
\nabla L=\sum_gX_g^T(H_gr_g-Y_g),\qquad
\nabla^2L=\sum_gH_gX_g^T[\operatorname{diag}(r_g)-r_gr_g^T]X_g,
\]

where r_g here denotes fitted **observed** arm probabilities, not the known control input compositions. Known offsets affect those probabilities, not the linear design derivatives.

For strictly positive observed counts in every arm and full-rank reference logit design, the negative likelihood is coercive and strictly convex: every nonzero parameter direction changes some logit difference, and positive counts in all categories penalize extreme differences. Thus there is a finite unique MLE. The code checks design rank, uses stabilized log-softmax, Newton line search and agreement between empirical and zero starting points, then checks positive information, its condition number and finite variance. Numerical failure is reported explicitly. Reconstructed probabilities that underflow numerical precision are not interpreted as population zeros.

The dense NumPy implementation is intended for modest numbers of contexts. It adapts MIT-licensed numerical primitives from 0.2.0, with fixed offsets added and complete license/version lineage retained. No new optimizer theory is claimed.

## 5. Alternative and uncertainty

The saturated alternative has 8C multinomial log odds. The null has 7C+1, leaving **C-1** regular degrees of freedom. Its alternative supremum is

\[
\ell_{alt}=\sum_{c,g,i:Y_{cgi}>0}Y_{cgi}\log(Y_{cgi}/H_{cg}),\qquad
D=2(\ell_{alt}-\ell_{null}).
\]

For one context the descriptive corrected theta is identifiable under the controls, but cross-context sharing imposes no restriction: df=0, no constancy test. Adequate independent samples, positive true support and regular finite parameters support the conventional chi-square limit; the software emits no asymptotic p-value. A cell expectation below five triggers a descriptive sparse warning, not a theorem of approximation validity.

Independent arm sampling gives the per-context delta-method variance

\[
V_c\simeq\sum_{g\in\{b,t,a0,a1\}}\frac{1}{H_{cg}}
                   \sum_i\frac{v_i^2}{z_{cgi}}.
\tag{6}
\]

Signs in (1) disappear on squaring. Multinomial cross-category covariance contributes a term proportional to [sum(v)]²=0. The two extra control terms express finite recovery-calibration uncertainty. Knowing r does not make observed control recovery a0,a1 exact. If relative recovery were fixed and known, those two terms would be absent.

At the shared model, first-order efficient variance for theta is [sum_c(1/V_c)]^-1. The code reports the theta standard error from inverse joint information and separate per-arm variance contributions. These are regular asymptotic quantities, not sparse-sample confidence intervals. Control/input uncertainty or correlation introduces further terms; it cannot be suppressed by declaring the arms independent.

## 6. Joint bootstrap and the deliberate zero-cell limit

The bootstrap preserves all four observed arm totals in each context. It independently generates all four arms from the fitted null probabilities, refits the same null and compares with the saturated alternative. Fixed seeds, draws, numerical tolerance and unresolved counts are recorded. When all B replicates resolve,

\[
\widehat p_{MC}=(1+\#\{D_b\ge D_{obs}\})/(B+1).
\]

This is an estimated-null parametric bootstrap using finite counts. It is **not an exact finite-sample test** of a composite null, and no global type-I-error or power calibration is claimed. The +1 convention prevents a reported zero and sets Monte Carlo resolution; it does not guarantee correct test size under estimated nuisance parameters.

This prototype conservatively declines **any observed zero cell** with `zero_cell_not_supported`, without claiming that all such tables have boundary MLEs. Some have finite joint null estimates; a validated extended-MLE/boundary analysis is deferred. A missing arm returns `missing_arm`. Neither case receives a finite tilt or p-value. No pseudocount or arbitrary parameter bound supplies a replacement estimate.

A bootstrap draw with zero cells or numerical failure is retained as unresolved, rather than discarded or replaced. With E resolved exceedances and U unresolved draws, the output has no single p-value and reports computational bounds

\[
[(1+E)/(B+1),(1+E+U)/(B+1)].
\]

These classify unresolved draws both ways. They are not population confidence intervals or a guarantee of valid sparse inference. The conservative zero policy reduces usefulness for rare routes and makes that limitation visible. Designing genuinely informative samples or developing the correct boundary likelihood is preferable to hiding zero counts.

## 7. Reproducible synthetic checks

The implementation is [recovery_control_inference.py](../inference/recovery_control_inference.py), with companion [_convex_multinomial.py](../inference/_convex_multinomial.py). Direct numeric API users must enforce the same observation contract as the JSON CLI. JSON declarations and hashes do not independently authenticate provenance or transportability. Input r0,r1 must be finite, strictly positive, sum to one and be justified as known.

The exact rational fixtures contain four contexts, differing supply, differing slopes, nonuniform known control mixtures and route-specific recovery. They are deterministic software checks; their category totals are not real cultures or an actual sample-size recommendation.

| Synthetic fixture | Uncorrected two-arm D | Corrected four-arm D | Uncorrected bootstrap p | Corrected bootstrap p |
| --- | ---: | ---: | ---: | ---: |
| Shared true theta=log(2), varying recovery | 695.099676 | 0 | .005 | 1 |
| Last context true theta changes to log(4) | 511.956162 | 20.794330 | .005 | .005 |

Each p uses 199 estimated-null draws with fixed seeds; .005 is the minimum attainable (1/200), not a tail probability resolved below .005. All these draws resolved. The first fixture's uncorrected empirical contrasts are [0,.346574,2.079442,-1.039721], while corrected contrasts are all .693147. The second's last corrected contrast is 1.386294. The constrained corrected fit is theta=.693147 with regular SE=.071399 for the first fixture, and theta=.904820 with SE=.069839 for the departure fixture. The latter is a pooled constrained estimate despite the known departure, not a common biological truth.

The reproducible comparisons are in [synthetic_comparison_summary.json](../inference/fixtures/synthetic_comparison_summary.json). They demonstrate the intended mathematical separation of measurement and selection contrasts, not control validity, nominal statistical calibration or validated mechanism. In particular, corrected nonrejection does not prove the shared restriction.

Verification covers independent product-ratio algebra, reconstruction of latent q,p and eta, the fixed-offset design, score/Hessian finite differences, the four-arm variance/inverse-information identity, finite-controls versus fixed-efficiency precision, cancellation of assay scalars, artifact rescue and genuine departure, transport confounding, strict control and winner declarations, invalid counts/compositions, one-context interpretation, information failure, zero-cell/missing-arm declines, reproducible seeds and retained unresolved bootstrap draws.

From the inference directory, with Python 3.10+ and NumPy:

```sh
python3 make_synthetic_fixtures.py
python3 run_synthetic_validation.py
python3 -m unittest discover -s . -p 'test_recovery_control_inference.py' -v
python3 recovery_control_inference.py fixtures/recovery_artifact_shared_theta.json --bootstrap 199 --seed 20261001 --output RESULT.json
```

Future work should validate control transport independently, model uncertain r or fixed-input recovery when applicable, evaluate operating characteristics across plausible sparse/weak-effect scenarios, and lock an actual held-out observation protocol. Those tasks are prerequisites for biological interpretation and are not implied complete by these fixtures.
