#!/usr/bin/env python3
"""Four-arm recovery-control WS inference, prototype 0.3.0, NumPy only.

Copyright (c) 2026 Ricardo Maldonado. MIT; see LICENSE and VERSION_LINEAGE.md.
No zero-cell fit is attempted. A zero count does not prove a boundary MLE.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from _convex_multinomial import log_softmax, objective, minimize, saturated_loglik

ROUTES = ('W','A','M')
ARMS = ('baseline','selected','baseline_control','selected_control')
V = np.array([-.5,1.,-.5])


def validate_arrays(counts,r0,r1):
    raw = np.asarray(counts)
    if raw.ndim != 3 or raw.shape[1:] != (4,3) or len(raw) < 1:
        raise ValueError('Counts must have shape (contexts,4,3), at least one context')
    if any(isinstance(item,(bool,np.bool_)) for context in counts for arm in context for item in arm):
        raise ValueError('Booleans are not counts')
    if raw.dtype.kind not in 'iuf' or not np.all(np.isfinite(raw)):
        raise ValueError('Counts must be finite numeric integers')
    if np.any(raw < 0) or np.any(raw != np.floor(raw)) or np.any(raw > 2**52):
        raise ValueError('Counts must be nonnegative exactly representable integers')
    if np.any(raw.sum(axis=2) > 2**52):
        raise ValueError('Each sample total must be exactly representable')
    for r in (r0,r1):
        rr=np.asarray(r)
        if rr.shape != (len(raw),3) or rr.dtype.kind not in 'iuf':
            raise ValueError('Known compositions must have shape (contexts,3)')
        if not np.all(np.isfinite(rr)) or np.any(rr <= 0):
            raise ValueError('Known control compositions must be finite and strictly positive')
        if not np.allclose(rr.sum(axis=1),1.,rtol=0,atol=1e-10):
            raise ValueError('Known control compositions must sum to one')
    return np.asarray(counts,float),np.asarray(r0,float),np.asarray(r1,float)


def validate_document(doc):
    if not isinstance(doc,dict) or not isinstance(doc.get('metadata'),dict):
        raise ValueError('Input and metadata must be objects')
    meta=doc['metadata']
    for key in ('independent_all_four_arms','independent_replicates_across_contexts',
                'common_genetic_background','context_matched_calibration',
                'control_relative_recovery_transports','known_positive_control_compositions',
                'eligible_winner_observation_rule_locked'):
        if meta.get(key) is not True:
            raise ValueError(f'metadata.{key} must explicitly be true')
    if meta.get('calibration_design') != 'matched_route_multinomial':
        raise ValueError('Only validated matched route multinomial counts are supported; '
                         'pathway-isolated totals and fluctuation-culture colony totals are unsupported')
    if meta.get('calibration_validation') != 'validated_for_route_probability':
        raise ValueError('Explicit validation for route-probability calibration is required')
    if meta.get('control_sampling_design') != 'independent_random_mixture_conditional_recovery':
        raise ValueError('Controls require independent known random mixtures conditional on recovery; '
                         'fixed per-route input totals need a binomial recovery likelihood')
    if meta.get('triad_sampling') not in ('exhaustive_triad','conditioned_on_triad'):
        raise ValueError('Declare a common exhaustive_triad or conditioned_on_triad rule')
    if meta.get('provenance') not in ('synthetic','observed','literature_transcription'):
        raise ValueError('Explicit provenance is required')
    if doc.get('route_order') != list(ROUTES) or doc.get('arm_order') != list(ARMS):
        raise ValueError('Route and arm orders must match the documented schema')
    contexts=doc.get('contexts')
    if not isinstance(contexts,list) or not contexts or any(not isinstance(c,dict) for c in contexts):
        raise ValueError('Contexts must be a nonempty list of objects')
    names=[c.get('context') for c in contexts]
    if any(not isinstance(n,str) or not n for n in names) or len(set(names)) != len(names):
        raise ValueError('Context names must be nonempty and unique')
    counts=[[c.get(arm+'_counts') for arm in ARMS] for c in contexts]
    r0=[c.get('known_baseline_control_composition') for c in contexts]
    r1=[c.get('known_selected_control_composition') for c in contexts]
    counts,r0,r1=validate_arrays(counts,r0,r1)
    return names,counts,r0,r1


def design(r0,r1):
    """7C+1 linear logits plus the known-composition offset in selected A."""
    c=len(r0); d=7*c+1
    x=np.zeros((4*c,3,d)); offset=np.zeros((4*c,3))
    delta=(np.log(r1)-np.log(r0))@V
    for j in range(c):
        bw,ba,tw,a0w,a0a,a1w,a1a=range(7*j,7*j+7)
        x[4*j,0,bw]=x[4*j,1,ba]=1
        x[4*j+1,0,tw]=1
        x[4*j+1,1,[bw,ba,tw,a0w,a0a,a1w,a1a,d-1]]=[-.5,1,.5,.5,-1,-.5,1,1]
        x[4*j+2,0,a0w]=x[4*j+2,1,a0a]=1
        x[4*j+3,0,a1w]=x[4*j+3,1,a1a]=1
        offset[4*j+1,1]=-delta[j]
    return x,offset


def corrected_contrast(probabilities,r0,r1):
    p=np.asarray(probabilities,float)
    if p.ndim != 3 or p.shape[1:] != (4,3) or np.any(p <= 0) or not np.all(np.isfinite(p)):
        raise ValueError('Positive four-arm probabilities required for a logarithmic contrast')
    if not np.allclose(p.sum(axis=2),1.,rtol=0,atol=1e-10):
        raise ValueError('Each observed probability composition must sum to one')
    for r in (r0,r1):
        rr=np.asarray(r,float)
        if rr.shape!=(len(p),3) or not np.all(np.isfinite(rr)) or np.any(rr<=0) or not np.allclose(rr.sum(axis=1),1.,rtol=0,atol=1e-10):
            raise ValueError('Known control compositions must be positive probability simplexes')
    return (np.log(p[:,1])-np.log(p[:,0])-np.log(p[:,3])+np.log(r1)
            +np.log(p[:,2])-np.log(r0))@V


def contrast_variance(probabilities,totals):
    p=np.asarray(probabilities,float); totals=np.asarray(totals,float)
    if p.ndim != 3 or p.shape[1:] != (4,3) or totals.shape != p.shape[:2]:
        raise ValueError('Probability/total shapes mismatch')
    if not np.all(np.isfinite(p)) or not np.all(np.isfinite(totals)) or np.any(p <= 0) or np.any(totals <= 0):
        raise ValueError('Positive finite probabilities and totals required')
    if not np.allclose(p.sum(axis=2),1.,rtol=0,atol=1e-10):
        raise ValueError('Each probability composition must sum to one')
    components=np.sum(V*V/p,axis=2)/totals
    return components.sum(axis=1),components


def fit_recovery_bridge(counts,r0,r1,check_starts=True):
    counts,r0,r1=validate_arrays(counts,r0,r1)
    c=len(counts); y=counts.reshape(4*c,3)
    result={'schema_version':'0.3.0','regular_degrees_of_freedom':c-1,
            'alternative':'context-specific corrected theta; saturated four-arm multinomials',
            'loglik_saturated':saturated_loglik(y),'asymptotic_p_value':None}
    if np.any(counts.sum(axis=2)==0):
        result.update(status='missing_arm',inference_status='not_evaluable',
                      reason='Every context requires a positive total in all four independent arms')
        return result
    if np.any(counts==0):
        result.update(status='zero_cell_not_supported',inference_status='not_evaluable',
                      reason='Prototype declines zero-cell tables. Their null MLE may be finite or boundary; '
                             'neither is asserted without a validated boundary-face analysis')
        return result
    x,offset=design(r0,r1)
    diffs=np.concatenate((x[:,0]-x[:,2],x[:,1]-x[:,2]))
    rank=int(np.linalg.matrix_rank(diffs))
    result['design_rank']=rank
    if rank != x.shape[-1]:
        result.update(status='nonidentifiable',inference_status='not_evaluable')
        return result
    empirical=counts/counts.sum(axis=2)[:,:,None]
    odds=np.log(empirical[:,:,:2]/empirical[:,:,2,None])
    start=np.zeros(7*c+1)
    for j in range(c):
        start[7*j:7*j+7]=[odds[j,0,0],odds[j,0,1],odds[j,1,0],
                           odds[j,2,0],odds[j,2,1],odds[j,3,0],odds[j,3,1]]
    start[-1]=np.median(corrected_contrast(empirical,r0,r1))
    beta,diag=minimize(x,y,start,offset)
    checks=[diag]
    if check_starts:
        other,diag2=minimize(x,y,np.zeros_like(start),offset)
        checks.append(diag2)
        agree=diag2['converged'] and abs(objective(other,x,y,offset)[0]-objective(beta,x,y,offset)[0]) < 1e-8*(1+y.sum())
    else:
        agree=True
    if not diag['converged'] or not agree:
        result.update(status='optimizer_unresolved',inference_status='not_evaluable',optimizer_checks=checks)
        return result
    loss,_,hess=objective(beta,x,y,offset)
    try:
        eig=np.linalg.eigvalsh(hess)
        if not np.all(np.isfinite(eig)) or eig[0]<=0 or eig[-1]/eig[0]>1e14:
            raise np.linalg.LinAlgError('Numerically singular information')
        unit=np.zeros(len(beta)); unit[-1]=1
        variance=float(np.linalg.solve(hess,unit)[-1])
        if not math.isfinite(variance) or variance<=0:
            raise np.linalg.LinAlgError('Invalid variance')
    except np.linalg.LinAlgError:
        result.update(status='information_unresolved',inference_status='not_evaluable',optimizer_checks=checks)
        return result
    fitted=np.exp(log_softmax(x@beta+offset)).reshape(c,4,3)
    # Recover underlying route compositions. Absolute recovery efficiencies remain unidentified.
    log_q=np.log(fitted[:,0])+np.log(r0)-np.log(fitted[:,2])
    log_p=np.log(fitted[:,1])+np.log(r1)-np.log(fitted[:,3])
    q=np.exp(log_softmax(log_q)); p=np.exp(log_softmax(log_p))
    if np.any(fitted<=0) or np.any(q<=0) or np.any(p<=0):
        result.update(status='numerical_probability_underflow',inference_status='not_evaluable',
                      reason='Numerical precision cannot represent positive reconstructed probabilities')
        return result
    eta=.5*(log_p[:,0]-log_p[:,2]-log_q[:,0]+log_q[:,2])
    deviance=2*(result['loglik_saturated']+loss)
    if deviance < -1e-7*(1+y.sum()):
        result.update(status='optimizer_unresolved',inference_status='not_evaluable',reason='Violated model nesting')
        return result
    expected=fitted*counts.sum(axis=2)[:,:,None]
    per_context_variance,variance_components=contrast_variance(fitted,counts.sum(axis=2))
    result.update(status='interior',inference_status='estimable' if c>1 else 'not_evaluable',
                  theta=float(beta[-1]),eta=eta.tolist(),fitted_observed_probabilities=fitted.tolist(),
                  corrected_baseline_probabilities=q.tolist(),corrected_selected_probabilities=p.tolist(),
                  log_relative_baseline_recovery=(np.log(fitted[:,2])-np.log(r0)
                      -(np.log(fitted[:,2])-np.log(r0))[:,2,None]).tolist(),
                  log_relative_selected_recovery=(np.log(fitted[:,3])-np.log(r1)
                      -(np.log(fitted[:,3])-np.log(r1))[:,2,None]).tolist(),
                  loglik_null=-loss,deviance=max(0.,deviance),optimizer_checks=checks,
                  information_condition_number=float(eig[-1]/eig[0]),theta_standard_error_regular=math.sqrt(variance),
                  per_context_contrast_variance_regular=per_context_variance.tolist(),
                  contrast_variance_components_regular=variance_components.tolist(),
                  minimum_expected_count=float(expected.min()),sparse=bool(np.any(expected<5)),
                  identification_limit='Absolute recovery, opportunity flux and biological factorization are not identified')
    if c==1:
        result['reason']='One context identifies a descriptive corrected theta, but shared-theta constancy imposes no restriction'
    return result


def bootstrap_recovery_bridge(counts,r0,r1,replicates=199,seed=20261001):
    if not isinstance(replicates,int) or isinstance(replicates,bool) or replicates<1:
        raise ValueError('Positive integer bootstrap count required')
    counts,r0,r1=validate_arrays(counts,r0,r1)
    fit=fit_recovery_bridge(counts,r0,r1)
    if fit['inference_status']!='estimable':
        return {'status':'not_evaluable','fit':fit,'p_value':None}
    rng=np.random.default_rng(seed); probabilities=np.asarray(fit['fitted_observed_probabilities'])
    totals=counts.sum(axis=2); statistics=[]; exceed=0; unresolved={}
    tol=1e-9*max(1.,fit['deviance'])
    for _ in range(replicates):
        sampled=np.array([[rng.multinomial(int(total),prob)
                           for total,prob in zip(tc,pc)] for tc,pc in zip(totals,probabilities)])
        trial=fit_recovery_bridge(sampled,r0,r1,check_starts=False)
        if trial['status']!='interior':
            unresolved[trial['status']]=unresolved.get(trial['status'],0)+1
            continue
        stat=trial['deviance']; statistics.append(stat); exceed+=stat>=fit['deviance']-tol
    failures=sum(unresolved.values()); bounds=[(1+exceed)/(replicates+1),(1+exceed+failures)/(replicates+1)]
    return {'status':'resolved' if failures==0 else 'partially_unresolved','fit':fit,
            'replicates':replicates,'seed':seed,'exceedances':int(exceed),'unresolved_replicates':failures,
            'unresolved_reasons':unresolved,'bootstrap_statistics':statistics,
            'p_value':bounds[0] if failures==0 else None,'p_value_computational_bounds':bounds,
            'comparison_tolerance':tol,'monte_carlo_resolution':1/(replicates+1),
            'interpretation':'Estimated-null four-arm parametric bootstrap; approximate composite-null calibration. '
              'Unresolved draws are retained in computational bounds, not discarded. Bounds are not confidence intervals. '
              'A corrected nonrejection does not validate transportability or a biological mechanism.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path); parser.add_argument('--output',type=Path)
    parser.add_argument('--bootstrap',type=int,default=0); parser.add_argument('--seed',type=int,default=20261001)
    args=parser.parse_args()
    try:
        raw=args.input.read_bytes(); doc=json.loads(raw)
        names,counts,r0,r1=validate_document(doc)
        if args.bootstrap<0: raise ValueError('Bootstrap count cannot be negative')
        result=bootstrap_recovery_bridge(counts,r0,r1,args.bootstrap,args.seed) if args.bootstrap else fit_recovery_bridge(counts,r0,r1)
        result.update(schema_version='0.3.0',route_order=list(ROUTES),arm_order=list(ARMS),contexts=names,
                      metadata=doc['metadata'],input_sha256=hashlib.sha256(raw).hexdigest(),
                      known_baseline_control_compositions=r0.tolist(),known_selected_control_compositions=r1.tolist(),
                      provenance_warning='Synthetic fixtures are software checks, not biological evidence.' if doc['metadata']['provenance']=='synthetic' else
                      'Declarations and hashes do not authenticate observations or control transportability.')
        encoded=json.dumps(result,indent=2,allow_nan=False)+'\n'
        if args.output: args.output.write_text(encoded)
        else: print(encoded,end='')
    except (ValueError,TypeError,KeyError,OSError,np.linalg.LinAlgError) as exc:
        parser.exit(2,f'Invalid input or unresolved numerical analysis: {exc}\n')

if __name__=='__main__': main()
