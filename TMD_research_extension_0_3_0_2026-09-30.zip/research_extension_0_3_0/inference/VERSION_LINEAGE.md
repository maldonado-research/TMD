# Version lineage and license

The numerical primitives in `_convex_multinomial.py` are adapted from the project’s MIT-licensed 0.2.0 `inference/joint_ws_inference.py`: stabilized log-softmax, multinomial objective/gradient/Hessian, Newton line search, and saturated multinomial log likelihood. Copyright (c) 2026 Ricardo Maldonado. The complete MIT license is retained in `LICENSE`.

Version 0.3.0 adds known logit offsets and a different four-arm recovery-control design. It intentionally does not copy the 0.2.0 recession-cone procedure: any observed zero cell is explicitly unsupported here, without a claim that its MLE is necessarily infinite. It inherits no biological validation from earlier releases.

Runtime dependency: Python 3.10+ and NumPy. Entry point: `python recovery_control_inference.py INPUT.json --bootstrap 199 --output RESULT.json`. The companion `_convex_multinomial.py` must remain alongside the entry point. Direct API: `fit_recovery_bridge(counts,r0,r1)` and `bootstrap_recovery_bridge(counts,r0,r1,replicates,seed)`, with counts shaped (contexts,4,3) in baseline, selected, baseline-control, selected-control order and routes W,A,M. CLI metadata validation is separate; API users must enforce the observation contract.
