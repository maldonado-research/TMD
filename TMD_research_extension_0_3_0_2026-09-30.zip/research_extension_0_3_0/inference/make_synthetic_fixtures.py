"""Generate exact rational arithmetic fixtures only; no biological observations.
Copyright (c) 2026 Ricardo Maldonado. MIT; see LICENSE.
"""
from fractions import Fraction as F
from functools import reduce
from math import gcd,log
from pathlib import Path
import json

ROOT=Path(__file__).parent/'fixtures'
META={'provenance':'synthetic','independent_all_four_arms':True,
      'independent_replicates_across_contexts':True,'common_genetic_background':True,
      'context_matched_calibration':True,'control_relative_recovery_transports':True,
      'known_positive_control_compositions':True,'eligible_winner_observation_rule_locked':True,
      'calibration_design':'matched_route_multinomial','calibration_validation':'validated_for_route_probability',
      'control_sampling_design':'independent_random_mixture_conditional_recovery',
      'triad_sampling':'exhaustive_triad','description':'Exact rational arithmetic fixture; no sampled biological evidence.'}
ARMS=['baseline','selected','baseline_control','selected_control']

def normalize(x):
    total=sum(x); return [F(v)/total for v in x]

def observed(q,d): return normalize([a*b for a,b in zip(q,d)])

def exact_counts(p,multiplier=200):
    lcm=reduce(lambda a,b:a*b//gcd(a,b),(v.denominator for v in p))
    return [int(v*lcm)*multiplier for v in p]

def build_fixture(departure=False,scale0=F(1),scale1=F(1)):
    qw=[[1,2,1],[2,1,2],[1,1,3],[3,2,1]]
    eta=[F(1),F(2),F(1,2),F(1)]
    d0=[[F(1,2),F(1,2),F(1,2)],[F(1,4),F(1,2),F(1,2)],
        [F(1,2),F(1,4),F(1,2)],[F(1,2),F(1,2),F(1,4)]]
    d1=[[F(1,2),F(1,4),F(1,2)],[F(1,2),F(1,2),F(1,2)],
        [F(1,2),F(1),F(1,2)],[F(1,2),F(1,8),F(1,2)]]
    r0w=[[1,1,1],[1,2,3],[3,2,1],[1,3,2]]
    r1w=[[1,2,3],[2,1,2],[1,1,1],[3,1,2]]
    contexts=[]; truth=[]
    for c in range(4):
        q=normalize(qw[c]); axis=F(4) if departure and c==3 else F(2)
        p=normalize([q[0]*eta[c],q[1]*axis,q[2]/eta[c]])
        r0,r1=normalize(r0w[c]),normalize(r1w[c])
        dd0=[v*scale0 for v in d0[c]]; dd1=[v*scale1 for v in d1[c]]
        probs=[observed(q,dd0),observed(p,dd1),observed(r0,dd0),observed(r1,dd1)]
        row={'context':f'synthetic_recovery_context_{c+1}',
             'known_baseline_control_composition':[float(v) for v in r0],
             'known_selected_control_composition':[float(v) for v in r1]}
        row.update({arm+'_counts':exact_counts(prob) for arm,prob in zip(ARMS,probs)})
        contexts.append(row)
        truth.append({'q':[float(v) for v in q],'p':[float(v) for v in p],
                      'theta':log(float(axis)),'eta':log(float(eta[c])),
                      'd0':[float(v) for v in dd0],'d1':[float(v) for v in dd1]})
    return {'route_order':['W','A','M'],'arm_order':ARMS,'metadata':META.copy(),
            'generating_parameters':truth,'contexts':contexts}

if __name__=='__main__':
    ROOT.mkdir(exist_ok=True)
    for name,departure in [('recovery_artifact_shared_theta',False),('genuine_theta_departure',True)]:
        (ROOT/(name+'.json')).write_text(json.dumps(build_fixture(departure),indent=2)+'\n')
