"""Convex multinomial primitives adapted from TMD 0.2.0 (MIT).
Copyright (c) 2026 Ricardo Maldonado. See LICENSE and VERSION_LINEAGE.md.
0.3.0 adds fixed logit offsets; no pseudocounts enter the likelihood.
"""
import numpy as np

def log_softmax(v):
    z = v - np.max(v, axis=-1, keepdims=True)
    return z - np.log(np.sum(np.exp(z), axis=-1, keepdims=True))


def objective(beta, x, y, offset=None):
    lp = log_softmax(x @ beta + (0 if offset is None else offset))
    p = np.exp(lp)
    total = y.sum(axis=1)
    loss = -float(np.sum(y*lp))
    grad = np.einsum('gkd,gk->d', x, total[:,None]*p-y)
    mean = np.einsum('gk,gkd->gd', p, x)
    hess = (np.einsum('g,gk,gkd,gke->de', total,p,x,x)
            - np.einsum('g,gd,ge->de', total,mean,mean))
    return loss, grad, hess


def minimize(x, y, start, offset=None, max_iter=160):
    beta = start.copy()
    for iteration in range(max_iter):
        loss, grad, hess = objective(beta,x,y,offset)
        score = float(np.max(np.abs(grad)))
        # Absolute score tolerance, with a roundoff allowance for large totals.
        tolerance = max(1e-7, 2e-12*float(y.sum()))
        if score <= tolerance:
            return beta, {'converged':True,'iterations':iteration,'score_max':score,
                          'loss':loss,'hessian_min_eigenvalue':float(np.linalg.eigvalsh(hess)[0])}
        try:
            step = np.linalg.solve(hess,grad)
        except np.linalg.LinAlgError:
            return beta, {'converged':False,'reason':'singular Hessian','score_max':score}
        descent = float(grad@step)
        if not np.isfinite(descent) or descent <= 0:
            return beta, {'converged':False,'reason':'invalid Newton direction','score_max':score}
        factor = 1.
        for _ in range(60):
            candidate = beta-factor*step
            next_loss = objective(candidate,x,y,offset)[0]
            if np.isfinite(next_loss) and (next_loss <= loss-1e-4*factor*descent
                    or (abs(next_loss-loss) < 1e-11*(1+loss) and factor*descent < 1e-8)):
                beta = candidate
                break
            factor *= .5
        else:
            return beta, {'converged':False,'reason':'line search failed','score_max':score}
    return beta, {'converged':False,'reason':'iteration limit','score_max':score}


def saturated_loglik(y):
    out = 0.
    for row in y:
        positive = row > 0
        if row.sum():
            out += float(np.sum(row[positive]*np.log(row[positive]/row.sum())))
    return out

