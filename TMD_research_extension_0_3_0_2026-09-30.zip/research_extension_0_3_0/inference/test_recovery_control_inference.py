"""Independent arithmetic/derivative and behavioral tests; synthetic only."""
import copy
import math
from fractions import Fraction
from pathlib import Path
import unittest
from unittest.mock import patch
import numpy as np
from recovery_control_inference import (V,design,validate_document,validate_arrays,corrected_contrast,
    contrast_variance,fit_recovery_bridge,bootstrap_recovery_bridge)
from _convex_multinomial import objective,minimize,saturated_loglik,log_softmax
from make_synthetic_fixtures import build_fixture


def uncorrected_two_arm_lrt(counts):
    # Independent construction of the 0.2.0 two-arm model for this comparison.
    c=len(counts); x=np.zeros((2*c,3,3*c+1))
    for j in range(c):
        x[2*j,0,3*j]=1; x[2*j,1,3*j+1]=1
        x[2*j+1,0,3*j+2]=1
        x[2*j+1,1,[3*j,3*j+1,3*j+2,-1]]=[-.5,1,.5,1]
    y=counts[:,:2].reshape(2*c,3)
    beta,diag=minimize(x,y,np.zeros(3*c+1))
    assert diag['converged']
    return 2*(objective(beta,x,y)[0]+saturated_loglik(y))


class RecoveryBridgeTests(unittest.TestCase):
    def setUp(self):
        self.doc=build_fixture()
        _,self.counts,self.r0,self.r1=validate_document(self.doc)

    def test_noiseless_corrected_identity_and_latent_compositions(self):
        empirical=self.counts/self.counts.sum(axis=2)[:,:,None]
        # Direct route-wise product ratios; independent of the logit design.
        ratio=empirical[:,1]*self.r1*empirical[:,2]/(empirical[:,0]*empirical[:,3]*self.r0)
        theta=np.log(ratio[:,1]/np.sqrt(ratio[:,0]*ratio[:,2]))
        np.testing.assert_allclose(theta,math.log(2),atol=1e-14)
        np.testing.assert_allclose(corrected_contrast(empirical,self.r0,self.r1),theta,atol=1e-14)
        fit=fit_recovery_bridge(self.counts,self.r0,self.r1)
        self.assertEqual(fit['status'],'interior'); self.assertLess(fit['deviance'],1e-7)
        self.assertAlmostEqual(fit['theta'],math.log(2),places=9)
        self.assertEqual(fit['regular_degrees_of_freedom'],3)
        np.testing.assert_allclose(fit['corrected_baseline_probabilities'],[t['q'] for t in self.doc['generating_parameters']],atol=1e-10)
        np.testing.assert_allclose(fit['corrected_selected_probabilities'],[t['p'] for t in self.doc['generating_parameters']],atol=1e-10)
        np.testing.assert_allclose(fit['eta'],[t['eta'] for t in self.doc['generating_parameters']],atol=1e-10)

    def test_design_recovers_constraint_with_nonuniform_known_compositions(self):
        x,offset=design(self.r0,self.r1)
        beta=np.linspace(-.9,.8,x.shape[-1]); beta[-1]=.41
        probs=np.exp(log_softmax(x@beta+offset)).reshape(4,4,3)
        np.testing.assert_allclose(corrected_contrast(probs,self.r0,self.r1),.41,atol=1e-14)
        self.assertGreater(np.max(np.abs(offset)),.1)

    def test_gradient_and_hessian_independent_finite_differences(self):
        x,offset=design(self.r0[:2],self.r1[:2]); y=self.counts[:2].reshape(8,3)
        beta=np.linspace(-.3,.4,x.shape[-1]); h=1e-5
        _,grad,H=objective(beta,x,y,offset)
        numeric_grad=np.zeros_like(grad); numeric_H=np.zeros_like(H)
        for j in range(len(beta)):
            shift=np.eye(len(beta))[j]*h
            left=objective(beta-shift,x,y,offset); right=objective(beta+shift,x,y,offset)
            numeric_grad[j]=(right[0]-left[0])/(2*h)
            numeric_H[:,j]=(right[1]-left[1])/(2*h)
        np.testing.assert_allclose(grad,numeric_grad,rtol=1e-8,atol=1e-6)
        np.testing.assert_allclose(H,numeric_H,rtol=1e-8,atol=1e-6)
        self.assertGreater(np.linalg.eigvalsh(H).min(),0)

    def test_finite_control_uncertainty_matches_information(self):
        probs=self.counts/self.counts.sum(axis=2)[:,:,None]
        totals=self.counts.sum(axis=2)
        per_arm=np.sum(np.array([.25,1.,.25])/probs,axis=2)/totals
        expected_var=1/np.sum(1/per_arm.sum(axis=1))
        fit=fit_recovery_bridge(self.counts,self.r0,self.r1)
        self.assertAlmostEqual(fit['theta_standard_error_regular']**2,expected_var,places=11)
        v,components=contrast_variance(probs,totals)
        np.testing.assert_allclose(components,per_arm,atol=1e-14)
        enlarged=self.counts.copy(); enlarged[:,2:]*=10000
        big=fit_recovery_bridge(enlarged,self.r0,self.r1)
        fixed_var=1/np.sum(1/per_arm[:,:2].sum(axis=1))
        self.assertGreater(expected_var,fixed_var)
        self.assertGreater(big['theta_standard_error_regular']**2,fixed_var)
        self.assertAlmostEqual(big['theta_standard_error_regular']**2,fixed_var,delta=expected_var*1e-4)

    def test_assay_wide_unknown_scalars_cancel(self):
        scaled=build_fixture(scale0=Fraction(1,3),scale1=Fraction(1,5))
        _,counts,r0,r1=validate_document(scaled)
        np.testing.assert_array_equal(counts,self.counts)
        original=fit_recovery_bridge(self.counts,self.r0,self.r1)
        changed=fit_recovery_bridge(counts,r0,r1)
        self.assertEqual(original,changed)
        self.assertNotIn('absolute_recovery',original)

    def test_detection_artifact_uncorrected_rejects_corrected_rescues(self):
        self.assertGreater(uncorrected_two_arm_lrt(self.counts),100)
        result=bootstrap_recovery_bridge(self.counts,self.r0,self.r1,19,11)
        self.assertEqual(result['status'],'resolved')
        self.assertEqual(result['p_value'],1.)
        # This fixture establishes arithmetic rescue only, not valid biological transport.

    def test_genuine_departure_remains_detectable_after_correction(self):
        _,counts,r0,r1=validate_document(build_fixture(departure=True))
        result=bootstrap_recovery_bridge(counts,r0,r1,39,12)
        self.assertEqual(result['status'],'resolved')
        self.assertGreater(result['fit']['deviance'],20)
        self.assertEqual(result['exceedances'],0)
        self.assertEqual(result['p_value'],1/40)

    def test_transport_failure_is_still_confounding(self):
        # Actual sample route A recovers half as well as its selected-stage control.
        changed=self.counts.copy(); changed[0,1,1]/=2
        probs=changed/changed.sum(axis=2)[:,:,None]
        contrasts=corrected_contrast(probs,self.r0,self.r1)
        self.assertAlmostEqual(contrasts[0],0.,places=12)
        np.testing.assert_allclose(contrasts[1:],math.log(2),atol=1e-12)
        # Additional controls do not remove an unmeasured sample/control mismatch.

    def test_zero_cell_declined_without_boundary_claim(self):
        changed=self.counts.copy(); changed[0,0,0]=0
        result=fit_recovery_bridge(changed,self.r0,self.r1)
        self.assertEqual(result['status'],'zero_cell_not_supported')
        self.assertEqual(result['inference_status'],'not_evaluable')
        self.assertNotIn('theta',result)
        self.assertIn('may be finite or boundary',result['reason'])

    def test_missing_arm_declined(self):
        changed=self.counts.copy(); changed[1,2]=0
        self.assertEqual(fit_recovery_bridge(changed,self.r0,self.r1)['status'],'missing_arm')

    def test_one_context_descriptive_only(self):
        result=fit_recovery_bridge(self.counts[:1],self.r0[:1],self.r1[:1])
        self.assertEqual(result['inference_status'],'not_evaluable')
        self.assertEqual(result['regular_degrees_of_freedom'],0)
        self.assertAlmostEqual(result['theta'],math.log(2),places=9)

    def test_bootstrap_zero_draws_retained_as_unresolved(self):
        counts=np.full((2,4,3),2)
        uniform=np.full((2,3),1/3)
        result=bootstrap_recovery_bridge(counts,uniform,uniform,19,9)
        self.assertEqual(result['status'],'partially_unresolved')
        self.assertGreater(result['unresolved_replicates'],0)
        self.assertIsNone(result['p_value'])
        self.assertEqual(len(result['bootstrap_statistics'])+result['unresolved_replicates'],19)
        self.assertLess(result['p_value_computational_bounds'][0],result['p_value_computational_bounds'][1])

    def test_input_and_independence_declarations(self):
        for key in ('independent_all_four_arms','control_relative_recovery_transports',
                    'known_positive_control_compositions','eligible_winner_observation_rule_locked'):
            doc=copy.deepcopy(self.doc); doc['metadata'][key]=False
            with self.assertRaisesRegex(ValueError,key):validate_document(doc)
        doc=copy.deepcopy(self.doc); doc['metadata']['calibration_design']='fluctuation_colony_totals'
        with self.assertRaisesRegex(ValueError,'fluctuation'):validate_document(doc)
        doc=copy.deepcopy(self.doc); doc['metadata']['control_sampling_design']='fixed_per_route_spike_inputs'
        with self.assertRaisesRegex(ValueError,'binomial'):validate_document(doc)
        for known in (np.zeros_like(self.r0),np.full_like(self.r0,float('nan')),np.ones_like(self.r0)):
            with self.assertRaises(ValueError):validate_arrays(self.counts,known,self.r1)
        for value in (-1,.5,float('nan'),True):
            counts=self.counts.tolist(); counts[0][0][0]=value
            with self.assertRaises(ValueError):validate_arrays(counts,self.r0,self.r1)

    def test_information_failure_is_not_inference(self):
        with patch('recovery_control_inference.np.linalg.eigvalsh',return_value=np.array([-1.,1.])):
            result=fit_recovery_bridge(self.counts,self.r0,self.r1)
        self.assertEqual(result['status'],'information_unresolved')
        self.assertNotIn('theta',result)

    def test_public_contrast_helpers_require_probability_simplexes(self):
        probabilities=self.counts/self.counts.sum(axis=2)[:,:,None]
        with self.assertRaises(ValueError):corrected_contrast(probabilities*2,self.r0,self.r1)
        with self.assertRaises(ValueError):corrected_contrast(probabilities,self.r0*2,self.r1)
        with self.assertRaises(ValueError):contrast_variance(probabilities*2,self.counts.sum(axis=2))

    def test_fixed_seed_reproducible(self):
        a=bootstrap_recovery_bridge(self.counts,self.r0,self.r1,5,321)
        b=bootstrap_recovery_bridge(self.counts,self.r0,self.r1,5,321)
        self.assertEqual(a,b)

if __name__=='__main__':unittest.main(verbosity=2)
