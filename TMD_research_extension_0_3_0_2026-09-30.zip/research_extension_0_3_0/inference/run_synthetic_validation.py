"""Reproduce synthetic correction/uncorrected comparisons, never biological evidence.
Copyright (c) 2026 Ricardo Maldonado. MIT; see LICENSE and VERSION_LINEAGE.md.
The two-arm comparator reconstructs the 0.2.0 logit restriction on observed counts.
"""
from pathlib import Path
import json
import hashlib
import platform
import numpy as np
from _convex_multinomial import objective,minimize,log_softmax,saturated_loglik
from recovery_control_inference import V,validate_document,corrected_contrast,bootstrap_recovery_bridge

ROOT=Path(__file__).parent


def fit_uncorrected(counts):
    c=len(counts); y=np.asarray(counts)[:,:2].reshape(2*c,3)
    if np.any(y<=0): return {'status':'zero_cell_not_supported'}
    x=np.zeros((2*c,3,3*c+1))
    for j in range(c):
        x[2*j,0,3*j]=1; x[2*j,1,3*j+1]=1
        x[2*j+1,0,3*j+2]=1
        x[2*j+1,1,[3*j,3*j+1,3*j+2,-1]]=[-.5,1,.5,1]
    beta,diag=minimize(x,y,np.zeros(3*c+1))
    if not diag['converged']: return {'status':'optimizer_unresolved'}
    return {'status':'interior','theta':float(beta[-1]),
            'deviance':max(0.,2*(objective(beta,x,y)[0]+saturated_loglik(y))),
            'probabilities':np.exp(log_softmax(x@beta)).reshape(c,2,3).tolist()}


def bootstrap_uncorrected(counts,replicates,seed):
    fit=fit_uncorrected(counts)
    if fit['status']!='interior':return {'status':'not_evaluable','fit':fit,'p_value':None}
    rng=np.random.default_rng(seed); probs=np.asarray(fit['probabilities']); totals=counts[:,:2].sum(axis=2)
    exceed=0; unresolved=0; tol=1e-9*max(1.,fit['deviance'])
    for _ in range(replicates):
        # Only first two arms enter this intentionally uncorrected comparison.
        sample=np.array([[rng.multinomial(int(t),p) for t,p in zip(tc,pc)] for tc,pc in zip(totals,probs)])
        trial=fit_uncorrected(sample)
        if trial['status']!='interior': unresolved+=1
        else: exceed+=trial['deviance']>=fit['deviance']-tol
    bounds=[(1+exceed)/(replicates+1),(1+exceed+unresolved)/(replicates+1)]
    return {'status':'resolved' if not unresolved else 'partially_unresolved','fit':fit,
            'replicates':replicates,'seed':seed,'exceedances':int(exceed),'unresolved_replicates':unresolved,
            'p_value':bounds[0] if not unresolved else None,'p_value_computational_bounds':bounds}


def main():
    summary={'provenance':'synthetic','replicates_each':199,
             'python_version':platform.python_version(),'numpy_version':np.__version__,
             'code_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in
                ('recovery_control_inference.py','_convex_multinomial.py','run_synthetic_validation.py','make_synthetic_fixtures.py')},
             'interpretation':'Exact arithmetic fixtures and estimated-null bootstrap illustrations only. '
                'No biological evidence, nominal-size claim, exact-test claim or sample-size justification.',
             'fixtures':{}}
    for index,name in enumerate(('recovery_artifact_shared_theta','genuine_theta_departure')):
        raw=(ROOT/'fixtures'/(name+'.json')).read_bytes(); input_hash=hashlib.sha256(raw).hexdigest()
        doc=json.loads(raw)
        names,counts,r0,r1=validate_document(doc)
        empirical=counts/counts.sum(axis=2)[:,:,None]
        corrected=bootstrap_recovery_bridge(counts,r0,r1,199,20261001+index)
        uncorrected=bootstrap_uncorrected(counts,199,20261101+index)
        corrected.update(schema_version='0.3.0',input_sha256=input_hash,metadata=doc['metadata'],
                         contexts=names,route_order=doc['route_order'],arm_order=doc['arm_order'],
                         known_baseline_control_compositions=r0.tolist(),known_selected_control_compositions=r1.tolist(),
                         provenance_warning='Synthetic arithmetic fixture; not biological evidence.')
        (ROOT/'fixtures'/(name+'_result.json')).write_text(json.dumps(corrected,indent=2,allow_nan=False)+'\n')
        summary['fixtures'][name]={
            'input_file':name+'.json','input_sha256':input_hash,
            'generating_theta':[row['theta'] for row in doc['generating_parameters']],
            'uncorrected_empirical_theta':((np.log(empirical[:,1])-np.log(empirical[:,0]))@V).tolist(),
            'corrected_empirical_theta':corrected_contrast(empirical,r0,r1).tolist(),
            'corrected':{k:corrected[k] for k in ('status','replicates','seed','p_value','unresolved_replicates','p_value_computational_bounds')},
            'uncorrected':uncorrected}
        summary['fixtures'][name]['corrected'].update(theta=corrected['fit'].get('theta'),
            deviance=corrected['fit'].get('deviance'),theta_standard_error_regular=corrected['fit'].get('theta_standard_error_regular'))
    (ROOT/'fixtures/synthetic_comparison_summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    print(json.dumps({name:{kind:row[kind].get('p_value') for kind in ('uncorrected','corrected')}
                      for name,row in summary['fixtures'].items()},indent=2))

if __name__=='__main__':main()
