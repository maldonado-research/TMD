# Prospective recovery-control study: decisions to freeze before outcomes

This is a proposed statistical data contract, not an authenticated laboratory protocol, completed experiment or registered preregistration. The archive audit found no admissible new measured recovery data. Version 0.3.0 implements one narrow four-arm model; a laboratory must establish that its sampling process supports that model before data are admitted.

## 1. Define the biological claim and independent unit

Specify at least two contexts for a shared-contrast test; four prespecified contexts are preferable for a nontrivial stress test. Lock the Wsp/Aws/Mws route dictionary, common genetic background, exposure/history, observation time, classification method, excluded routes and whether the triad is exhaustive or conditioned upon. Record an independently generated biological unit and its batch/lineage identifier. Mutation opportunities, isolated endpoint genotypes, first detected events and first successful arrivals are different units and endpoints.

Lock the relation p ∝ q exp(theta × Aws_indicator + eta_context × (1,0,−1)), including which biological factors q and eta represent. Do not multiply in a detection, establishment or fitness factor already included in another term. A supported baseline q assay must estimate the relevant route probability independently of the selected outcomes, with a justified growth/mutation likelihood. Raw colonies from a fluctuation culture and pathway-isolated strain totals do not automatically meet this categorical contract.

Endpoint route counts can test the endpoint contrast only. They cannot establish independence between route and arrival time. Using the earlier time diagnostic requires separate, justified first-arrival measurements and censoring information.

## 2. Match and separate all four arms

For every context obtain independent samples for biological baseline, selected outcomes, baseline recovery controls and selected recovery controls. Lock the assay stages. A control added after extraction calibrates downstream processing only; it cannot measure whole-cell persistence, pre-extraction losses or evolutionary establishment. Match genotype representatives, concentration, matrix, processing stage, history, handling and time windows. Include more than one representative per route where feasible; a route label need not imply a single recovery coefficient.

Separate physical units and randomization do not necessarily remove shared-batch effects. Record blocks and perform a prespecified dependence assessment. This prototype rejects designs without explicit independence declarations; declarations are not evidence that independence is true. A hierarchical, clustered or paired likelihood is future work if batch correlations remain material.

## 3. Use the control design the implemented likelihood actually supports

The present control arm uses **randomized independent input route labels drawn with known composition r**, or an independently justified equivalent sampling scheme. A unit with input route i recovers with probability d_i; among independent recovered units, route probabilities are proportional to r_i d_i. Condition on the recovered total to obtain the multinomial likelihood. Input compositions r0 and r1 may differ across branches and contexts but must be known, strictly positive and independently documented. Preserve exposed and recovered totals for audit even though the conditional prototype does not estimate absolute recovery.

**Fixed numbers of introduced units for each route are a different design.** Independent recoveries would instead supply route-specific binomial successes/trials. Conditioning on total recovery does not generally turn those fixed-route counts into the multinomial likelihood used here. Likewise barcode amplification reads are not independent recovered cells. Do not feed either design into this tool; develop and validate the corresponding binomial or read-sampling observation model first. This release does not implement them.

If input mixture composition is estimated from noisy measurements, r is not known. Preserve those observations and propagate their uncertainty with an expanded likelihood or justified sensitivity bounds. Do not replace uncertain mixtures with exact numbers in the current model.

## 4. Challenge transfer before interpreting corrected biology

Use at least two independently randomized known compositions per branch in designated calibration/validation batches, with prespecified abundance and environmental-history variations. For a fixed route-relative recovery vector, control log odds relative to M minus input log odds relative to M should agree across mixtures. Fit recovery on calibration mixtures and predict the held-out mixture. Freeze tolerances, adequacy/power criteria, recovery failures and the number of checks before reading outcomes. Do not pool heterogeneous controls until invariance is justified.

This hold-out check challenges composition-dependent recovery. It does not prove that a reconstituted mixture transfers to evolving biological units. Define the domain over which transfer is defended, audit same-stage processing, and use biologically matched independent bridge controls if obtainable. Failed checks invalidate this observation model; they do not by themselves falsify TMD. Nonrejection with weak controls is not evidence of transportability.

Specify justified bounds on the **differential control-to-biological branch transport** for each route. Report results under exact transfer and increasingly conservative bounds. Arbitrary illustrative bounds cannot be described as measured. If no defensible bounds or transfer argument exist, report an assay-level corrected contrast only; biological theta remains unidentified.

## 5. Freeze inference, failure rules and prediction

Use the current four-arm joint likelihood only after the data contract is supported. Propagate uncertainty from every arm. This release conservatively declines any observed zero cell; this is a software support policy, not a theorem that a finite MLE is impossible. It also declines missing arms, unidentifiable/numerically unresolved fits and unsupported data designs. Do not add tiny counts to obtain a desired answer.

Choose sample sizes from pilot probabilities and real costs, then simulate the **actual planned design** across null, weak and practically important alternatives. Predeclare the statistic, bootstrap count/seed policy, threshold, minimum usable counts and computational failure handling. All four arms must be resampled; unresolved draws stay in computational p-value bounds. The included estimated-null bootstrap is approximate, not an exact finite-sample test. Example simulations in this release are debugging demonstrations and do not certify this laboratory design's size or power.

For a held-out biological context, lock its baseline/controls and any directional eta prediction using information independent of its selected outcomes. Fitting a free eta to the same held-out selected counts is a compatibility fit, not a fully prespecified route forecast. Compare predictive log scores with credible competing models under the same training and data access. Archive failed predictions and controls alongside successes.

## 6. Archive the evidence, not just the conclusion

Retain independent-unit records, all mixtures and failures, sampling/conditioning details, batch maps, exposure opportunity denominators, protocol version, known-r provenance, source hashes and blinded admission decisions. Label observed, literature-transcribed and synthetic inputs separately. Release only material cleared for public sharing. New data are the next bottleneck; additional mathematical flexibility cannot supply missing biological measurements.
