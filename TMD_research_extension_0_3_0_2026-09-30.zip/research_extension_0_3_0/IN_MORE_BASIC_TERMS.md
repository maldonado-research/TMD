# In More Basic Terms: could our measuring method fool us?

Imagine three kinds of marbles passing through a sorting machine. The machine catches most blue marbles but misses many red ones. If we count only what comes out, we might decide there were fewer red marbles to begin with. The mistake comes from the machine, not the marbles.

Mutation research can face a similar problem. Some genetic routes may be easier to recover, sequence or classify than others. A route can appear to become more common because biology favors it, because the assay sees it more easily, or because both happen together.

Our previous update showed how that can distort a TMD test. This update gives us a way to correct the distortion **when independent, well-matched controls are available**.

## What we need to count

We need four separate groups for each condition:

| Group | Its job |
|---|---|
| Biological baseline | Estimate the route mix before the selected outcome, using a valid independent assay. |
| Selected outcomes | Measure the route mix we want to explain. |
| Baseline recovery controls | Check which routes the baseline measurement tends to recover or miss. |
| Selected recovery controls | Check the same issue in the selected-outcome measurement. |

The control mixtures must have known starting compositions and a sampling design that matches the calculation. Their outcomes are measurements too, so we include their uncertainty. More sequencing reads from the same cells do not automatically count as more independent biological observations.

## What the calculation achieved

In one simulated example, the true biological contrast was the same in four conditions. Different recovery biases made it look very different. The corrected calculation recovered the shared value. In a second simulated example, one condition really did have a different contrast; correcting the assay did not erase that difference.

Those examples are useful because we know how they were constructed. They show that the method can separate the two effects under its assumptions. They are not experiments, and they do not show that TMD is true in nature.

## The next question is whether the controls really match

A laboratory mixture may behave differently from cells that have grown, competed and adapted. That difference matters. We now calculate how far the biological conclusion could move if the controls transfer imperfectly. If we cannot defend a match or a reasonable bound on the mismatch, the biological conclusion remains unresolved.

There is also a practical cost: ignoring control uncertainty can make an answer look too precise. In an equal-frequency planning example with 100 observations in each group, including both control groups increases the standard error by about 41% compared with pretending the controls were perfectly known. Better measurements can narrow that uncertainty; more confidence in an untested assumption cannot.

## What would move this research forward most?

The priority is a real study with independent baseline observations, matched recovery controls and a prediction locked before seeing a new condition's outcomes. We should challenge the controls with different known mixtures, keep failures, and compare predictions with competing explanations.

The progress here is a better measurement-aware test and a clearer experiment. It does not establish a new law of physics, explain every form of evolution, or demonstrate a prize-worthy discovery. It gives TMD a more demanding route to evidence.
