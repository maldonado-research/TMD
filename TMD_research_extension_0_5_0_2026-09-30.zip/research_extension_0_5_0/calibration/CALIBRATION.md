# Repeated-sample boundary-confidence diagnostic

This is a reproducible synthetic diagnostic for the frozen 0.5.0 boundary-confidence API at alpha 0.05. It retains 40 previously generated datasets and 120 new datasets. Reanalysis of the original 40 adds no new independent observations. There are no biological data, bootstrap draws, replacements or discarded cases.

| Scenario, 40 datasets each | Reject shared theta | Compatible, finite shared interval | Compatible, unbounded shared interval | Declined |
|---|---:|---:|---:|---:|
| Exact 0.4 high-recovery stress counts reused | 0 | 40 | 0 | 0 |
| New high-recovery shared-theta null | 0 | 40 | 0 | 0 |
| New high-recovery strong contextual departure | 40 | 0 | 0 | 0 |
| New low-recovery shared-theta stress | 0 | 0 | 40 | 0 |

“Compatible” means no shared-theta departure established; it is not an equivalence or mechanism claim. Rejection is classified first: an unbounded interval in one context can still exclude another context's interval and cause rejection. The records separately retain unbounded per-context intervals, shared-interval status and any decline exception. No decline occurred here.

Each dataset contains four contexts, two categorical branches, and three routes. Each route/branch control has exactly 100 introduced units. The new high-recovery categorical totals are 1200 per branch; the reused and low-recovery totals are 600. The unknown recovery efficiencies are estimated by the confidence procedure from fixed-input successes/trials; their generating values are recorded as simulation truth, not supplied as known parameters to inference.

For the new scenarios, baseline q is `(1/3,1/3,1/3)` in every context. Let the context tilt be `(1,2,1/2,1)`. Selected p is proportional to `q * (tilt, aws_weight, 1/tilt)`. The null uses aws_weight 2 everywhere; the departure uses 32 in the last context. Thus the exact rational target invariant `J=exp(2*theta)` is 4 in null contexts and 1024 in the departure's last context. Both branches have the same route-independent recovery: 99/100 in the high-recovery scenarios and 1/1000 in the low-recovery stress. Normalization therefore leaves their observed categorical probabilities unchanged. Exact rational probabilities, seed hierarchy and actual counts are saved in `sampled_counts.json`. NumPy receives double conversions of the rational targets; this is not an arbitrary-precision random sampler.

The reused input is an exact extraction of the original 0.4 `high_recovery_support_stress` scenario, preserved in `reused_high_recovery_counts.json`, with the original whole-input hash and historical fixture/runner hashes. Its 40 original data seeds and unused bootstrap seeds were regenerated from master seed 2026100104, scenario child 2, and both-child dataset hierarchy. All count tables match. Every dataset in that complete original cohort was declined by the 0.4 extreme-count policy; no selected subset or archived inference code was run. The new master seed is 2026100105: three scenario children, each spawning 40 dataset children. All 160 data seeds are distinct, and every count table was replayed.

Each simulated dataset uses independent multinomial branch samples and independent binomial controls, with exact recovery transport by construction. These assumptions describe the generator only. They do not authenticate an experimental exposed-unit definition, categorical calibration or biological recovery transfer.

Exact Fraction comparisons against the authoritative projected J bounds find all four true context invariants covered in 40/40 datasets in each scenario. Each individual context also has 40/40 coverage. Approximate 95% Wilson intervals for 0/40 rejection are 0–8.76%, and for 40/40 rejection or joint truth coverage are 91.24–100%. These describe the fixed generator's repeated-sampling uncertainty; they do not prove nominal size, certify power, or replace the conditional analytical coverage argument. The alternative's high rejection frequency concerns this deliberately strong departure only. Do not infer power dominance over 0.4 from these scenarios or compare unlike estimands.

The high-recovery cohorts contain respectively 325, 328 and 376 all-success controls out of 960 controls each. Their projected shared intervals are finite when compatible. The low-recovery cohort contains 871 zero-success controls, and four datasets have zero recoveries in all 24 controls. Zeros are observed outcomes with positive known denominators, not missing data or proof of zero population recovery. All 40 low-recovery shared intervals are unbounded: 39 span the entire real theta line; dataset index 31 retains a lower bound of approximately -19.1972 and has no upper bound. The distinction matters because “unbounded” does not always mean a wholly uninformative interval.

The implementation allocates 48 scalar intervals with exact per-tail error 1/1920, certifies outward CP endpoints using integer binomial tails, and compares the projected intersection with exact rational J arithmetic. This diagnostic checks stored decisions and membership rather than substituting rounded displayed theta limits. Its rectangular enclosure may be conservative; finite confidence under valid marginal laws is distinct from informative inference.

A one-record-per-scenario benchmark took 3.026 seconds. The full run took 120.146 seconds with bundled Python 3.12.14 and NumPy 2.3.5. The benchmark repeats four of the same records and does not add four datasets to the final sample. Source/input hashes were unchanged before and after the full run; the API hash matches its frozen receipt. `verify_calibration_results.py` independently imports neither runner nor inference, reproduces all 160 count tables and seed hierarchies, reconstructs the new generator algebra, recomputes the stored projected J bounds with a direct formula and checks decisions/coverage. It does not re-solve CP endpoints. Its checks pass and are recorded in `verification_receipt.json`; the separately authored independent review is a further audit.

From the extracted package root, run with Python and NumPy installed:

```sh
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python3 calibration/run_repeated_sample_calibration.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python3 calibration/verify_calibration_results.py
```

The runner's `--prepare-only` option replays and writes inputs without importing inference; `--benchmark` analyzes one record per scenario and writes separate benchmark results. The prior extraction is included, so the reproduction commands require no 0.4 package or network access. `artifact_hashes.json` records delivered artifact hashes relative to this calibration directory. Reproduction changes runtime fields and downstream file hashes; it should preserve count tables, exact interval/decision fields and scenario summaries with the recorded software versions.
