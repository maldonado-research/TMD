#!/usr/bin/env python3
"""Independent recorded-count and exact-ratio audit; imports neither inference nor runner.
Copyright (c) 2026 Ricardo Maldonado. MIT; see ../inference/LICENSE.
Does not rerun confidence endpoint calculations.
"""
from collections import Counter
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pairs_from_counts(generator, seed):
    rng = np.random.default_rng(seed)
    probs = np.asarray([[[float(F(v)) for v in r] for r in c] for c in generator['observed_probabilities_exact_rational']])
    ds = np.asarray([[[float(F(v)) for v in r] for r in c] for c in generator['control_efficiencies_exact_rational']])
    n = generator['categorical_total_each_branch']
    counts = [[rng.multinomial(n, row).tolist() for row in context] for context in probs]
    recovered = rng.binomial(np.full((4, 2, 3), 100, dtype=np.int64), ds).tolist()
    return counts, recovered


def direct_bounds(intervals):
    b, p = intervals['baseline'], intervals['selected']
    u, v = intervals['baseline_controls'], intervals['selected_controls']
    low = lambda row, i: F(row[i]['lower'])
    high = lambda row, i: F(row[i]['upper'])
    # Direct formula, separate from API's exponent dictionary/loop.
    lower = (low(p, 1)**2*low(b, 0)*low(b, 2)*low(v, 0)*low(v, 2)*low(u, 1)**2
             / (high(p, 0)*high(p, 2)*high(b, 1)**2*high(v, 1)**2*high(u, 0)*high(u, 2)))
    denominator = low(p, 0)*low(p, 2)*low(b, 1)**2*low(v, 1)**2*low(u, 0)*low(u, 2)
    upper = None if denominator == 0 else (
        high(p, 1)**2*high(b, 0)*high(b, 2)*high(v, 0)*high(v, 2)*high(u, 1)**2/denominator)
    return lower, upper


def main():
    counts_path = ROOT/'sampled_counts.json'
    results_path = ROOT/'repeated_sample_results.json'
    prior_path = ROOT/'reused_high_recovery_counts.json'
    counts, results, prior = [json.loads(p.read_text()) for p in (counts_path, results_path, prior_path)]
    for relative, expected in results['source_sha256'].items():
        assert digest(BASE/relative) == expected, relative
    assert results['benchmark_only'] is False
    assert counts['master_seed_new'] == 2026100105
    assert results['configuration']['alpha_exact'] == '0.05'
    assert results['configuration']['bootstraps'] == 0
    assert len(counts['scenarios']) == len(results['scenarios']) == 4
    reused_child = np.random.SeedSequence(prior['prior_master_seed']).spawn(3)[2].spawn(40)
    new_children = np.random.SeedSequence(2026100105).spawn(3)
    seed_lists = []
    for child in reused_child:
        a, b = child.spawn(2)
        seed_lists.append((int(a.generate_state(1, dtype=np.uint64)[0]), int(b.generate_state(1, dtype=np.uint64)[0])))
    new_seeds = [[int(child.generate_state(1, dtype=np.uint64)[0]) for child in scenario.spawn(40)] for scenario in new_children]
    seen = set()
    audit = []
    for si, (source, analysed) in enumerate(zip(counts['scenarios'], results['scenarios'])):
        assert source['scenario'] == analysed['scenario']
        generator = source['generator']
        assert generator == analysed['generator']
        assert len(source['records']) == len(analysed['records']) == 40
        if si:
            total = 600 if si == 3 else 1200
            recovery = F(1, 1000) if si == 3 else F(99, 100)
            weights = [F(2)]*3+[F(32) if si == 2 else F(2)]
            for ci, (tilt, weight) in enumerate(zip([F(1), F(2), F(1, 2), F(1)], weights)):
                q, p = generator['observed_probabilities_exact_rational'][ci]
                expected_p = [tilt, weight, 1/tilt]
                expected_p = [v/sum(expected_p) for v in expected_p]
                assert [F(x) for x in q] == [F(1, 3)]*3
                assert [F(x) for x in p] == expected_p
                assert all(F(x) == recovery for branch in generator['control_efficiencies_exact_rational'][ci] for x in branch)
            assert generator['categorical_total_each_branch'] == total
        status = Counter()
        covered_count = 0
        for i, (row, fit) in enumerate(zip(source['records'], analysed['records'])):
            expected_seed = seed_lists[i][0] if si == 0 else new_seeds[si-1][i]
            assert row['dataset_index'] == fit['dataset_index'] == i
            assert row['dataset_seed'] == fit['dataset_seed'] == expected_seed
            assert expected_seed not in seen
            seen.add(expected_seed)
            if si == 0:
                original = prior['scenario']['records'][i]
                assert original['dataset_seed'] == expected_seed
                assert row['prior_bootstrap_seed_not_used'] == original['bootstrap_seed'] == seed_lists[i][1]
                assert row['categorical_counts'] == original['categorical_counts']
                assert row['control_recovered_counts'] == original['control_recovered_counts']
                assert original['fit_admitted'] is False
            regenerated_counts, regenerated_controls = pairs_from_counts(generator, expected_seed)
            assert regenerated_counts == row['categorical_counts']
            assert regenerated_controls == row['control_recovered_counts']
            assert all(sum(branch) == generator['categorical_total_each_branch'] for context in row['categorical_counts'] for branch in context)
            status[fit['evaluation_status']] += 1
            if fit['evaluation_status'] == 'declined':
                assert fit['decision'] is None and fit['all_true_context_J_covered'] is None
                continue
            projection = fit['projection_result']
            assert projection['coordinates'] == 48
            assert F(projection['per_tail_error_exact']) == F(1, 1920)
            context_bounds = []
            coverage = []
            for ci, context in enumerate(projection['contexts']):
                intervals = context['marginal_intervals']
                for group in intervals.values():
                    for cell in group:
                        assert 0 <= cell['lower'] <= cell['upper'] <= 1
                        assert cell['status'] == 'certified'
                        assert all(cert['exact_tail_certified'] is True for cert in cell['certificates'])
                lo, hi = direct_bounds(intervals)
                assert F(context['J_lower_exact']) == lo
                assert (None if context['J_upper_exact'] is None else F(context['J_upper_exact'])) == hi
                truth = F(1024) if si == 2 and ci == 3 else F(4)
                coverage.append(lo <= truth and (hi is None or truth <= hi))
                context_bounds.append((lo, hi))
            assert coverage == fit['true_J_covered_by_context']
            assert all(coverage) == fit['all_true_context_J_covered']
            covered_count += all(coverage)
            shared = projection['shared_theta_intersection']
            lo = max(a for a, b in context_bounds)
            finite = [b for a, b in context_bounds if b is not None]
            hi = min(finite) if finite else None
            empty = hi is not None and lo > hi
            assert F(shared['J_lower_exact']) == lo
            assert (None if shared['J_upper_exact'] is None else F(shared['J_upper_exact'])) == hi
            assert shared['empty'] == empty
            unbounded = not empty and (lo == 0 or hi is None)
            expected_status = 'reject' if empty else ('compatible_unbounded' if unbounded else 'compatible_finite')
            assert fit['evaluation_status'] == expected_status
            assert fit['shared_interval_unbounded'] == unbounded
        summary = analysed['summary']
        assert all(summary['status_counts'][key] == status[key] for key in summary['status_counts'])
        assert summary['all_true_context_J_coverage_count'] == covered_count
        audit.append({'scenario': source['scenario'], 'records_replayed': 40,
                      'status_counts': dict(status), 'all_true_context_J_coverage_count': covered_count})
    assert len(seen) == 160
    receipt = {'scope': 'Independent seed/count replay, new generator algebra, stored exact-J projection and decision/coverage reconstruction; no endpoint re-solving and no biological validation.',
        'all_160_records_checked': True, 'all_160_dataset_seeds_distinct': True,
        'scenarios': audit,
        'sha256': {str(p.relative_to(BASE)): digest(p) for p in
                   (Path(__file__).resolve(), counts_path, results_path, prior_path, BASE/'inference/boundary_confidence.py')}}
    (ROOT/'verification_receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print('PASS: all160 seeds/counts, exact generator invariants, stored projected J bounds, decisions and coverage checks.', flush=True)


if __name__ == '__main__':
    main()
