# Independent calibration and public-claims review — TMD 0.5.0

**PASS.** Separately reviewed after the calibration agent declared its files frozen. No calibration-owned artifact, inference source, historical file or source archive was modified by this review. This file is the independent review receipt.

## Reproduction and provenance

An independently written replay imported neither the calibration runner nor its verifier. It reconstructed the original master-seed hierarchy (2026100104, third scenario child, 40 dataset children, data/bootstrap children) and the new hierarchy (2026100105, three scenario children, 40 dataset children each). All 160 distinct data seeds regenerated their saved multinomial and binomial counts exactly. Every categorical branch retained its prescribed total (600 for reused/low-recovery and 1,200 for new high-recovery); all 24 control denominators per dataset were 100. No subset selection, replacement, discarded dataset or bootstrap was used.

The portable reused scenario equals the ACTUAL original 0.4.0 `calibration/sampled_counts.json` high-recovery scenario, not merely its extraction receipt. Its original whole-input hash and all historical source/fixture hashes also match. Thus the 40 reused datasets are reanalysis of the complete original cohort, with no new independent observations implied. All 40 were declined by the older interior-count policy.

The new route probabilities were independently reconstructed from uniform baseline composition and tilts (1,2,1/2,1), with A weights 2 in null contexts and 32 in the strong departure's last context. Both branches use common route recovery 99/100 or 1/1000. An independent direct rational formula for the corrected invariant gives J=4 in null contexts and J=1024 in the alternative context. All inputs have positive population targets, known denominators and a justified fixed-route count model by synthetic construction. NumPy samples double conversions of these recorded exact rational targets; this is not an exact arbitrary-precision probability sampler or an empirical authentication of the scientific contract.

Beyond count replay, all 160 datasets were independently converted to strict API documents and submitted afresh to the frozen confidence kernel. Every FULL returned projection dictionary—including marginal endpoints/certificates, exact rational J bounds, displayed theta bounds and decisions—matches its stored result exactly. This independently reproduces endpoint computation and results; it is not a second independent implementation of the confidence kernel. The separate exact-tail oracle and mathematical audit address that kernel's mathematical checks. The fresh replay took approximately 121.4 seconds in the recorded Python/NumPy environment.

## Decisions, coverage and failure accounting

For every record, exact Fraction membership of the recorded true J targets was recomputed. Shared intersections and decisions used rational bounds, rather than displayed logarithms. Rejection precedes the unbounded classification. Control-zero/all-success totals, per-context unbounded flags, shared-interval flags, retained denominators, coverage summaries, Wilson intervals and frozen hashes were independently checked. No decline occurred and every summary denominator remains 40.

| Scenario | Retained | Reject | Finite compatible | Unbounded compatible | Declined | All four target J covered |
|---|---:|---:|---:|---:|---:|---:|
| Reused original high-recovery cohort | 40 | 0 | 40 | 0 | 0 | 40 |
| New high-recovery shared contrast | 40 | 0 | 40 | 0 | 0 | 40 |
| New strong contextual departure | 40 | 40 | 0 | 0 | 0 | 40 |
| New low-recovery shared contrast | 40 | 0 | 0 | 40 | 0 | 40 |

All-success control totals are 325, 328 and 376 in the three high-recovery cohorts, respectively. The low-recovery cohort has 871 observed zero-success controls, including four datasets with all 24 controls zero. Its shared intervals are unbounded in all 40 cases; 39 cover the entire real theta line, while index 31 has a finite lower endpoint and no upper endpoint. No pseudocount, manufactured finite estimate or missing-as-zero substitution is present.

Rebuilt approximate Wilson summaries agree exactly: 0/40 gives [0,0.0876216012], and 40/40 gives [0.9123783988,1]. These are generator-specific sampling summaries, not certified power, a proof of size, or biological validation. The conditional finite-sample error bound comes from the marginal confidence/union/projection argument. Nonrejection, particularly with an unbounded interval, does not establish common theta. No P value or boundary likelihood result is inferred.

## Public explanations

Reviewed `README.md`, `SCIENTIFIC_PROGRESS.md`, `IN_MORE_BASIC_TERMS.md` and `design/ALL_SUCCESS_CONTROL_PRECISION.md`. The contrast sign, twelve coordinates per context, Bonferroni allocation, fixed-sample scope, positive population requirement with d=1 permitted, dependence qualification, one-context limitation, relative transport and lack of biological authentication are correctly stated. The analytic all-success recovery half-width is 2 log(24C/alpha)/L; the docs correctly distinguish ideal roots from certified conservative dyadic software approximations and from total biological-plus-control uncertainty.

Two initially incorrect reproduction paths were corrected by the root agent to the actual fixture and runner. The root also added the ideal-root approximation qualification. The final explanations distinguish limited synthetic detection frequencies from universal power/coverage claims and note that a one-sided unbounded interval can remain informative. No remaining mathematical/scientific correction was identified. Publication status is reviewed as a reserved identifier, not asserted publication confirmation.

## Frozen hash receipt

The calibration manifest excludes this independently authored file. All eight manifest entries, the source hashes in results and the independently generated verification receipt were rebuilt from final files and match. The following hashes identify the reviewed calculation and counts:

```json
{
  "inference/boundary_confidence.py": "23feb7547d481fc4d361b25da28fe9d46d79be2f9fe66376f9c9ca85c069c79d",
  "calibration/run_repeated_sample_calibration.py": "6210bcd33fab71ad4a21fc1022b99aee6903af4ef163ba5581e7879c7192d9c3",
  "calibration/repeated_sample_results.json": "509783c2a67bf70e590b3daca4b7f9706cf4c9a6b578a5e4e318e47939dd819f",
  "calibration/sampled_counts.json": "97947ee377f706455325f24994d81678d59c70b3b9f32ca39185f6bc5711e441",
  "calibration/reused_high_recovery_counts.json": "bca589343ec0ad8231c6e9c57f79957b7c9142855f76a32174d1528ae7036f58",
  "calibration/CALIBRATION.md": "9ab6959253b783cf76145cf00ea78f65b8b712d00818da9773e029ff71ab70c5",
  "calibration/artifact_hashes.json": "e716074c61d301c595e7993b64ebc454a2c73a1db8f771c1d1e4c7fa6c43eef6",
  "calibration/verification_receipt.json": "87dfe2a7d5eb3f8bd588ece31cbf625d3ab70a6c0eba198002a567b91d8835b8"
}
```

Release-builder receipt: PASS. The four benchmark records also match the corresponding full-run records after excluding elapsed timing. All 39 full-real low-recovery intersections and the single index-31 one-sided intersection were checked directly.

- `inference/boundary_confidence.py`: `23feb7547d481fc4d361b25da28fe9d46d79be2f9fe66376f9c9ca85c069c79d`
- `calibration/run_repeated_sample_calibration.py`: `6210bcd33fab71ad4a21fc1022b99aee6903af4ef163ba5581e7879c7192d9c3`
- `calibration/verify_calibration_results.py`: `e3ad3386e1598f64187a1e3518eb5a5330b9974a88ab0f16020bbea0fc10bf21`
- `calibration/reused_high_recovery_counts.json`: `bca589343ec0ad8231c6e9c57f79957b7c9142855f76a32174d1528ae7036f58`
- `calibration/sampled_counts.json`: `97947ee377f706455325f24994d81678d59c70b3b9f32ca39185f6bc5711e441`
- `calibration/benchmark_results.json`: `3a1998db2a01c164a9bfa152a3319058652bfdec34c98f03bb1cc2ad5485281f`
- `calibration/repeated_sample_results.json`: `509783c2a67bf70e590b3daca4b7f9706cf4c9a6b578a5e4e318e47939dd819f`
- `calibration/verification_receipt.json`: `87dfe2a7d5eb3f8bd588ece31cbf625d3ab70a6c0eba198002a567b91d8835b8`
- `calibration/CALIBRATION.md`: `9ab6959253b783cf76145cf00ea78f65b8b712d00818da9773e029ff71ab70c5`
- `calibration/artifact_hashes.json`: `e716074c61d301c595e7993b64ebc454a2c73a1db8f771c1d1e4c7fa6c43eef6`
