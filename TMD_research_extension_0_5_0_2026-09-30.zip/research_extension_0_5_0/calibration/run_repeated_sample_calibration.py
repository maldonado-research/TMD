#!/usr/bin/env python3
"""Synthetic repeated sampling for frozen 0.5 boundary confidence projection.
Copyright (c) 2026 Ricardo Maldonado. MIT; see ../inference/LICENSE.
Reuses 40 prior synthetic datasets and retains all new datasets and API failures.
"""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
MASTER_SEED = 2026100105
DATASETS = 40
ALPHA = '0.05'
TILTS = [F(1), F(2), F(1, 2), F(1)]
NEW_SCENARIOS = (
    ('new_high_recovery_shared_theta', 1200, F(99, 100), False),
    ('new_high_recovery_strong_departure', 1200, F(99, 100), True),
    ('new_low_recovery_shared_theta_stress', 600, F(1, 1000), False),
)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def wilson(k, n):
    if not n:
        return None
    z = 1.959963984540054
    p = k/n
    den = 1 + z*z/n
    center = (p + z*z/(2*n))/den
    half = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))/den
    return [max(0., center-half), min(1., center+half)]


def normalize(values):
    total = sum(values)
    return [v/total for v in values]


def exact_j(probabilities, efficiencies):
    """Independent algebraic generator invariant; no inference helper used."""
    result = []
    for branches, ds in zip(probabilities, efficiencies):
        q, p = [normalize([v/d for v, d in zip(row, dd)]) for row, dd in zip(branches, ds)]
        result.append(p[1]**2*q[0]*q[2]/(p[0]*p[2]*q[1]**2))
    return result


def float_array(values):
    return np.array([[[float(v) for v in row] for row in context] for context in values])


def rational_array(values):
    return [[[str(v) for v in row] for row in context] for context in values]


def new_generator(total, recovery, departure):
    q = [F(1, 3)]*3
    weights = [F(2)]*3 + [F(32) if departure else F(2)]
    latent = [[q[:], normalize([q[0]*tilt, q[1]*weight, q[2]/tilt])]
              for tilt, weight in zip(TILTS, weights)]
    ds = [[[recovery]*3 for _ in range(2)] for _ in range(4)]
    observed = [[normalize([v*d for v, d in zip(row, dd)])
                 for row, dd in zip(context, dc)] for context, dc in zip(latent, ds)]
    truth = exact_j(observed, ds)
    assert truth == [F(4)]*3 + [F(1024) if departure else F(4)]
    return {
        'observed_probabilities_exact_rational': rational_array(observed),
        'latent_baseline_selected_exact_rational': rational_array(latent),
        'control_efficiencies_exact_rational': rational_array(ds),
        'introduced_each_route_branch': [[[100]*3 for _ in range(2)] for _ in range(4)],
        'categorical_total_each_branch': total,
        'eta_tilt_by_context_exact': [str(v) for v in TILTS],
        'aws_weight_by_context_exact': [str(v) for v in weights],
        'generating_J_exact': [str(v) for v in truth],
        'generating_theta_description': 'ln(2) in all contexts' if not departure else 'ln(2) in contexts 1–3; ln(32) in context 4',
        'sampling_law': 'Independent NumPy multinomial branches and independent binomial introduced-unit controls. Exact rational target probabilities converted to IEEE double for NumPy sampling; not an arbitrary-precision random sampler.',
        'transport_assumption': 'Exact by construction; recovery constant across routes and both branches. Synthetic declarations do not authenticate biological transfer.',
    }


def sample_counts(generator, seed):
    probs = float_array([[[F(v) for v in row] for row in c]
                         for c in generator['observed_probabilities_exact_rational']])
    ds = float_array([[[F(v) for v in row] for row in c]
                      for c in generator['control_efficiencies_exact_rational']])
    L = np.array(generator['introduced_each_route_branch'], dtype=np.int64)
    total = generator['categorical_total_each_branch']
    rng = np.random.default_rng(seed)
    counts = np.array([[rng.multinomial(total, p) for p in context] for context in probs])
    recovered = rng.binomial(L, ds)
    assert np.all(counts.sum(axis=2) == total)
    assert np.all((recovered >= 0) & (recovered <= L))
    return counts.tolist(), recovered.tolist()


def replay_reused(receipt):
    scenario = receipt['scenario']
    generator = dict(scenario['generator'])
    generator['categorical_total_each_branch'] = 600
    probs = [[[F(v) for v in row] for row in c]
             for c in generator['observed_probabilities_exact_rational']]
    ds = [[[F(v) for v in row] for row in c]
          for c in generator['control_efficiencies_exact_rational']]
    assert exact_j(probs, ds) == [F(4)]*4
    generator['generating_J_exact'] = ['4']*4
    generator['sampling_law'] = 'Original 0.4 NumPy sampling stream replayed independently; targets recorded as exact rationals and converted to double.'
    seeds = np.random.SeedSequence(receipt['prior_master_seed']).spawn(3)[receipt['prior_scenario_child_index']].spawn(40)
    records = scenario['records']
    assert len(records) == 40
    for index, (child, row) in enumerate(zip(seeds, records)):
        data_child, bootstrap_child = child.spawn(2)
        seed = int(data_child.generate_state(1, dtype=np.uint64)[0])
        unused_bootstrap = int(bootstrap_child.generate_state(1, dtype=np.uint64)[0])
        assert row['dataset_index'] == index
        assert row['dataset_seed'] == seed and row['bootstrap_seed'] == unused_bootstrap
        counts, recovered = sample_counts(generator, seed)
        assert counts == row['categorical_counts']
        assert recovered == row['control_recovered_counts']
        assert row['passes_supported_cell_policy'] is False and row['fit_admitted'] is False
    return generator, records


def prepare_inputs():
    receipt_path = ROOT/'reused_high_recovery_counts.json'
    receipt = json.loads(receipt_path.read_text())
    generator, prior_records = replay_reused(receipt)
    scenarios = [{
        'scenario': 'reused_0_4_high_recovery_support_stress',
        'sampling_relationship': 'Exactly the 40 recorded 0.4 high-recovery support-stress datasets; reanalysis, not new independent data.',
        'generator': generator,
        'records': [{key: row[key] for key in ('dataset_index', 'dataset_seed', 'categorical_counts', 'control_recovered_counts')}
                    | {'prior_bootstrap_seed_not_used': row['bootstrap_seed'], 'prior_fit_admitted': False}
                    for row in prior_records],
    }]
    all_seeds = {row['dataset_seed'] for row in prior_records}
    scenario_children = np.random.SeedSequence(MASTER_SEED).spawn(3)
    for spec, child in zip(NEW_SCENARIOS, scenario_children):
        label, total, recovery, departure = spec
        generator = new_generator(total, recovery, departure)
        scenario = {'scenario': label, 'sampling_relationship': 'New independent synthetic datasets; separate SeedSequence scenario child.',
                    'generator': generator, 'records': []}
        for index, dataset_child in enumerate(child.spawn(DATASETS)):
            seed = int(dataset_child.generate_state(1, dtype=np.uint64)[0])
            assert seed not in all_seeds
            all_seeds.add(seed)
            counts, recovered = sample_counts(generator, seed)
            scenario['records'].append({'dataset_index': index, 'dataset_seed': seed,
                'categorical_counts': counts, 'control_recovered_counts': recovered})
        scenarios.append(scenario)
    # Independent deterministic replay of every new record from its saved seed.
    for scenario in scenarios[1:]:
        for row in scenario['records']:
            counts, recovered = sample_counts(scenario['generator'], row['dataset_seed'])
            assert counts == row['categorical_counts'] and recovered == row['control_recovered_counts']
    return receipt, scenarios


def document(scenario, row):
    routes = ('W', 'A', 'M')
    contexts = []
    L = scenario['generator']['introduced_each_route_branch']
    for c in range(4):
        context = {'context': f'synthetic_context_{c+1}'}
        for j, branch in enumerate(('baseline', 'selected')):
            context[branch+'_counts'] = dict(zip(routes, row['categorical_counts'][c][j]))
            context[branch+'_recovery_controls'] = {
                route: {'introduced': L[c][j][i], 'recovered': row['control_recovered_counts'][c][j][i]}
                for i, route in enumerate(routes)}
        contexts.append(context)
    metadata = {key: True for key in (
        'categorical_multinomial_marginals_justified', 'route_control_binomial_marginals_justified',
        'common_genetic_background', 'context_matched_calibration', 'control_relative_recovery_transports',
        'eligible_winner_observation_rule_locked', 'positive_population_components_for_log_contrast')}
    metadata.update(provenance='synthetic', control_sampling_design='fixed_route_independent_binomial',
        control_outcome_definition='one_binary_recovery_per_introduced_unit',
        exposed_unit_definition='Independently simulated traceable route-labelled introduced unit with one Bernoulli recovery outcome.',
        calibration_design='matched_route_multinomial', calibration_validation='validated_for_route_probability',
        triad_sampling='exhaustive_triad')
    return {'metadata': metadata, 'route_order': list(routes), 'branch_order': ['baseline', 'selected'], 'contexts': contexts}


def analyse_record(api, scenario, row):
    start = time.monotonic()
    L = scenario['generator']['introduced_each_route_branch']
    controls = [(k, n) for kc, nc in zip(row['control_recovered_counts'], L)
                for kr, nr in zip(kc, nc) for k, n in zip(kr, nr)]
    output = {key: row[key] for key in ('dataset_index', 'dataset_seed')}
    output.update(control_zero_cells=sum(k == 0 for k, n in controls),
                  control_all_success_cells=sum(k == n for k, n in controls),
                  all_24_controls_zero=all(k == 0 for k, n in controls))
    try:
        result = api(document(scenario, row), alpha=ALPHA)
        covered = []
        unbounded_contexts = []
        for i, (context, truth) in enumerate(zip(result['contexts'], scenario['generator']['generating_J_exact'])):
            lo = F(context['J_lower_exact'])
            hi = None if context['J_upper_exact'] is None else F(context['J_upper_exact'])
            assert hi is None or lo <= hi
            covered.append(lo <= F(truth) and (hi is None or F(truth) <= hi))
            if lo == 0 or hi is None:
                unbounded_contexts.append(i)
        intersection = result['shared_theta_intersection']
        unbounded_shared = not intersection['empty'] and (F(intersection['J_lower_exact']) == 0 or intersection['J_upper_exact'] is None)
        rejected = result['decision'] == 'reject_shared_theta'
        status = 'reject' if rejected else ('compatible_unbounded' if unbounded_shared else 'compatible_finite')
        output.update(evaluation_status=status, decision=result['decision'],
            true_J_covered_by_context=covered, all_true_context_J_covered=all(covered),
            unbounded_context_indices=unbounded_contexts, shared_interval_unbounded=unbounded_shared,
            projection_result=result)
    except (ValueError, TypeError, KeyError, ArithmeticError, OSError) as exc:
        output.update(evaluation_status='declined', decision=None, true_J_covered_by_context=None,
            all_true_context_J_covered=None, shared_interval_unbounded=None,
            decline_exception=type(exc).__name__, decline_reason=str(exc))
    output['elapsed_seconds'] = time.monotonic()-start
    return output


def summarize(records):
    n = len(records)
    statuses = Counter(row['evaluation_status'] for row in records)
    declined = statuses['declined']
    evaluated = n-declined
    covered = sum(row['all_true_context_J_covered'] is True for row in records)
    rejected = statuses['reject']
    return {
        'datasets_retained': n,
        'status_counts': {key: statuses[key] for key in ('reject', 'compatible_finite', 'compatible_unbounded', 'declined')},
        'compatible_means': 'Shared theta departure not established; not equivalence or mechanism confirmation.',
        'datasets_with_any_unbounded_context': sum(bool(row.get('unbounded_context_indices')) for row in records),
        'datasets_with_all_24_controls_zero': sum(row['all_24_controls_zero'] for row in records),
        'control_zero_cells_total': sum(row['control_zero_cells'] for row in records),
        'control_all_success_cells_total': sum(row['control_all_success_cells'] for row in records),
        'evaluated_datasets': evaluated,
        'reject_fraction_among_evaluated': rejected/evaluated if evaluated else None,
        'reject_wilson_95_among_evaluated': wilson(rejected, evaluated),
        'all_true_context_J_coverage_count': covered,
        'all_true_context_J_coverage_count_bounds_if_declined': [covered, covered+declined],
        'all_true_context_J_coverage_wilson_95_among_evaluated': wilson(covered, evaluated),
        'true_J_coverage_counts_by_context': [sum(row['true_J_covered_by_context'][c] for row in records if row['true_J_covered_by_context'] is not None) for c in range(4)],
        'uncertainty_limit': 'Wilson summaries concern this fixed synthetic generator and are approximate binomial intervals, not the formal CP projection coverage theorem or certified power. Declines remain separate. Reused data are not new observations.',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare-only', action='store_true', help='Replay and save inputs without importing/running inference.')
    parser.add_argument('--benchmark', action='store_true', help='Analyze first record of each scenario only; does not replace final results.')
    args = parser.parse_args()
    start = time.monotonic()
    receipt, scenarios = prepare_inputs()
    input_output = {'schema_version': '0.5.0', 'provenance': 'synthetic only; 40 reused plus 120 new datasets',
        'master_seed_new': MASTER_SEED, 'datasets_new_per_scenario': DATASETS,
        'numpy_version': np.__version__, 'prior_input_sha256': receipt['prior_input_sha256'],
        'reused_input_sha256': sha256(ROOT/'reused_high_recovery_counts.json'), 'scenarios': scenarios}
    (ROOT/'sampled_counts.json').write_text(json.dumps(input_output, indent=2, allow_nan=False)+'\n')
    print('All 40 reused seed streams and 120 new seed streams replayed; 160 input records retained.', flush=True)
    if args.prepare_only:
        return
    source_paths = [Path(__file__).resolve(), BASE/'inference/boundary_confidence.py',
                    ROOT/'reused_high_recovery_counts.json', ROOT/'sampled_counts.json']
    hashes = {str(path.relative_to(BASE)): sha256(path) for path in source_paths}
    sys.path.insert(0, str(BASE/'inference'))
    from boundary_confidence import simultaneous_confidence
    output = {'schema_version': '0.5.0', 'provenance': 'synthetic repeated sampling and explicitly reused 0.4 counts only',
        'purpose': 'Limited finite-confidence calibration/stress diagnostic; no empirical biological validation or certified power claim.',
        'configuration': {'alpha_exact': ALPHA, 'new_master_seed': MASTER_SEED, 'datasets_each_scenario': DATASETS,
                          'contexts': 4, 'scalar_CP_coordinates': 48, 'control_trials_each_route_branch': 100,
                          'bootstraps': 0, 'replacement_policy': 'No replacements or discarded unresolved datasets.'},
        'software': {'python': platform.python_version(), 'numpy': np.__version__},
        'source_sha256': hashes, 'prior_whole_input_sha256': receipt['prior_input_sha256'],
        'historical_prior_source_sha256': receipt['prior_source_sha256'],
        'replay_checks': {'all_40_reused_counts_and_seed_pairs_match': True, 'all_120_new_counts_replayed': True, 'all_160_dataset_seeds_distinct': True},
        'benchmark_only': args.benchmark, 'scenarios': []}
    for scenario in scenarios:
        selected = scenario['records'][:1] if args.benchmark else scenario['records']
        analysed = []
        for row in selected:
            analysed.append(analyse_record(simultaneous_confidence, scenario, row))
            if len(analysed) % 10 == 0:
                print(f'{scenario["scenario"]}: {len(analysed)}/{len(selected)} retained', flush=True)
        output['scenarios'].append({'scenario': scenario['scenario'],
            'sampling_relationship': scenario['sampling_relationship'], 'generator': scenario['generator'],
            'records': analysed, 'summary': summarize(analysed)})
    for relative, expected in hashes.items():
        assert sha256(BASE/relative) == expected, f'Source or input changed during run: {relative}'
    output['elapsed_seconds'] = time.monotonic()-start
    path = ROOT/('benchmark_results.json' if args.benchmark else 'repeated_sample_results.json')
    path.write_text(json.dumps(output, indent=2, allow_nan=False)+'\n')
    print(json.dumps({s['scenario']: s['summary'] for s in output['scenarios']}, indent=2), flush=True)
    print(f'Elapsed seconds: {output["elapsed_seconds"]:.3f}', flush=True)


if __name__ == '__main__':
    main()
