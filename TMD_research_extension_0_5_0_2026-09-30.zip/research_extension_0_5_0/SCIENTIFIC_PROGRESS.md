# Scientific progress: an all-success control is still information

Methods extension 0.5.0, 30 September 2026. Ricardo Maldonado, with AI-assisted development and independent internal review.

## The practical limitation

The 0.4.0 joint likelihood supports interior categorical and control counts. With recovery .99 and 100 introduced units per control, its policy is expected to decline almost every four-context dataset because at least one control contains only successes. Its planning floors address software eligibility, rather than proving those discarded observations carry no information.

We now add a confidence procedure that can retain that information without claiming to solve the full boundary likelihood. Clopper-Pearson intervals admit observed zeros and all-success counts. A control with L successes from L known trials has bounds [a^(1/L),1], where a is its allocated tail error. A zero-success control has a zero lower bound and a positive upper bound. Neither case justifies replacing the observed count or treating the underlying probability as known exactly.

## A conditional finite-sample falsifier

Each context contributes twelve marginal probabilities: baseline and selected route compositions plus route-specific recovery in both branches. Applying marginal two-sided error alpha/(12C) gives joint coverage at least 1-alpha by Bonferroni. Dependence among multinomial coordinates does not invalidate this union bound; the appropriate binomial marginal laws are still necessary.

The recovery-corrected contrast is theta=v·[log(t)-log(b)-log(d1)+log(d0)], v=(-1/2,1,-1/2). Sign-aware projection of the simultaneous rectangle gives an interval per context. Under a shared finite theta, those intervals must intersect whenever the rectangle covers the true parameters. Empty intersection therefore has null rejection probability at most alpha, for a prespecified fixed-sample procedure under its sampling and recovery-transfer assumptions.

The implementation certifies each accepted CP endpoint with exact integer tail arithmetic. It compares projected J=exp(2theta) bounds as rational numbers, avoiding logarithm-rounding errors in the decision. This supplies a defensible computational certificate within the declared count/context domain. It does not certify physiological transfer or the validity of a count ledger. CP, Bonferroni and interval arithmetic are established methods; no external mathematical priority is claimed.

The rectangle ignores composition-sum constraints, so overlap is a conservative inability to rule out a shared contrast, rather than proof that an admissible shared model exists. No p-value, maximum-likelihood estimate, profile interval or equivalence claim follows from this procedure. One context cannot test cross-context sharing.

## All-success precision, with an honest denominator

When all six controls in a context recover all L introduced independent units, their contribution alone has interval half-width 2 log(24C/alpha)/L. At C=4, alpha=.05 and L=100, the lower recovery bound is approximately .92719 and the correction-only half-width is .15120. Biological sampling uncertainty must still be included.

This is a conditional observed-table calculation. It does not guarantee all units will recover or prescribe power. It shows why the previous L=643 interior-policy floor was not an information-theoretic requirement. A likelihood method and this interval method have different strengths and conservativeness; neither is asserted to dominate all designs.

These formulas describe the ideal CP roots. The implementation returns certified conservative dyadic outer approximations, which can be slightly wider; the formula is not an identity for its binary endpoints.

An all-failure control instead leaves at least one log-contrast endpoint unbounded. That limit is retained. A one-sided unbounded interval can still be disjoint from another context: unbounded does not automatically mean uninformative. Unknown introduced totals, missing biological records and structural true zeros must not be disguised as ordinary measured zeros.

## What the synthetic checks found

The fixed-alpha study retains all 160 datasets in four deliberately limited scenarios, with no replacement or bootstrap. Forty are exact reanalyses of the earlier 0.4.0 high-recovery stress counts; 120 are newly generated counts. Each dataset has four contexts and six control cells per context, each with 100 known trial units.

| Synthetic scenario | Datasets | Shared-contrast rejections | Interval status |
| --- | ---: | ---: | --- |
| Reused 0.4.0 high-recovery shared contrast | 40 | 0 | Finite and compatible |
| New high-recovery shared contrast | 40 | 0 | Finite and compatible |
| New strong contrast departure | 40 | 40 | Departure distinguished |
| New low-recovery stress | 40 | 0 | Compatible and unbounded |

All 160 datasets were evaluated, and all four true per-context J values were covered in each dataset. These are sampled software checks, not a proof of universal coverage or power. The finite-sample rejection bound instead follows from the conditional mathematical argument. A rejection frequency of 0/40 has a descriptive Wilson 95% interval of 0 to 8.76%; 40/40 has 91.24 to 100%. Low-recovery nonrejection reflects uncertainty, not confirmed constancy. The strong departure was intentionally large; this does not establish sensitivity to small biological effects.

Thirteen unit tests pass. Independent exact-arithmetic audit checks also examine endpoint certificates, binomial tails, a rational probability grid and rectangular projection corners. Their source hashes and counts are recorded in the included receipts. No numerical test establishes control-to-biology transport or authenticates a real count ledger.

## Evidence discipline

The targeted archive review recovered an older defective CP inversion and prior warnings about missing cells being filled with zero and posterior quantiles being labeled confidence intervals. Those historical files remain read-only references. The current implementation uses the correct tail inequalities and an explicit simultaneous-coverage argument; prior interval language alone does not establish frequentist coverage.

Three additional substantive papers and official statistical references sharpen boundary-confidence and control-unit assumptions. Whole-cell versus DNA spike measurements and single-cell isolation studies show why molecular yields and well denominators cannot automatically become independent recovered-cell trials. Their measured findings and our design consequences are separated in the attributed literature notes. No raw third-party data were downloaded or analyzed in this update, and no matched W/A/M control panel was admitted.

The useful next empirical step remains a fixed-sample, independently justified route panel with known control exposures, binary endpoints, culture/batch lineage, and held-out tests of relative recovery transfer. Route-specific control mismatch remains confounded with biology. The procedure tests a conditional shared contrast, rather than identifying mutation supply, establishment or a new physical law.
