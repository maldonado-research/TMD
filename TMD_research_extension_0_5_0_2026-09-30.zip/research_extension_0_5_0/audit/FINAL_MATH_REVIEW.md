# Final independent mathematical review, TMD 0.5.0

**Outcome: pass; no required changes identified.** Review corresponds to the frozen kernel, source SHA256 `23feb7547d481fc4d361b25da28fe9d46d79be2f9fe66376f9c9ca85c069c79d`. Sources, methods, test suite, deterministic examples and the analytic all-success note were inspected read-only. Companion `FINAL_REVIEW_RECEIPT.json` and `EXACT_BINOMIAL_ORACLE_RECEIPT.json` record verification and source hashes.

## Required and optional findings

Required fixes: none.

Optional future work: prospective validation of the marginal sampling laws and relative recovery transport remains necessary before biological interpretation. Tighter regions respecting categorical simplex constraints could increase information, but the current rectangle is deliberately conservative and valid. Neither extension is required for this release's stated mathematical/software claims. No priority is claimed for CP inversion, Beta quantiles, Bonferroni or monotone interval arithmetic.

## Independently checked argument

Each context supplies twelve binomial marginals: three observed baseline route probabilities, three selected route probabilities and six fixed-route control probabilities. Individual categorical coordinates have valid binomial marginals even though they are dependent. With exact rational per-tail error tau=alpha/(24C), CP lower endpoints solve P_l(X>=k)=tau for k>0 and upper endpoints P_u(X<=k)=tau for k<n. Boundary conventions l=0 at k=0, u=1 at k=n and [0,1] at n=0 are correct. Equivalent Beta shapes are (k,n-k+1) and (k+1,n-k), distinct from a uniform-prior posterior interval.

The accepted floating endpoints satisfy exact integer inequalities P_l(X>=k)<=tau and P_u(X<=k)<=tau. Tail monotonicity therefore proves that they enclose the ideal nominal CP roots. They are conservative outer approximations, not numerically exact copies of the mathematical roots. The direct integer recurrence, integer divisibility, shorter-tail complements, and exact rational comparison have correct signs and thresholds. Invalid proposal accuracy may widen a result, including an explicit support-boundary fallback, but cannot narrow a certified accepted bound. A final floating nextafter alone would not have supplied this guarantee; here exact tail certificates supply it.

The correction theta=v·(log t-log b-log d1+log d0), v=(-1/2,1,-1/2), cancels context normalizers and nuisance s=(1,0,-1). Thus J=exp(2theta) equals t_A²*b_W*b_M*d1_W*d1_M*d0_A² divided by t_W*t_M*b_A²*d1_A²*d0_W*d0_M. Code exponents and numerator/denominator endpoint selection agree. Positive upper probability bounds avoid undefined denominator divisions. A zero numerator lower bound gives J_lower=0; a zero denominator lower bound gives unbounded J_upper. Ignoring simplex constraints widens the region, preserving coverage.

On simultaneous component coverage, every true finite J lies in its projected interval. The union bound gives probability at least 1-alpha without requiring independence among coordinates, arms or contexts. Under a shared finite contrast, their intervals must intersect on that event. The exact rational strict comparison max(lower)>min(upper) therefore has false-rejection probability at most alpha under the count laws and transfer assumptions. Touching bounds are compatible. A separation as small as 1/10^100 is decided rationally rather than rounded away. Decimal/float theta displays do not drive the decision; their directed rational enclosure, adjacent logarithm step and outward conversion are consistent with display enclosures.

This theorem addresses prespecified contexts, alpha, totals and analysis. It does not justify optional stopping or selected reported contexts. Positive population components are required for finite log targets; observed zeros remain valid outcomes. Actual structural zeros require another target/model. Absolute control recovery does not identify absolute biological branch-scale recovery. Metadata declarations and hashes do not authenticate sampling, provenance or transport. Overdispersion, misclassification and unknown denominators are not repaired by the construction. No P value, mechanism validation, likelihood fit or equivalence conclusion is returned.

## Boundaries, design and examples

An all-success control has ideal interval [tau^(1/L),1], hence finite log range [log(tau)/L,0]. Six equal-denominator all-success controls contribute a correction-only interval [-2log(24C/alpha)/L,+2log(24C/alpha)/L]. The design note's C=4, alpha=.05, L=100 values .9271862611 and .1512016093 are correct. Its ceiling formula for a desired conditional observed-table half-width is correct. It is explicitly conditional on the realized all-success table, not a power calculation or a universal sample-size/design ranking. The 0.4 interior-policy floor 643 is correctly distinguished from an information requirement.

An all-failure control gives a zero lower probability bound and at least one unbounded contrast side. A one-sided unbounded interval can still reject a shared contrast when disjoint from another context; only a completely unbounded interval lacks individual comparison restriction. The methods correctly preserve this distinction. Missing counts and denominators are rejected rather than converted to observed zeros. A known zero categorical total is explicitly no observations, giving full probability support and an uninformative contrast.

All six saved synthetic results reproduce exactly from frozen code in memory. The all-success null gives both intervals approximately [-.858894,.858894]. The strong departure yields a second interval [2.717251,5.180998] and rejection. The observed-zero categorical example yields [3.966368,+infinity] versus the finite null interval and can reject. The complete all-failure/no-data examples remain [-infinity,+infinity]. A single context remains descriptive. These are deterministic arithmetic examples, not independent biological evidence or repeated-sampling power estimates.

## Independent execution

Bundled Python 3.12.14 ran all 13 production tests successfully (0.886s). They include independent exact-tail enumeration, small-binomial coverage, deliberately bad root proposals, malformed inputs, endpoint nesting, signs, display enclosures, boundary behavior and a dependent-component shared-null experiment with valid marginals.

A separately owned oracle uses direct Fraction PMF sums rather than the production recurrence: 468 accepted endpoint certificates, 3,240 tail comparisons, 756 exhaustive count-outcome coverage calculations for n=1..12 at 21 rational population values and three prespecified tail allocations, 4,096 rectangular corner projections, two signed-zero projections, six saved fixture reproductions and two exact touching/separation checks all passed. The minimum grid coverage was 95860758147/100000000000 for n=11, p=3/10, per-tail=1/40, above the corresponding .95 lower bound. These finite checks supplement the analytic proof; they do not prove performance over every parameter configuration or validate biological assumptions.

## Frozen reviewed hashes

- `inference/boundary_confidence.py`: `23feb7547d481fc4d361b25da28fe9d46d79be2f9fe66376f9c9ca85c069c79d`
- `inference/test_boundary_confidence.py`: `23502c43ffe5f6330f235f92998ec964195854fe7b7e3f1a48d97ec35344e95e`
- `inference/make_synthetic_fixtures.py`: `75ea9e0180019d063eb00833ade62583e9800a157e8050523d316e82a18ffa48`
- `inference/run_synthetic_validation.py`: `687de8593441aaf8e29edd1d92788a1fa1e7fee1531fbff54b53310b4e5b1d37`
- `inference/VERSION_LINEAGE.md`: `85bf5ca772b2bc502b0ce3ac6659c3c59909c73416dc42171d41dcdb4ad84aaf`
- `methods/BOUNDARY_CONFIDENCE_PROJECTION.md`: `3526c11074af53acf0d0296a9b82d561951b3653038fa8387f9c2cdee2b1507c`
- `design/ALL_SUCCESS_CONTROL_PRECISION.md`: `ac1e1087fa8a5414f95dcccb817eec8fab0a083f4aee1564ecee014585371f1d`
- `inference/results/synthetic_summary.json`: `d787d2325cfa704f58309a12063991638e3e93a893557b065d66fc8de0ff808e`
