# Boundary interval audit, 0.5.0

Status: independent mathematical derivation and targeted reference audit complete. Final implementation review and frozen-source hashes are recorded in [FINAL_MATH_REVIEW.md](FINAL_MATH_REVIEW.md). The current kernel adds exact dyadic endpoint certificates and rational decisions; see the implementation qualification below. No biological measurements were generated or recovered by this audit.

## Independent construction

For C prespecified contexts, each context has twelve marginal probabilities: three coordinates each of baseline b, selected t, baseline control recovery d0, and selected control recovery d1. With fixed categorical sample totals M,N and fixed introduced control totals L, every coordinate count has a Binomial(total, probability) marginal. Categorical coordinates are dependent; this does not invalidate their individual binomial marginals.

Choose overall alpha in (0,1), marginal noncoverage delta=alpha/(12C), and tail level a=delta/2. For k successes in n>0 trials, the two-sided Clopper–Pearson bounds are

- lower=0 if k=0, otherwise BetaQuantile(a;k,n-k+1);
- upper=1 if k=n, otherwise BetaQuantile(1-a;k+1,n-k).

These shape parameters differ from the Beta(k+1,n-k+1) uniform-prior posterior. The standard frequentist coverage is at least 1-delta, often greater because counts are discrete. The binomial-inversion procedure is established mathematics; a new TMD projection does not make CP or Beta quantiles a novel discovery. [NIST exact binomial documentation](https://www.itl.nist.gov/div898/software/dataplot/refman1/auxillar/propconf.htm) describes the inversion.

Let v=(-1/2,1,-1/2). Under the same route-relative transport assumption used in 0.4, the corrected contrast is

theta_c = v·log(t_c) - v·log(b_c) - v·log(d1_c) + v·log(d0_c).

Thus the four coefficient vectors are v,-v,-v,v for t,b,d1,d0 respectively. For a positive coefficient w, use w*log(lower) for its lower contribution and w*log(upper) for its upper contribution. For negative w, reverse the interval endpoints. Use log(0)=-infinity as an extended endpoint; never introduce pseudocounts or probability floors. Lower contributions can be finite or -infinity only; upper contributions finite or +infinity only, so properly constructed sums do not require undefined infinity cancellation. Intersecting the marginal rectangle with simplex constraints could tighten bounds, but ignoring those constraints is conservative.

This projects the simultaneous rectangle to an interval [ell_c,u_c]. The theorem targets finite contrasts with positive underlying b,t,d0,d1 coordinates (d can equal one). A zero observed count is allowed; a structurally zero true coordinate makes the finite log-contrast undefined and requires a different biological model. Boundary rectangle endpoints denote limiting bounds over positive probabilities.

By the union bound, all 12C marginal intervals contain their true probabilities with probability at least 1-alpha. No independence among coordinates or among intervals is required for this step. On that event every true finite theta_c lies in its projected interval. Under a shared-theta null, all projected intervals therefore intersect. Rejecting only when max_c ell_c > min_c u_c has false-rejection probability at most alpha. Equality is compatible, not rejection. This is one prespecified simultaneous fixed-sample decision; repeated looks, data-selected contexts, or a data-selected alpha need further adjustment.

The guarantee requires correct binomial marginals: fixed totals or a valid explicitly conditioned sampling model, and genuine known denominators. Overdispersion, unknown denominators, preferential sampling, misclassification, and failure of relative control-to-biological transport are not repaired by Bonferroni. The test addresses the stated shared corrected-contrast model, not biological mechanism identification. Nonrejection does not establish constancy.

## Boundary and numerical implications

For an all-success control k=n, lower=a^(1/n)>0 and upper=1, so its log contribution is finite. Hence datasets refused by an interior-likelihood fit solely because of all-success controls can still yield useful finite intervals. For an all-failure control k=0, lower=0 and upper=1-a^(1/n); the log range is unbounded below, giving at least one unbounded contrast endpoint. Different signed zero cells can make both endpoints infinite. No claim that every boundary dataset becomes informative is warranted.

Stable all-failure upper evaluation uses -expm1(log(a)/n); all-success log(lower) is log(a)/n. An implementation must distinguish the exact nominal theorem from floating-point beta inversion. Root bracketing, CDF monotonicity, endpoints, outward rounding, and endpoint underflow need explicit tests; a successful floating computation is not a certified coverage proof. An outward final nextafter alone does not certify all inversion/log/arithmetic errors. A numerical comparison tolerance may conservatively delay rejection but cannot justify advertising certified exact arithmetic. Extreme supported-input restrictions or explicit numerical failure are preferable to silently replacing tiny positive probabilities by zero.

The current 0.5 implementation addresses this concern directly: floating roots only propose endpoints. For a proposed lower endpoint l it checks the exact rational binomial upper tail P_l(X>=k)<=a; for an upper endpoint u it checks the exact rational lower tail P_u(X<=k)<=a. Monotonicity implies l is no larger and u no smaller than the nominal CP endpoints. All accepted endpoints are thus certified conservative bounds, including any explicit support-boundary fallback. Integer arithmetic compares each dyadic float endpoint to the exact rational tail allocation. Rational J=exp(2theta) products and comparisons determine intersection emptiness without logarithmic rounding. Decimal log enclosures are displayed only. Consequently the floating-proposal caveat is not a limitation on the accepted endpoints' coverage guarantee in this kernel; the prior warning applies to uncertified alternatives and display-only arithmetic. This distinction will also be checked in final release wording.

## Targeted archive findings

The portable inventory records seven file/member hashes with source labels rather than private absolute paths. The earlier 918-file fixed-input audit was reused. This audit inspected three selected small ZIP members in memory and did not extract or execute archive contents.

1. `TMD_ARCHIVE/old mutation files/untitled folder 39/TMD_breakthrough_v1_3/g3_evidence_calculator.py`: the historical CP function scans p upward from zero until CDF(k-1)>=alpha/2, and downward from one until CDF(k)<=1-alpha/2. These directions do not implement the required roots. `TMD_VECTOR_STORE/TMD_Research_Handoff_and_100_Explore_Questions.md`, lines 1032–1046, independently records this defect. This is a relevant implementation warning, not a reference implementation.
2. `TMD_VECTOR_STORE/TMD_Architect_Master_Handoff_and_100_Explore_Questions.md`, lines 889–895: CP is already named and explicitly distinguished from uniform-prior posterior quantiles; full conventions were absent from the recovered historical source. The new work should claim a corrected implementation and model-specific application.
3. `TMD_VECTOR_STORE/TMD_Architect_Research_Handoff_and_100_Explore_Questions_2026-09-08.md`, line 6983: an earlier analysis filled missing cells with zero. Missing input must remain distinct from a measured zero count in this release. Line 6898 also warns that marginal endpoint ratio constructions need a simultaneous-coverage argument; the new Bonferroni argument supplies that missing qualification for this different model.
4. `TMD_ARCHIVE/untitled folder 193/TMD_H482R_interval_decision_pack_2026-03-10.zip!/TMD_H482R_interval_decision_theorem_note_v0_1_2026-03-10.md`: prior deterministic interval-sum and cap decisions exist. They lack a calibrated sampling construction and recovery-control observations.
5. `TMD_ARCHIVE/untitled folder 215/TMD_rpoB_interval_tightening_pack_2026-03-29.zip!/TMD_interval_tightening_resilience_and_component_fragility_note_v0_1_2026-03-29.md`: “coverage” is coverage of a target by provisional mechanistic intervals, not frequentist confidence coverage. Do not conflate the meanings.
6. `TMD_ARCHIVE/untitled folder 204/TMD_H482R_adaptive_count_selector_pack_2026-03-25.zip!/TMD_H482R_adaptive_count_selector_and_dev_replicate_note_v0_1_2026-03-25.md`: proposed adaptive Gaussian planning uses 1.96 with a one-sided95 label. It is planning material, not fixed-sample CP evidence; sequential stopping also needs separate treatment.

No suitable new measured baseline/selected/control dataset was found in these selected materials. This negative result is scoped, not proof that unavailable sources or other archives contain none. The useful extension is a boundary-tolerant, explicitly calibrated model-level falsifier with a numerical implementation caveat; it remains a method awaiting suitable observations.
