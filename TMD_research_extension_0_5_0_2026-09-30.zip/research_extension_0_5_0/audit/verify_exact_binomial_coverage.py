"""Independent small-n oracle: direct rational PMFs, no production recurrence."""
from fractions import Fraction
from math import comb
from pathlib import Path
import hashlib
import importlib.util
import json
from itertools import product
import sys

sys.dont_write_bytecode=True

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'inference/boundary_confidence.py'
spec=importlib.util.spec_from_file_location('reviewed_boundary',SOURCE)
kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)

def pmf(n,k,p):
    return Fraction(comb(n,k))*p**k*(1-p)**(n-k)

def tail(n,k,p,upper):
    support=range(k,n+1) if upper else range(k+1)
    return sum((pmf(n,j,p) for j in support),Fraction(0))

def main():
    certificates=coverage_cases=tail_cases=0
    worst=Fraction(1);worst_case=None
    # Include exact boundary populations; the binomial intervals remain valid
    # there although the complete finite-log contrast requires positivity.
    populations=[Fraction(j,20) for j in range(21)]
    for n in range(1,13):
        for a in [Fraction(1,40),Fraction(1,480),Fraction(1,1920)]:
            intervals=[kernel.clopper_pearson(k,n,a) for k in range(n+1)]
            for k,ci in enumerate(intervals):
                lo,hi=Fraction(ci['lower']),Fraction(ci['upper'])
                assert 0<=lo<=hi<=1
                if k:
                    assert tail(n,k,lo,True)<=a
                    certificates+=1
                if k<n:
                    assert tail(n,k,hi,False)<=a
                    certificates+=1
                for p_float in [0.,.0625,.25,.5,.875,1.]:
                    p=Fraction(p_float)
                    for upper in [True,False]:
                        numerator,denominator=kernel.exact_tail(n,k,p_float,upper)
                        assert Fraction(numerator,denominator)==tail(n,k,p,upper)
                        tail_cases+=1
            for p in populations:
                coverage=sum((pmf(n,k,p) for k,ci in enumerate(intervals)
                              if Fraction(ci['lower'])<=p<=Fraction(ci['upper'])),Fraction(0))
                assert coverage>=1-2*a
                coverage_cases+=1
                if coverage<worst:worst=coverage;worst_case=dict(n=n,p=str(p),tail_error=str(a))
    groups=['baseline','selected','baseline_controls','selected_controls']
    rectangle={g:[dict(lower=.125,upper=.5),dict(lower=.25,upper=.75),dict(lower=.5,upper=1.)] for g in groups}
    _,projected_lo,projected_hi=kernel.project_context(rectangle)
    corner_values=[]
    for corner in product([0,1],repeat=12):
        values=[]
        for j,g in enumerate(groups):
            values.append([Fraction(rectangle[g][i]['upper' if corner[3*j+i] else 'lower']) for i in range(3)])
        b,t,d0,d1=values
        # Independently form exp(2theta) from the contrast identity.
        J=(t[1]**2/(t[0]*t[2]))*(b[0]*b[2]/b[1]**2)*(d0[1]**2/(d0[0]*d0[2]))*(d1[0]*d1[2]/d1[1]**2)
        corner_values.append(J)
    assert projected_lo==min(corner_values) and projected_hi==max(corner_values)
    rectangle['baseline_controls'][1]['lower']=0.
    _,zero_lo,zero_hi=kernel.project_context(rectangle)
    assert zero_lo==0 and zero_hi is not None
    rectangle['baseline_controls'][0]['lower']=0.
    _,zero_lo,zero_hi=kernel.project_context(rectangle)
    assert zero_lo==0 and zero_hi is None
    reproduced_fixtures=0
    source_hash=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    for fixture in sorted((ROOT/'inference/fixtures').glob('*.json')):
        raw=fixture.read_bytes();doc=json.loads(raw)
        actual=kernel.simultaneous_confidence(doc,alpha='0.05')
        actual.update(input_sha256=hashlib.sha256(raw).hexdigest(),source_sha256=source_hash,
                      provenance='synthetic',synthetic_notice=doc['synthetic_notice'])
        saved=json.loads((ROOT/'inference/results'/(fixture.stem+'_result.json')).read_text())
        assert actual==saved,fixture.name
        reproduced_fixtures+=1
    from unittest.mock import patch
    doc=json.loads((ROOT/'inference/fixtures/high_recovery_all_success_null.json').read_text())
    # Isolate the shared-intersection rule from CP and log arithmetic: exact
    # contact is compatible; arbitrarily small rational separation rejects.
    for bounds,expect_rejection in [([(Fraction(1),Fraction(2)),(Fraction(2),Fraction(4))],False),
                                  ([(Fraction(1),Fraction(2)),(Fraction(2)+Fraction(1,10**100),Fraction(4))],True)]:
        projections=[({'theta_interval':{}},lo,hi) for lo,hi in bounds]
        with patch.object(kernel,'project_context',side_effect=projections):
            out=kernel.simultaneous_confidence(doc)
        assert (out['decision']=='reject_shared_theta')==expect_rejection
    result=dict(source='inference/boundary_confidence.py',source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        endpoint_certificates_checked=certificates,exact_tail_comparisons=tail_cases,
        rational_grid_coverage_cases=coverage_cases,worst_coverage_exact=str(worst),worst_case=worst_case,
        projection_corners_checked=len(corner_values),signed_zero_projection_checks=2,
        saved_fixture_results_reproduced=reproduced_fixtures,exact_intersection_threshold_checks=2,all_passed=True,
        scope='Exhaustive count outcomes for n1..12, three prespecified tail levels and21 rational population probabilities; direct Fraction PMF oracle. Supports implementation review, not proof for all supported n/p or biological validation.')
    (ROOT/'audit/EXACT_BINOMIAL_ORACLE_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
