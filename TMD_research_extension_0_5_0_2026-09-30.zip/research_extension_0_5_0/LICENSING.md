# Reuse and attribution

New software is MIT licensed; see LICENSE. New explanatory writing is CC BY 4.0: https://creativecommons.org/licenses/by/4.0/. Author: Ricardo Maldonado, with AI-assisted analysis and development. The CITATION license field names the software license; writing follows this separate notice.

Primary papers, publisher figures and third-party datasets retain their rights. This package redistributes none of those papers, figures or raw datasets. Literature summaries distinguish attributed measured findings from our proposed design consequences. Read-only archive references are described with portable labels and selected hashes, without altering the originals.

Reused synthetic records from the 0.4.0 project are identified as reused. They do not supply new independent biological evidence. Source and artifact hashes support reproducibility; they do not authenticate sampling, independence or recovery transfer.
