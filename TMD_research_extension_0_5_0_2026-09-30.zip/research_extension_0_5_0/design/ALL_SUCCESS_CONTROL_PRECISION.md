# What can all-success controls tell us?

This is an analytic illustration for a fixed, prespecified study. It does not prescribe a laboratory sample size, predict power or guarantee that future observations will contain only successes.

The formulas describe the ideal Clopper-Pearson roots. The software returns certified conservative dyadic outer approximations, which can be slightly wider; these expressions are not exact identities for its binary endpoints.

For C contexts and familywise error alpha, the proposed procedure covers twelve scalar probabilities per context. Each two-sided interval has error alpha/(12C), giving tail probability a=alpha/(24C). If a control recovers all L introduced independent units, its Clopper-Pearson interval is [a^(1/L),1]. In log coordinates it is [log(a)/L,0]. An all-success sample is evidence about recovery, despite providing no interior estimate for the 0.4.0 likelihood implementation.

Write v=(-1/2,1,-1/2). Recovery correction contributes v·log(d0)-v·log(d1). If all six controls in a context recover every introduced unit and their denominators are all L, the positive coefficients sum to two and the magnitudes of negative coefficients also sum to two. The correction's rectangular interval is therefore:

```text
[-2 log(24C/alpha)/L, +2 log(24C/alpha)/L]
```

At C=4, alpha=.05 and L=100, a=.0005208333. Each recovery lower endpoint is approximately .92719, and the correction half-width is approximately .15120. Biological baseline/selected sampling uncertainty must be added separately; .15120 is not the full theta uncertainty.

For a chosen correction-only half-width h>0, an equal-denominator all-success table meets that width once L>=ceil(2 log(24C/alpha)/h). This is a **conditional observed-table calculation**. It does not assert that this number of introduced units will all recover, that transfer is valid, or that the complete contrast can reject a departure. Unequal denominators or mixed success/failure counts require their actual projected intervals. Uncertain planning probabilities and laboratory costs need separate treatment.

Version 0.4.0's L=643 minimum at d=.99 was a chosen floor for its conservative interior-count policy at 95% global eligibility. It was not an information-theoretic requirement. The new projection can retain finite recovery information from all-success samples that policy declined. Different intervals and tests can differ greatly in width and detection ability; this does not establish universal superiority.

At k=0, a control's lower recovery bound is zero. Its log range extends to minus infinity, leaving at least one contrast endpoint unbounded. The procedure preserves that uncertainty. Missing observations or unknown denominators are not measured zeros and must not be filled in.

The exact finite-sample argument relies on the binomial marginal model and defensible route-relative control transport. It does not repair within-culture dependence, concentration uncertainty, misclassification, physiological mismatch or repeated optional stopping. Standard CP inversion and Bonferroni projection underlie this illustration; external mathematical priority is not claimed.
