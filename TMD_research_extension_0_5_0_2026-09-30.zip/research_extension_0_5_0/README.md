# Mutation by Natural Dominance: boundary confidence bounds

**Methods extension 0.5.0 · Ricardo Maldonado · 30 September 2026**

Version 0.4.0's interior likelihood declines an all-success or all-failure control. This package adds a different, conservative procedure: simultaneous binomial confidence intervals projected onto the recovery-corrected route contrast. All-success controls can retain finite information. Zero counts can give unbounded intervals, which remain unbounded.

The method combines established Clopper-Pearson inversion and Bonferroni coverage with a TMD-specific contrast projection. It does not fit a boundary likelihood, issue a p-value or establish a mutation mechanism. No suitable matched biological panel has yet been authenticated for this test. Numerical examples and repeated studies are synthetic.

## Read first

- [Scientific progress and scope](SCIENTIFIC_PROGRESS.md)
- [In More Basic Terms](IN_MORE_BASIC_TERMS.md)
- [Formal method and input contract](methods/BOUNDARY_CONFIDENCE_PROJECTION.md)
- [All-success control precision](design/ALL_SUCCESS_CONTROL_PRECISION.md)
- [Source audit and independent derivation](audit/BOUNDARY_INTERVAL_REFERENCE_AND_MATH_AUDIT.md)
- [Confidence and recovery literature](literature/LITERATURE_UPDATE.md)

## What is covered

For each of C prespecified contexts, record three route counts in each biological arm and introduced/recovered totals for each route in each control arm. There are twelve scalar probability intervals per context. Each two-sided marginal error is alpha/(12C); each tail receives alpha/(24C). Multinomial coordinates are dependent but have binomial marginals. The union bound does not require independence between those coordinates or between components.

Correct binomial/multinomial marginal laws still require justified sampling units and denominators. Dependence within trials, uncertain concentrations, clonal descendants, misclassification and failed control-to-biology recovery transfer can invalidate the interpretation. Missing counts are not measured zeros. Contexts, totals and alpha must be prespecified for this fixed-sample procedure; optional stopping and repeated looks are not automatically covered.

With v=(-1/2,1,-1/2), theta=v·[log(t)-log(b)-log(d1)+log(d0)]. The procedure conservatively projects a simultaneous rectangular probability region onto each finite population contrast. It rejects a shared theta only if the resulting intervals have an empty intersection. Nonempty overlap does not establish constancy or equivalence. Ignoring simplex constraints widens the projection; it cannot narrow away the true contrast on the coverage event.

Under valid marginal sampling, positive population components and admitted relative recovery transfer, simultaneous coverage is at least 1-alpha, and the shared-null rejection probability is at most alpha. Recovery probabilities may equal one. Structural true zero probabilities make the finite log contrast undefined and need another model.

## Numerical proof and supported domain

Floating-point roots only propose interval endpoints. Exact integer binomial-tail comparisons at the accepted dyadic endpoints certify that each endpoint lies outside or on the mathematical CP root. Exact rational bounds for J=exp(2theta) then decide intersection, so rounded logarithms cannot cause a rejection. Displayed theta endpoints are outward enclosures; infinite limits have explicit JSON fields rather than fake finite numbers.

The prototype supports at most 5,000 trials per scalar count, 64 contexts, and alpha at least 1e-12 and below one. Unsupported inputs are declined. A certificate proves the stated arithmetic inequalities, conditional on correct execution; it cannot authenticate a biological sampling model. No arbitrary probability floor or pseudocount is used.

## Reproduce

The inference core uses only the Python standard library. The repeated-sample generator and audit use NumPy 2.3.5; the reviewed environment is Python 3.12.14.

```sh
python3 -m unittest discover -s inference -p 'test_boundary_confidence.py' -v
python3 audit/verify_exact_binomial_coverage.py
python3 inference/boundary_confidence.py inference/fixtures/high_recovery_all_success_null.json --alpha 0.05
python3 calibration/run_repeated_sample_calibration.py
```

Read each scenario's generator, seeds and provenance before interpreting detection frequencies. Reused 0.4.0 observations remain reused synthetic observations, not new independent evidence. Root-level VALIDATION.json and SHA256SUMS.txt record release checks; the audit contains independent source-specific review receipts.

## Publication and earlier work

The reserved Zenodo identifier for the new report version is 10.5281/zenodo.23075312, in the existing research-report DOI family 10.5281/zenodo.23068055. A reserved identifier does not by itself confirm publication or resolver activation; publication receipts are kept separately. The preceding report is [0.1.0](https://zenodo.org/records/23068056). Earlier 0.2.0, 0.3.0 and 0.4.0 packages remain separately versioned; their observation designs and citations must not be silently replaced.

New software is MIT licensed and new explanatory text is CC BY 4.0. Original papers and third-party datasets retain their rights. See [reuse and attribution](LICENSING.md).
