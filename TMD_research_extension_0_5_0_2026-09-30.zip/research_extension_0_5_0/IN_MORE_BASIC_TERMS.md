# In More Basic Terms: every success does not mean certainty

Suppose you introduce 100 verified control cells and recover all 100. That is useful evidence that recovery is high. It does not prove recovery will always be perfect.

Our previous conservative calculation required each control sample to contain both successes and failures. The new method can use an all-success sample by keeping a range of possible recovery rates. It also includes the uncertainty in the biological route counts.

We then compare the ranges across conditions. If there is no value shared by all the ranges, that challenges the proposed common contrast under the stated assumptions. If the ranges overlap, the data have not settled the question. Overlap is not proof that the hypothesis is correct.

A sample with no recovered controls can be much less informative. Its recovery range reaches zero, and the corrected comparison may become unbounded. We leave that uncertainty visible. A missing record is different from a measured zero; neither gets an invented count.

The method also checks its numerical limits using exact arithmetic. That helps prevent a rounding error from becoming a scientific claim. The arithmetic cannot tell us whether a sorting event really contained one cell, whether a culture created dependent observations, or whether control cells behave like evolving cells. Those questions require clear records and experimental checks.

This is progress in making Mutation by Natural Dominance easier to test fairly. Simulations check how the tool behaves. A suitable biological experiment is still needed to learn whether the proposed shared contrast describes real evolutionary outcomes.
