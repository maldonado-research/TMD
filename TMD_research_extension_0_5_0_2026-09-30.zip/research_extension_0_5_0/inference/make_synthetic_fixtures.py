#!/usr/bin/env python3
"""Deterministic synthetic arithmetic examples; MIT, TMD 0.5.0."""
from pathlib import Path
import json

def document(selected=None,recovered=100,C=2,baseline=None):
    meta=dict(categorical_multinomial_marginals_justified=True,route_control_binomial_marginals_justified=True,
              common_genetic_background=True,context_matched_calibration=True,control_relative_recovery_transports=True,
              eligible_winner_observation_rule_locked=True,positive_population_components_for_log_contrast=True,
              control_sampling_design='fixed_route_independent_binomial',control_outcome_definition='one_binary_recovery_per_introduced_unit',
              exposed_unit_definition='Synthetic individually introduced labeled unit with one binary recovery indicator',
              calibration_design='matched_route_multinomial',calibration_validation='validated_for_route_probability',
              triad_sampling='exhaustive_triad',provenance='synthetic')
    contexts=[]
    for c in range(C):
        row=dict(context=f'context_{c+1}')
        for branch in ('baseline','selected'):
            counts=(selected[c] if selected is not None and branch=='selected' else (baseline if baseline is not None else [200,200,200]))
            row[branch+'_counts']=dict(zip(('W','A','M'),counts))
            row[branch+'_recovery_controls']={r:dict(introduced=100,recovered=recovered) for r in ('W','A','M')}
        contexts.append(row)
    return dict(route_order=['W','A','M'],branch_order=['baseline','selected'],metadata=meta,contexts=contexts,
                synthetic_notice='Deterministic count tables for arithmetic/software checks; not experimental observations or a repeated-sample power study.')

def fixtures():
    return {'high_recovery_all_success_null':document(),
            'high_recovery_strong_departure':document(selected=[[200,200,200],[20,960,20]]),
            'all_failure_controls':document(recovered=0),
            'zero_categorical_cells':document(selected=[[0,600,0],[200,200,200]]),
            'no_categorical_observations':document(baseline=[0,0,0]),
            'one_context_descriptive':document(C=1)}

if __name__=='__main__':
    dest=Path(__file__).resolve().parent/'fixtures';dest.mkdir(exist_ok=True)
    for name,doc in fixtures().items():(dest/(name+'.json')).write_text(json.dumps(doc,indent=2,allow_nan=False)+'\n')
