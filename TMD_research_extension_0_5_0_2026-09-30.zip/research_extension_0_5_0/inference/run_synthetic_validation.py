#!/usr/bin/env python3
"""Reproduce deterministic TMD 0.5.0 examples; all results are synthetic, MIT."""
import hashlib
import json
from pathlib import Path
import platform
import time
from boundary_confidence import simultaneous_confidence

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    here=Path(__file__).resolve().parent;results=here/'results';results.mkdir(exist_ok=True)
    hashes={p.name:digest(p) for p in [here/'boundary_confidence.py',here/'make_synthetic_fixtures.py',Path(__file__).resolve()]}
    records=[]
    for path in sorted((here/'fixtures').glob('*.json')):
        raw=path.read_bytes();doc=json.loads(raw);start=time.perf_counter();r=simultaneous_confidence(doc,alpha='0.05');elapsed=time.perf_counter()-start
        r.update(input_sha256=hashlib.sha256(raw).hexdigest(),source_sha256=hashes['boundary_confidence.py'],
                 provenance='synthetic',synthetic_notice=doc['synthetic_notice'])
        out=results/(path.stem+'_result.json');out.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n')
        records.append(dict(fixture=path.name,input_sha256=r['input_sha256'],result=out.name,result_sha256=digest(out),
                            decision=r['decision'],context_theta_intervals=[c['theta_interval'] for c in r['contexts']],elapsed_seconds=elapsed))
    summary=dict(schema_version='0.5.0',provenance='synthetic',python=platform.python_version(),source_hashes=hashes,
                 notice='Deterministic arithmetic examples, not repeated-sample size or power estimates. No bootstrap or P values.',results=records)
    (results/'synthetic_summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    for r in records:print(f"{r['fixture']}: {r['decision']}; {r['elapsed_seconds']:.3f} s")

if __name__=='__main__':main()
