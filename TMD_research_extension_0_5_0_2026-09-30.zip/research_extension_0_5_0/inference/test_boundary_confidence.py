#!/usr/bin/env python3
"""Independent arithmetic and inferential checks, MIT, TMD 0.5.0."""
import copy
from decimal import Decimal,localcontext
from fractions import Fraction
import itertools
import json
import math
import unittest
from unittest.mock import patch
import boundary_confidence as bc
from make_synthetic_fixtures import document,fixtures

def direct_tail(n,k,p,upper):
    p=Fraction(p)
    return sum((Fraction(math.comb(n,j))*p**j*(1-p)**(n-j) for j in range(n+1) if (j>=k if upper else j<=k)),Fraction())

def contains(interval,p):return Fraction(interval['lower'])<=p<=Fraction(interval['upper'])

class ConfidenceTests(unittest.TestCase):
    def test_exact_tails_against_independent_enumeration(self):
        for n in range(1,13):
            for k in range(n+1):
                for p in [0.,.125,.3,.75,1.]:
                    for upper in (False,True):
                        num,den=bc.exact_tail(n,k,p,upper)
                        self.assertEqual(Fraction(num,den),direct_tail(n,k,Fraction(p),upper))
                        self.assertAlmostEqual(bc.float_tail(n,k,p,upper),float(direct_tail(n,k,Fraction(p),upper)),places=12)
    def test_all_small_n_direct_enumerated_coverage(self):
        for n in range(1,11):
            for tau in [Fraction(1,100),Fraction(1,20),Fraction(1,5)]:
                intervals=[bc.clopper_pearson(k,n,tau) for k in range(n+1)]
                for p in [Fraction(j,20) for j in range(21)]:
                    coverage=sum((Fraction(math.comb(n,k))*p**k*(1-p)**(n-k) for k,i in enumerate(intervals) if contains(i,p)),Fraction())
                    self.assertGreaterEqual(coverage,1-2*tau)
    def test_certificates_and_endpoint_identities(self):
        tau=Fraction(1,960)
        for n in [1,2,100,1000]:
            lo=bc.clopper_pearson(n,n,tau);hi=bc.clopper_pearson(0,n,tau)
            self.assertEqual(lo['upper'],1.);self.assertEqual(hi['lower'],0.)
            self.assertTrue(bc.tail_at_most(n,n,lo['lower'],tau,True))
            self.assertTrue(bc.tail_at_most(n,0,hi['upper'],tau,False))
            with localcontext() as ctx:
                ctx.prec=70;root=(Decimal(tau.numerator)/Decimal(tau.denominator)).ln().__truediv__(n).exp()
                self.assertLessEqual(Decimal(lo['lower']),root)
                self.assertGreaterEqual(Decimal(hi['upper']),1-root)
            self.assertLess(float(root)-lo['lower'],1e-8)
    def test_bad_root_proposal_still_certified(self):
        with patch.object(bc,'proposed_root',return_value=.99):
            i=bc.clopper_pearson(2,10,Fraction(1,100))
        self.assertTrue(bc.tail_at_most(10,2,i['lower'],Fraction(1,100),True))
        self.assertTrue(bc.tail_at_most(10,2,i['upper'],Fraction(1,100),False))
    def test_endpoint_monotonicity_and_nesting(self):
        narrow=[bc.clopper_pearson(k,20,Fraction(1,20)) for k in range(21)]
        wide=[bc.clopper_pearson(k,20,Fraction(1,100)) for k in range(21)]
        for k in range(21):
            self.assertLessEqual(wide[k]['lower'],narrow[k]['lower']);self.assertGreaterEqual(wide[k]['upper'],narrow[k]['upper'])
            if k:self.assertGreaterEqual(narrow[k]['lower'],narrow[k-1]['lower']);self.assertGreaterEqual(narrow[k]['upper'],narrow[k-1]['upper'])
    def test_strict_missing_versus_observed_zero(self):
        for mutation in ['missing','missing_L','boolean','L_zero','too_many','random_mixture','missing_contract']:
            d=document();c=d['contexts'][0]
            if mutation=='missing':del c['selected_counts']['A']
            elif mutation=='missing_L':del c['selected_recovery_controls']['A']['introduced']
            elif mutation=='boolean':c['baseline_counts']['W']=True
            elif mutation=='L_zero':c['baseline_recovery_controls']['W']['introduced']=0
            elif mutation=='too_many':c['baseline_recovery_controls']['W']['recovered']=101
            elif mutation=='random_mixture':d['metadata']['control_sampling_design']='random_mixture_multinomial'
            else:del d['metadata']['route_control_binomial_marginals_justified']
            with self.assertRaises(ValueError,msg=mutation):bc.validate_document(d)
        bc.validate_document(document(recovered=0))
    def test_limits_and_no_observations(self):
        self.assertEqual(bc.clopper_pearson(0,0,Fraction(1,100))['status'],'no_observations')
        for value in [-1,True,None,float('nan'),5001,1.5]:
            with self.assertRaises(ValueError):bc.integer_count(value,'test')
        for value in [0,1,True,'nan',1e-13]:
            with self.assertRaises(ValueError):bc.alpha_fraction(value)
    def test_exact_projection_signs_and_display_enclosure(self):
        groups={'baseline':[Fraction(1,5),Fraction(1,2),Fraction(3,10)],'selected':[Fraction(1,4),Fraction(1,2),Fraction(1,4)],
                'baseline_controls':[Fraction(1,2),Fraction(2,3),Fraction(3,4)],'selected_controls':[Fraction(3,4),Fraction(1,2),Fraction(2,3)]}
        intervals={g:[dict(lower=p,upper=p) for p in row] for g,row in groups.items()}
        out,lo,hi=bc.project_context(intervals)
        b,t,d0,d1=[groups[g] for g in ['baseline','selected','baseline_controls','selected_controls']]
        expected=t[1]**2*b[0]*b[2]*d1[0]*d1[2]*d0[1]**2/(t[0]*t[2]*b[1]**2*d1[1]**2*d0[0]*d0[2])
        self.assertEqual(lo,expected);self.assertEqual(hi,expected)
        with localcontext() as ctx:
            ctx.prec=100;truth=(Decimal(expected.numerator)/Decimal(expected.denominator)).ln()/2
            self.assertLessEqual(Decimal(out['theta_interval']['lower']['value']),truth)
            self.assertGreaterEqual(Decimal(out['theta_interval']['upper']['value']),truth)
    def test_public_projection_rejects_truncated_invalid_groups(self):
        i={g:[dict(lower=.1,upper=.9)]*3 for g in ['baseline','selected','baseline_controls','selected_controls']}
        for bad in ['missing','short','zero_upper','nan','boolean']:
            x=copy.deepcopy(i)
            if bad=='missing':del x['baseline']
            elif bad=='short':x['baseline'].pop()
            elif bad=='zero_upper':x['baseline'][0]=dict(lower=0,upper=0)
            elif bad=='nan':x['baseline'][0]['lower']=float('nan')
            else:x['baseline'][0]['upper']=True
            with self.assertRaises(ValueError):bc.project_context(x)
    def test_all_success_controls_finite_and_departure_rejects(self):
        f=fixtures();null=bc.simultaneous_confidence(f['high_recovery_all_success_null']);alt=bc.simultaneous_confidence(f['high_recovery_strong_departure'])
        self.assertEqual(null['decision'],'no_shared_theta_departure_established')
        self.assertEqual(alt['decision'],'reject_shared_theta')
        for c in null['contexts']:
            self.assertTrue(Fraction(c['J_lower_exact'])<=1<=Fraction(c['J_upper_exact']))
            self.assertIsNotNone(c['theta_interval']['lower']['value']);self.assertIsNotNone(c['theta_interval']['upper']['value'])
    def test_failure_zero_and_missing_sample_are_unbounded(self):
        for name in ['all_failure_controls','no_categorical_observations']:
            r=bc.simultaneous_confidence(fixtures()[name])
            self.assertEqual(r['decision'],'no_shared_theta_departure_established')
            for c in r['contexts']:
                self.assertEqual(c['theta_interval']['lower'],dict(value=None,infinity='negative'))
                self.assertEqual(c['theta_interval']['upper'],dict(value=None,infinity='positive'))
            json.dumps(r,allow_nan=False)
        z=bc.simultaneous_confidence(fixtures()['zero_categorical_cells'])
        self.assertEqual(z['contexts'][0]['theta_interval']['upper']['infinity'],'positive')
        self.assertIsNone(z['p_value'])
    def test_one_context_only_descriptive_and_exact_allocation(self):
        r=bc.simultaneous_confidence(document(C=1),alpha='0.05')
        self.assertEqual(r['decision'],'not_evaluable_one_context');self.assertEqual(r['coordinates'],12)
        self.assertEqual(Fraction(r['per_tail_error_exact']),Fraction(1,480))
        self.assertFalse(r['shared_theta_intersection']['empty'])
    def test_shared_rule_under_dependent_valid_marginals(self):
        # One common n=4 multinomial sample generates EVERY component: maximal dependence.
        # Route permutations preserve uniform b,t; each control indicator has d=1/3.
        # Thus every count law holds and both true contrasts are theta=0, despite dependence.
        probability_reject=Fraction();probability_joint_coverage=Fraction();alpha=Fraction(1,20)
        for w in range(5):
            for a in range(5-w):
                m=4-w-a;raw=[w,a,m];d=document(C=2)
                for j,c in enumerate(d['contexts']):
                    for h,branch in enumerate(('baseline','selected')):
                        vals=raw[(j+h)%3:]+raw[:(j+h)%3]
                        c[branch+'_counts']=dict(zip(bc.ROUTES,vals))
                        c[branch+'_recovery_controls']={r:dict(introduced=4,recovered=raw[(i+j+2*h)%3]) for i,r in enumerate(bc.ROUTES)}
                out=bc.simultaneous_confidence(d,alpha)
                weight=Fraction(math.factorial(4),math.factorial(w)*math.factorial(a)*math.factorial(m))*Fraction(1,3)**4
                good=all(contains(cell,Fraction(1,3)) for c in out['contexts'] for row in c['marginal_intervals'].values() for cell in row)
                if good:
                    probability_joint_coverage+=weight
                    self.assertFalse(out['shared_theta_intersection']['empty'])
                if out['decision']=='reject_shared_theta':probability_reject+=weight
        self.assertGreaterEqual(probability_joint_coverage,1-alpha);self.assertLessEqual(probability_reject,alpha)

if __name__=='__main__':unittest.main(verbosity=2)
