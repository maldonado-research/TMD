# Limited repeated-sample calibration and support stress test

This independent synthetic diagnostic calls the frozen 0.4.0 inference API. It is an approximate composite-null check, not certified test size, power, empirical TMD validation or evidence that laboratory controls transport.

All three scenarios contain four contexts, two categorical branches per context and three routes. Baseline and selected categorical totals are fixed at 600 in every context. Dense scenarios use 600 independently introduced units for **each route in each control branch**, not a 600-unit total pooled across routes. High-recovery controls use 100 introduced units per route/branch. Categorical samples and control recoveries are independent by construction; every introduced control unit has one Bernoulli outcome. These are generator assumptions, not experimentally established properties.

## Generators and decisions

The dense generators use the exact rational categorical proportions encoded by `fixed_route_recovery_artifact.json` and `fixed_route_theta_departure.json`, with control efficiencies given by the fixtures' exact recovered/introduced ratios. Their original deterministic table sizes are ignored. Shared latent theta is log(2). In the departure case, context four has theta = log(4), a log(2) departure; the remaining contexts retain log(2).

The high-recovery case recovers the shared fixture's latent baseline/selected probabilities by dividing its observed probabilities by its control efficiencies and renormalizing, using rational arithmetic. It then sets every control efficiency to 99/100. Because recovery is equal across routes within each branch, high-case observed probabilities are the same latent q and p. Transport is exact in all generators.

Forty independent datasets are sampled per scenario. Every fit admitted by the API receives 99 fitted-null parametric bootstrap draws of both categorical outcomes and all fixed-route binomial controls. Master seed `2026100104` yields distinct dataset and bootstrap seeds. Plus-one p <= 0.05 is the decision rule; at 99 draws its resolution is 0.01 and rejection requires no more than four exceedances.

No dataset or unresolved draw is replaced. Policy admission, fit admission and statistical decisions are recorded separately. If bootstrap draws are unresolved, computational p-value bounds determine definite rejection/nonrejection; an interval crossing 0.05 leaves the decision unresolved. These bounds are not confidence intervals. Declined dataset fits receive no bootstrap and are **not** statistical nonrejections.

## Recorded outcomes

| Synthetic scenario | Policy passes / fit admissions | 5% rejections among admitted fits | 95% Wilson interval for rejection fraction |
|---|---:|---:|---:|
| Dense shared latent theta with route recovery differences | 40/40; 40/40 | 1/40 (2.5%) | 0.44–12.88% |
| Dense context departure | 40/40; 40/40 | 33/40 (82.5%) | 68.05–91.25% |
| High recovery d=.99, introduced L=100 per route/branch | 0/40; 0/40 | Not tested | Not estimable |

All 7,920 bootstrap draws requested for the 80 admitted dense fits resolved. All 40 high-recovery datasets were retained with `extreme_binomial_not_supported`; their prospective 3,960 bootstrap draws were not attempted. No bootstrap draw was unresolved in this run. Dense admission fractions each have a 95% Wilson interval of 91.24–100%; high-recovery admission has an interval of 0–8.76%.

Wilson intervals describe repeated-dataset uncertainty at these fixed synthetic probabilities and this finite-bootstrap decision procedure. Admitted-only rejection is conditional on fit admission. It does not establish a general power curve or a biological sample-size recommendation. A null rejection count of 1/40 is consistent with considerable uncertainty around nominal 5%, and 99 inner draws give coarse and variable decisions. Per-dataset fitted-null exceedance counts also receive Wilson intervals describing inner Monte Carlo uncertainty; these do not certify composite-null calibration.

## Independent finite check of the high-recovery support prediction

The planner predicts passing the zero/extreme-cell policy using an independent-count product. For each three-category arm with probabilities p and N=600, occupancy is

`1 − sum_i (1−p_i)^600 + sum_i p_i^600`.

For each route-specific control, interior support is

`1 − d^L − (1−d)^L`.

The calibration script separately evaluates all eight categorical factors and 24 binomial factors from rational inputs using 80-digit Decimal arithmetic, without calling the planner's component helpers. It compares that product with `supported_cell_probability`. For high recovery, predicted admission is **1.7766851793×10^-5**, agreeing within 2.44×10^-19 in floating-point comparison. The expected number admitted in 40 is 0.000710674; the model probability of zero admissions is 99.92896%. Thus, zero admissions is the expected stress-test outcome. This probability concerns support-policy passage only, not optimizer success, resolved bootstrap inference or biological eligibility.

The small delta-method control variance at high d does not prevent frequent all-recovered control cells. The API conservatively declines those tables; this run does not claim their joint MLE must be infinite or their biological hypothesis false.

## Reproduction and provenance

```sh
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python3 calibration/run_repeated_sample_calibration.py
```

The recorded run used bundled Python 3.12.14 and NumPy 2.3.5 and took approximately 15.3 seconds. `sampled_counts.json` records every dataset's categorical/recovered counts, generator and seed pair; route-control introduced totals are stored with each scenario's generator. `repeated_sample_results.json` additionally retains fitted diagnostics, bootstrap statistics, computational decision bounds and uncertainty summaries. All 120 sampled datasets were independently regenerated from their saved seeds and matched; totals, decisions, draw accounting and source hashes were checked.

Results contain portable relative-path hashes for the inference module, solver, fixture generator, fixtures and calibration script. Planner provenance is recorded separately with each finite check. `artifact_hashes.json` hashes the emitted calibration artifacts. Source hashes were stable before/after execution and matched the final files. Elapsed runtime is the only timing-dependent result field. Only `calibration/` was written; inference, design and protocol files were not modified.
