#!/usr/bin/env python3
"""Independent synthetic diagnostic for the frozen 0.4.0 fixed-route API.

Copyright (c) 2026 Ricardo Maldonado. MIT; see ../inference/LICENSE.
No biological observations, sample replacement, or inference/design edits.
"""
from __future__ import annotations
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
INFERENCE = BASE / 'inference'
sys.path.insert(0, str(INFERENCE))
sys.path.insert(0, str(BASE / 'design'))
from fixed_route_control_inference import bootstrap_fixed_route_controls, corrected_contrast, validate_document
from fixed_input_design import supported_cell_probability

DATASETS = 40
BOOTSTRAPS = 99
CATEGORICAL_TOTAL = 600
ALPHA = .05
MASTER_SEED = 2026100104
SCENARIOS = (
    ('dense_shared_latent_theta', 'fixed_route_recovery_artifact.json', 600, False),
    ('dense_context_departure', 'fixed_route_theta_departure.json', 600, False),
    ('high_recovery_support_stress', 'fixed_route_recovery_artifact.json', 100, True),
)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def wilson(k, n):
    if n == 0:
        return None
    z = 1.959963984540054
    p = k / n
    den = 1 + z*z/n
    center = (p + z*z/(2*n))/den
    half = z * math.sqrt(p*(1-p)/n + z*z/(4*n*n))/den
    return [max(0., center-half), min(1., center+half)]


def norm(values):
    total = sum(values)
    return [value/total for value in values]


def floats(values):
    return np.asarray([[[float(v) for v in row] for row in context] for context in values])


def rationals(values):
    return [[[str(v) for v in row] for row in context] for context in values]


def load_generator(filename, control_total, high):
    path = INFERENCE/'fixtures'/filename
    doc = json.loads(path.read_text())
    names, counts, introduced, recovered = validate_document(doc)
    assert counts.shape == (4, 2, 3)
    probs = [[norm([F(int(v)) for v in row]) for row in context] for context in counts]
    ds = [[[F(int(k), int(L)) for k, L in zip(kk, LL)] for kk, LL in zip(kc, Lc)] for kc, Lc in zip(recovered, introduced)]
    latent = [[norm([p/d for p, d in zip(pp, dd)]) for pp, dd in zip(pc, dc)] for pc, dc in zip(probs, ds)]
    if high:
        ds = [[[F(99, 100)]*3 for _ in range(2)] for _ in range(4)]
        probs = [[norm([p*d for p, d in zip(pp, dd)]) for pp, dd in zip(pc, dc)] for pc, dc in zip(latent, ds)]
    probabilities, efficiencies = floats(probs), floats(ds)
    theta = corrected_contrast(probabilities, efficiencies)
    assert np.allclose(theta, [row['theta'] for row in doc['generating_parameters']], rtol=0, atol=1e-12)
    L = np.full((4, 2, 3), control_total, dtype=np.int64)
    planning_contexts = [{'b': pc[0].tolist(), 't': pc[1].tolist(), 'd0': dc[0].tolist(), 'd1': dc[1].tolist(), 'm': CATEGORICAL_TOTAL, 'n': CATEGORICAL_TOTAL, 'L0': [control_total]*3, 'L1': [control_total]*3} for pc, dc in zip(probabilities, efficiencies)]
    planner_path = BASE/'design/fixed_input_design.py'
    planner_hash = sha256(planner_path)
    planner = supported_cell_probability(planning_contexts, independent_all_units=True)
    # Independently evaluate the finite occupancy/extreme-count product using
    # exact-rational inputs and 80-digit Decimal arithmetic, not planner helpers.
    with localcontext() as ctx:
        ctx.prec = 80
        convert = lambda x: Decimal(x.numerator)/Decimal(x.denominator)
        one = Decimal(1)
        factors = []
        for pc, dc in zip(probs, ds):
            for row in pc:
                pp = [convert(value) for value in row]
                factors.append(one-sum((one-p)**CATEGORICAL_TOTAL for p in pp)+sum(p**CATEGORICAL_TOTAL for p in pp))
            for row in dc:
                for value in row:
                    d = convert(value)
                    factors.append(one-d**control_total-(one-d)**control_total)
        product = one
        for factor in factors:
            product *= factor
        independent_decimal = str(product)
    difference = abs(planner['probability_of_all_supported_cells']-float(product))
    assert math.isfinite(difference) and difference < 1e-12
    assert sha256(planner_path) == planner_hash
    return path, names, probabilities, efficiencies, L, {
        'source_fixture': str(path.relative_to(BASE)),
        'observed_probabilities_exact_rational': rationals(probs),
        'latent_baseline_selected_exact_rational': rationals(latent),
        'control_efficiencies_exact_rational': rationals(ds),
        'observed_probabilities': probabilities.tolist(),
        'control_efficiencies': efficiencies.tolist(),
        'introduced_each_route_branch': L.tolist(),
        'generating_corrected_theta': theta.tolist(),
        'transport_assumption': 'Exact by construction; route efficiencies transport within each paired control/outcome branch.',
        'support_planner_check': {
            'planner': planner, 'planner_source_sha256': planner_hash,
            'independent_80_digit_finite_probability': independent_decimal,
            'absolute_float_difference': difference,
            'formula': 'Product over all 8 categorical arms of [1-sum_i(1-p_i)^600+sum_i p_i^600], times all 24 control probabilities [1-d^L-(1-d)^L].',
            'limit': 'Probability of passing zero/extreme-cell policy only; not optimizer success, bootstrap resolution or biological eligibility.',
        },
    }


def summary(records, support_probability):
    n = len(records)
    support = sum(row['passes_supported_cell_policy'] for row in records)
    admitted = sum(row['fit_admitted'] for row in records)
    decisions = Counter(row['decision_at_5_percent'] for row in records)
    rejected = decisions['reject']
    ambiguous = decisions['unresolved_bootstrap']
    attempted = sum(row['bootstrap_result'].get('replicates', 0) for row in records)
    failed = sum(row['bootstrap_result'].get('unresolved_replicates', 0) for row in records)
    reasons = Counter()
    for row in records:
        reasons.update(row['bootstrap_result'].get('unresolved_reasons', {}))
    return {
        'datasets_generated_and_retained': n,
        'support_policy_passes': support, 'support_policy_declines': n-support,
        'support_policy_admission_fraction': support/n,
        'support_policy_admission_wilson_95': wilson(support, n),
        'predicted_support_admission_probability': support_probability,
        'predicted_number_support_admitted': n*support_probability,
        'probability_zero_support_admitted_under_generator': (1-support_probability)**n,
        'fit_admitted': admitted, 'fit_not_evaluable': n-admitted,
        'fit_admission_wilson_95': wilson(admitted, n),
        'fit_status_counts': dict(Counter(row['bootstrap_result']['fit']['status'] for row in records)),
        'bootstrap_status_counts': dict(Counter(row['bootstrap_result']['status'] for row in records)),
        'decision_counts': {key: decisions[key] for key in ('reject', 'do_not_reject', 'unresolved_bootstrap', 'not_tested_dataset_fit')},
        'rejection_count_computational_bounds_among_fit_admitted': [rejected, rejected+ambiguous],
        'rejection_fraction_bounds_among_fit_admitted': [rejected/admitted, (rejected+ambiguous)/admitted] if admitted else None,
        'rejection_wilson_95_among_fit_admitted': wilson(rejected, admitted) if admitted and ambiguous == 0 else None,
        'rejection_wilson_endpoint_envelope_if_unresolved': [wilson(rejected, admitted)[0], wilson(rejected+ambiguous, admitted)[1]] if admitted and ambiguous else None,
        'uncertainty_limit': 'Wilson intervals concern independent generated datasets in this fixed scenario; admitted-only rejection is conditional on fit admission. Computational bounds/envelopes are not exact confidence intervals. Policy declines are not statistical nonrejections.',
        'bootstrap_draws_if_all_datasets_fit_admitted': n*BOOTSTRAPS,
        'bootstrap_draws_requested_for_fit_admitted': admitted*BOOTSTRAPS,
        'bootstrap_draws_attempted': attempted,
        'bootstrap_draws_unresolved': failed,
        'bootstrap_draws_not_attempted_due_to_dataset_fit': (n-admitted)*BOOTSTRAPS,
        'unresolved_draw_reasons': dict(reasons),
    }


def main():
    start = time.monotonic()
    source_paths = [Path(__file__).resolve(), INFERENCE/'fixed_route_control_inference.py', INFERENCE/'_fixed_route_convex.py', INFERENCE/'make_synthetic_fixtures.py']
    source_hashes = {str(path.relative_to(BASE)): sha256(path) for path in source_paths}
    output = {'schema_version': '0.4.0', 'provenance': 'synthetic_repeated_sampling_only', 'biological_data_admitted': False,
        'purpose': 'Limited approximate composite-null diagnostic and support-policy stress test, not certified size/power or empirical TMD validation.',
        'software': {'python': platform.python_version(), 'numpy': np.__version__},
        'configuration': {'contexts': 4, 'branches': 2, 'routes': 3, 'categorical_total_each_context_branch': CATEGORICAL_TOTAL, 'datasets_each_scenario': DATASETS, 'bootstraps_each_fit_admitted': BOOTSTRAPS, 'master_seed': MASTER_SEED, 'nominal_alpha': ALPHA, 'decision_rule': 'Reject if upper computational p bound <= 0.05; nonreject if lower bound > 0.05; otherwise unresolved. Declined dataset fits are not tested.', 'sampling_policy': 'No dataset or failed-draw replacement; independent multinomial categorical samples and independent binomial fixed-route controls.'},
        'source_sha256': source_hashes, 'scenarios': []}
    for spec, scenario_seed in zip(SCENARIOS, np.random.SeedSequence(MASTER_SEED).spawn(3)):
        label, filename, control_total, high = spec
        path, names, probs, ds, L, generator = load_generator(filename, control_total, high)
        output['source_sha256'][str(path.relative_to(BASE))] = sha256(path)
        scenario = {'scenario': label, 'context_names': names, 'generator': generator, 'records': []}
        for index, seed in enumerate(scenario_seed.spawn(DATASETS)):
            data_seed, bootstrap_seed_sequence = seed.spawn(2)
            data_seed_int = int(data_seed.generate_state(1, dtype=np.uint64)[0])
            bootstrap_seed = int(bootstrap_seed_sequence.generate_state(1, dtype=np.uint64)[0])
            rng = np.random.default_rng(data_seed_int)
            counts = np.array([[rng.multinomial(CATEGORICAL_TOTAL, p) for p in context] for context in probs])
            recovered = rng.binomial(L, ds)
            assert np.all(counts.sum(axis=2) == CATEGORICAL_TOTAL)
            assert np.all((recovered >= 0) & (recovered <= L))
            passes = bool(np.all(counts > 0) and np.all(recovered > 0) and np.all(recovered < L))
            result = bootstrap_fixed_route_controls(counts, L, recovered, replicates=BOOTSTRAPS, seed=bootstrap_seed)
            admitted = result['fit']['inference_status'] == 'estimable'
            bounds = result.get('p_value_computational_bounds')
            decision = 'not_tested_dataset_fit' if not admitted else ('reject' if bounds[1] <= ALPHA else ('do_not_reject' if bounds[0] > ALPHA else 'unresolved_bootstrap'))
            e, f = result.get('exceedances', 0), result.get('unresolved_replicates', 0)
            tail_ci = wilson(e, BOOTSTRAPS) if admitted and f == 0 else None
            tail_envelope = [wilson(e, BOOTSTRAPS)[0], wilson(e+f, BOOTSTRAPS)[1]] if admitted and f else None
            scenario['records'].append({'dataset_index': index, 'dataset_seed': data_seed_int, 'bootstrap_seed': bootstrap_seed, 'categorical_counts': counts.tolist(), 'control_recovered_counts': recovered.tolist(), 'passes_supported_cell_policy': passes, 'fit_admitted': admitted, 'decision_at_5_percent': decision, 'bootstrap_tail_wilson_95_given_resolved': tail_ci, 'bootstrap_tail_wilson_endpoint_envelope_if_unresolved': tail_envelope, 'tail_uncertainty_limit': 'Monte Carlo uncertainty of a fitted-null exceedance probability; does not calibrate the composite null or biological model.', 'bootstrap_result': result})
            if (index+1) % 10 == 0:
                print(f'{label}: {index+1}/{DATASETS} datasets retained', flush=True)
        scenario['summary'] = summary(scenario['records'], generator['support_planner_check']['planner']['probability_of_all_supported_cells'])
        output['scenarios'].append(scenario)
    for relative, expected in output['source_sha256'].items():
        assert sha256(BASE/relative) == expected, f'Source changed during execution: {relative}'
    output['elapsed_seconds'] = time.monotonic()-start
    (ROOT/'repeated_sample_results.json').write_text(json.dumps(output, indent=2, allow_nan=False)+'\n')
    count_output = {'provenance': output['provenance'], 'master_seed': MASTER_SEED, 'source_sha256': output['source_sha256'], 'scenarios': [{'scenario': s['scenario'], 'generator': s['generator'], 'records': [{key: r[key] for key in ('dataset_index','dataset_seed','bootstrap_seed','categorical_counts','control_recovered_counts','passes_supported_cell_policy','fit_admitted','decision_at_5_percent')} for r in s['records']]} for s in output['scenarios']]}
    (ROOT/'sampled_counts.json').write_text(json.dumps(count_output, indent=2, allow_nan=False)+'\n')
    print(json.dumps({s['scenario']: s['summary'] for s in output['scenarios']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
