#!/usr/bin/env python3
"""Standard delta-method planning and exact support probabilities for fixed controls.

Copyright (c) 2026 Ricardo Maldonado. MIT; see ../LICENSE.
No observed data, external mathematical novelty or certified power is supplied.
"""
from __future__ import annotations
import json
import math
from numbers import Real
from pathlib import Path

V=(-.5,1.,-.5)
NAMES=('baseline_recovered','selected_recovered',
       'baseline_W_introduced','baseline_A_introduced','baseline_M_introduced',
       'selected_W_introduced','selected_A_introduced','selected_M_introduced')


def finite_positive(x):
    if isinstance(x,bool) or not isinstance(x,Real) or not math.isfinite(x) or x<=0:
        raise ValueError('Positive finite numeric value required')
    return float(x)


def count(n):
    x=finite_positive(n)
    if x!=math.floor(x) or x>2**52:
        raise ValueError('Positive exactly representable integer count required')
    return int(x)


def triad(values,simplex=False):
    if len(values)!=3:
        raise ValueError('Three route values required')
    values=tuple(finite_positive(x) for x in values)
    if any(x>=1 for x in values):
        raise ValueError('Strictly interior route probabilities required')
    if simplex and not math.isclose(sum(values),1,abs_tol=1e-10,rel_tol=0):
        raise ValueError('Route composition must sum to one')
    return values


def coefficients(b,t,d0,d1):
    b,t=triad(b,True),triad(t,True)
    d0,d1=triad(d0),triad(d1)
    result=[sum(w*w/x for w,x in zip(V,b)),sum(w*w/x for w,x in zip(V,t))]+[
        w*w*(1-d)/d for ds in (d0,d1) for w,d in zip(V,ds)]
    if not all(math.isfinite(x) and x>0 for x in result):
        raise ValueError('Planning coefficients exceed numerical precision; unsupported input')
    return result


def contrast_variance(b,t,d0,d1,m,n,L0,L1):
    if len(L0)!=3 or len(L1)!=3:
        raise ValueError('Three introduced totals per branch required')
    totals=[finite_positive(x) for x in (m,n,*L0,*L1)]
    terms=[a/x for a,x in zip(coefficients(b,t,d0,d1),totals)]
    if not all(math.isfinite(x) for x in terms) or not math.isfinite(sum(terms)):
        raise ValueError('Planning variance exceeds numerical precision')
    return {'variance_regular':sum(terms),'standard_error_regular':math.sqrt(sum(terms)),
            'components':dict(zip(NAMES,terms)),
            'assumption':'Two independent categorical samples and six independent fixed-input binomials; route-relative transport'}


def optimal_allocation(b,t,d0,d1,budget,costs=(1,)*8):
    budget=finite_positive(budget)
    if len(costs)!=8:
        raise ValueError('Eight per-unit costs required')
    costs=[finite_positive(x) for x in costs]
    aa=coefficients(b,t,d0,d1)
    denominator=sum(math.sqrt(a*c) for a,c in zip(aa,costs))
    if not math.isfinite(denominator) or not math.isfinite(denominator*denominator/budget):
        raise ValueError('Planning budget/cost combination exceeds numerical precision')
    totals=[budget*(math.sqrt(a/c)/denominator) for a,c in zip(aa,costs)]
    return {'continuous_allocation':dict(zip(NAMES,totals)),'costs':list(costs),'budget':budget,
            'minimum_regular_variance':denominator*denominator/budget,
            'interpretation':'Mixed units: biological recovered observations versus control introduced independent units. Continuous planning only; round and verify yields, eligibility and actual costs.'}


def binomial_interior_probability(L,d):
    """Exact model probability of 0<K<L, not probability of a usable p-value."""
    L=count(L); d=finite_positive(d)
    if d>=1:
        raise ValueError('Recovery probability strictly between zero and one required')
    if L<2:
        return 0.
    answer=math.fsum([1.,-math.exp(L*math.log1p(-d)),-math.exp(L*math.log(d))])
    return min(1.,max(0.,answer))


def categorical_positive_probability(N,p):
    """Three-category occupancy probability by inclusion-exclusion."""
    N=count(N); p=triad(p,True)
    if N<3:
        return 0.
    answer=math.fsum([1.]+[-math.exp(N*math.log1p(-x)) for x in p]+[math.exp(N*math.log(x)) for x in p])
    return min(1.,max(0.,answer))


def supported_cell_probability(contexts,independent_all_units=False):
    if independent_all_units is not True:
        raise ValueError('Explicit independent_all_units=True required for product probability')
    if not contexts:
        raise ValueError('At least one planning context required')
    factors=[]; detail=[]
    for ctx in contexts:
        if len(ctx['L0'])!=3 or len(ctx['L1'])!=3:
            raise ValueError('Three control totals per branch required')
        d0,d1=triad(ctx['d0']),triad(ctx['d1'])
        components=[categorical_positive_probability(ctx['m'],ctx['b']),
                    categorical_positive_probability(ctx['n'],ctx['t'])]+[
            binomial_interior_probability(L,d) for Ls,ds in ((ctx['L0'],d0),(ctx['L1'],d1)) for L,d in zip(Ls,ds)]
        factors.extend(components)
        detail.append(dict(zip(NAMES,components)))
    probability=math.prod(factors)
    return {'probability_of_all_supported_cells':probability,'probability_of_policy_decline':1-probability,
            'per_context_components':detail,
            'interpretation':'Exact under the specified independent count model and planning probabilities. Predicts only passing the zero/extreme-cell policy, not optimizer success, bootstrap resolution, power or biological admission.'}


def minimum_policy_totals(b,t,d0,d1,contexts=4,target=.95,max_per_component=10000000):
    """Equal union-bound error allocation; not globally minimum-cost design."""
    contexts=count(contexts); cap=count(max_per_component)
    target=finite_positive(target)
    if target>=1:
        raise ValueError('Target strictly below one required')
    b,t=triad(b,True),triad(t,True)
    d0,d1=triad(d0),triad(d1)
    tolerance=(1-target)/(8*contexts)
    funcs=[lambda x:categorical_positive_probability(x,b),lambda x:categorical_positive_probability(x,t)]+[
        lambda x,d=d:binomial_interior_probability(x,d) for ds in (d0,d1) for d in ds]
    minima=[]
    for fun in funcs:
        high=1
        while fun(high)<1-tolerance and high<cap:
            high=min(cap,2*high)
        if fun(high)<1-tolerance:
            return {'status':'planning_cap_exceeded','max_per_component':cap}
        low=0
        while high-low>1:
            middle=(low+high)//2
            if fun(middle)>=1-tolerance:high=middle
            else:low=middle
        minima.append(high)
    return {'status':'bounded_policy_plan','integer_minima':dict(zip(NAMES,minima)),
            'contexts':contexts,'target_global_policy_probability':target,'failure_tolerance_per_component':tolerance,
            'interpretation':'Union-bound target conditional on true planning probabilities. Apply these context-specific bounds to all contexts. Equal error allocation is conservative; this does not optimize the full support constraint or guarantee bootstrap/optimizer success or power.'}


def allocation_with_minima(b,t,d0,d1,budget,minima,costs=(1,)*8):
    """Regular variance optimum with fixed per-component lower bounds."""
    budget=finite_positive(budget)
    if len(minima)!=8 or len(costs)!=8:
        raise ValueError('Eight integer minima and costs required')
    minima=[count(x) for x in minima];costs=[finite_positive(c) for c in costs]
    aa=coefficients(b,t,d0,d1)
    minimum_cost=sum(x*c for x,c in zip(minima,costs))
    if not math.isfinite(minimum_cost):
        raise ValueError('Planning floor cost exceeds numerical precision')
    if minimum_cost>budget:
        return {'status':'budget_infeasible_for_chosen_minima','minimum_cost':minimum_cost,'budget':budget,
                'interpretation':'The chosen support-policy floors cannot fit this budget; do not hide the conflict by replacing missing counts.'}
    slopes=[math.sqrt(a/c) for a,c in zip(aa,costs)]
    if not all(math.isfinite(s) and s>0 for s in slopes):
        raise ValueError('Planning slopes exceed numerical precision')
    def allocation(scale):return [max(l,scale*s) for l,s in zip(minima,slopes)]
    if budget==minimum_cost:
        totals=[float(x) for x in minima]
    else:
        low,high=0.,1.
        while sum(c*x for c,x in zip(costs,allocation(high)))<budget:
            high*=2
            if not math.isfinite(high):
                raise ValueError('Planning bracket exceeds numerical precision')
        for _ in range(80):
            mid=(low+high)/2
            if sum(c*x for c,x in zip(costs,allocation(mid)))>budget:high=mid
            else:low=mid
        totals=allocation(low)
    integer=[max(l,math.floor(x)) for l,x in zip(minima,totals)]
    integer_cost=sum(c*x for c,x in zip(costs,integer))
    return {'status':'feasible_given_minima','continuous_allocation':dict(zip(NAMES,totals)),
            'integer_allocation_floor':dict(zip(NAMES,integer)),'minimum_cost':minimum_cost,
            'budget':budget,'integer_cost':integer_cost,'unspent_budget':budget-integer_cost,
            'continuous_regular_variance':sum(a/n for a,n in zip(aa,totals)),
            'integer_regular_variance':sum(a/n for a,n in zip(aa,integer)),
            'interpretation':'Continuous variance optimum for the specified floors. Integer floors retain the policy minima and budget, but are not an integer optimum and may leave budget unspent. This does not optimize full finite-sample power.'}


def transport_bias_bounds(lower,upper):
    """Bounds for differential sample/control log mismatch; normalizers cancel."""
    if len(lower)!=3 or len(upper)!=3:
        raise ValueError('Three finite route bounds required')
    for x in (*lower,*upper):
        if isinstance(x,bool) or not isinstance(x,Real) or not math.isfinite(x):
            raise ValueError('Finite numeric bounds required')
    if any(a>b for a,b in zip(lower,upper)):
        raise ValueError('Invalid route bound order')
    lo=sum(w*(a if w>=0 else b) for w,a,b in zip(V,lower,upper))
    hi=sum(w*(b if w>=0 else a) for w,a,b in zip(V,lower,upper))
    return lo,hi


def demonstration():
    p=(1/3,)*3
    d=(.5,)*3
    typical={'b':p,'t':p,'m':100,'n':100,'d0':d,'d1':d,'L0':[100]*3,'L1':[100]*3}
    high=dict(typical,m=600,n=600,d0=[.99]*3,d1=[.99]*3)
    high_minima=minimum_policy_totals(p,p,[.99]*3,[.99]*3)
    high_floor_values=list(high_minima['integer_minima'].values())
    return {'provenance':'analytic_planning_examples_not_measurements','externally_novel_math_claimed':False,
        'uniform_biological_100_and_six_controls_100_each_at_recovery_half':contrast_variance(p,p,d,d,100,100,[100]*3,[100]*3),
        'fixed_control_trial_budget_600_equals_300_expected_recoveries':{'control_variance':.03,
            'random_mixture_control_budget_300_expected_recoveries_assuming_uniform_composition_and_common_recovery_variance':.06,
            'interpretation':'Fixed labels can contain additional recovery information; this selected equal-cost/yield comparison is not a universal efficiency ranking and input preparation costs may differ.'},
        'eight_sample_allocation_budget_800_equal_costs':optimal_allocation(p,p,d,d,800),
        'dense_policy_probability_four_contexts':supported_cell_probability([typical]*4,True),
        'near_perfect_recovery_0_99_with_100_introduced_per_route_four_contexts':supported_cell_probability([high]*4,True),
        'near_perfect_recovery_minima_for_global_policy_probability_0_95':high_minima,
        'near_perfect_recovery_budget_800_conflicts_with_chosen_minima':allocation_with_minima(p,p,[.99]*3,[.99]*3,800,high_floor_values),
        'transport_bias_bounds_at_symmetric_log_error_0_1':list(transport_bias_bounds([-.1]*3,[.1]*3))}


if __name__=='__main__':
    output=demonstration()
    (Path(__file__).parent/'fixed_input_design_results.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))
