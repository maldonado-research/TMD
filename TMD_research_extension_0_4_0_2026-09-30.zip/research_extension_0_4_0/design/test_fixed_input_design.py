import itertools
import math
import unittest
from fixed_input_design import (V,coefficients,contrast_variance,optimal_allocation,
    binomial_interior_probability,categorical_positive_probability,supported_cell_probability,transport_bias_bounds,
    minimum_policy_totals,allocation_with_minima)


class FixedDesignTests(unittest.TestCase):
    def test_binary_support_against_enumeration(self):
        for L in (1,2,5,10):
            for d in (.03,.5,.99):
                expected=sum(math.comb(L,k)*d**k*(1-d)**(L-k) for k in range(1,L))
                self.assertAlmostEqual(binomial_interior_probability(L,d),expected,places=13)

    def test_categorical_support_against_ordered_draws(self):
        p=[.1,.3,.6]
        for n in range(1,7):
            expected=0
            for draws in itertools.product(range(3),repeat=n):
                if len(set(draws))==3:
                    expected+=math.prod(p[i] for i in draws)
            self.assertAlmostEqual(categorical_positive_probability(n,p),expected,places=13)

    def test_delta_control_information_by_exact_binomial_variance(self):
        L,d=250,.4
        # Var(K/L)=d(1-d)/L; derivative log(d)=1/d.
        delta=(d*(1-d)/L)/(d*d)
        self.assertAlmostEqual(delta,(1-d)/(L*d))
        p=[1/3]*3
        result=contrast_variance(p,p,[.5]*3,[.5]*3,100,100,[100]*3,[100]*3)
        self.assertAlmostEqual(result['variance_regular'],.12)
        self.assertAlmostEqual(result['standard_error_regular'],math.sqrt(.12))

    def test_cost_optimum_and_budget_with_mixed_sample_units(self):
        b,t=[.2,.3,.5],[.1,.5,.4]
        d0,d1=[.1,.6,.7],[.3,.8,.2]
        costs=[2,3,1,2,3,1,2,3]
        result=optimal_allocation(b,t,d0,d1,2000,costs)
        n=list(result['continuous_allocation'].values())
        a=coefficients(b,t,d0,d1)
        self.assertAlmostEqual(sum(x*c for x,c in zip(n,costs)),2000)
        self.assertAlmostEqual(sum(x/y for x,y in zip(a,n)),result['minimum_regular_variance'])
        lagrange=[x/(y*y*c) for x,y,c in zip(a,n,costs)]
        self.assertLess(max(lagrange)-min(lagrange),1e-12)
        altered=n.copy();altered[0]+=5;altered[1]-=5*costs[0]/costs[1]
        self.assertGreater(sum(x/y for x,y in zip(a,altered)),result['minimum_regular_variance'])

    def test_extreme_success_probabilities_predict_policy_not_power(self):
        ctx={'b':[1/3]*3,'t':[1/3]*3,'m':600,'n':600,
             'd0':[.99]*3,'d1':[.99]*3,'L0':[100]*3,'L1':[100]*3}
        result=supported_cell_probability([ctx]*4,True)
        expected=(1-.99**100-(.01)**100)**24
        self.assertAlmostEqual(result['probability_of_all_supported_cells'],expected)
        self.assertLess(result['probability_of_all_supported_cells'],.0001)
        self.assertIn('not optimizer success',result['interpretation'])

    def test_positive_cell_probability_limit_and_declared_independence(self):
        self.assertAlmostEqual(categorical_positive_probability(100000,[.1,.2,.7]),1)
        ctx={'b':[1/3]*3,'t':[1/3]*3,'m':2,'n':100,
             'd0':[.5]*3,'d1':[.5]*3,'L0':[100]*3,'L1':[100]*3}
        self.assertEqual(supported_cell_probability([ctx],True)['probability_of_all_supported_cells'],0)
        with self.assertRaises(ValueError):
            supported_cell_probability([ctx])

    def test_transport_bounds_against_corners(self):
        lower,upper=[-.2,-.4,.1],[.3,.5,.7]
        corners=[sum(w*x for w,x in zip(V,point)) for point in itertools.product(*zip(lower,upper))]
        self.assertEqual(transport_bias_bounds(lower,upper),(min(corners),max(corners)))

    def test_invalid_boundary_string_and_fractional_counts_decline(self):
        for bad in (0,True,'5',2.5):
            with self.assertRaises(ValueError):
                binomial_interior_probability(bad,.5)
        with self.assertRaises(ValueError):
            binomial_interior_probability(20,1)
        with self.assertRaises(ValueError):
            categorical_positive_probability(20,[.2,.2,.2])
        with self.assertRaises(ValueError):
            transport_bias_bounds([1]*3,[0]*3)

    def test_minima_attain_conditional_support_target_and_are_componentwise_minimal(self):
        p=[1/3]*3;d=[.99]*3
        plan=minimum_policy_totals(p,p,d,d,contexts=4,target=.95)
        n=list(plan['integer_minima'].values())
        tol=plan['failure_tolerance_per_component']
        functions=[lambda x:categorical_positive_probability(x,p)]*2+[
            lambda x:binomial_interior_probability(x,.99)]*6
        for N,fun in zip(n,functions):
            self.assertGreaterEqual(fun(N),1-tol)
            self.assertLess(fun(N-1),1-tol)
        ctx={'b':p,'t':p,'d0':d,'d1':d,'m':n[0],'n':n[1],'L0':n[2:5],'L1':n[5:8]}
        self.assertGreaterEqual(supported_cell_probability([ctx]*4,True)['probability_of_all_supported_cells'],.95)
        self.assertEqual(allocation_with_minima(p,p,d,d,800,n)['status'],'budget_infeasible_for_chosen_minima')

    def test_allocation_with_floors_is_feasible_and_satisfies_kkt(self):
        p=[1/3]*3;d=[.5]*3
        floors=[100,40,60,10,60,10,10,10]
        result=allocation_with_minima(p,p,d,d,500,floors)
        x=list(result['continuous_allocation'].values())
        integer=list(result['integer_allocation_floor'].values())
        a=coefficients(p,p,d,d)
        self.assertAlmostEqual(sum(x),500)
        self.assertTrue(all(n>=l for n,l in zip(x,floors)))
        self.assertTrue(all(n>=l for n,l in zip(integer,floors)))
        self.assertLessEqual(sum(integer),500)
        free=[aa/(n*n) for aa,n,l in zip(a,x,floors) if n>l+1e-8]
        self.assertLess(max(free)-min(free),1e-12)
        self.assertTrue(all(aa/(n*n)<=free[0]+1e-12 for aa,n,l in zip(a,x,floors) if abs(n-l)<1e-8))
        unchanged=allocation_with_minima(p,p,d,d,sum(floors),floors)
        self.assertEqual(list(unchanged['integer_allocation_floor'].values()),floors)

    def test_planning_cap_cannot_be_mistaken_for_feasibility(self):
        p=[1/3]*3
        result=minimum_policy_totals(p,p,[.9999]*3,[.9999]*3,max_per_component=10)
        self.assertEqual(result['status'],'planning_cap_exceeded')

    def test_numerically_unresolved_coefficients_decline_before_allocation(self):
        p=[1/3]*3
        with self.assertRaises(ValueError):
            coefficients([1e-320,.5,.5],p,[.5]*3,[.5]*3)
        with self.assertRaises(ValueError):
            optimal_allocation(p,p,[1e-320,.5,.5],[.5]*3,800)


if __name__=='__main__':
    unittest.main()
