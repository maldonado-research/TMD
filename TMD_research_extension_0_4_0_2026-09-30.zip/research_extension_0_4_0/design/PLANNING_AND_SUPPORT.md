# Fixed-input control planning: uncertainty, support and budget

Version 0.4.0 applies standard binomial/multinomial information, occupancy probabilities, union bounds and constrained allocation. This is new implemented capability within the project, not a claim of new mathematical priority. All numerical examples are analytic planning illustrations.

## Count the correct denominator

Biological baseline and selected sample sizes M and N are **recovered independent categorical observations**. Each control trial count L_branch,route is an **introduced independent unit** with one prespecified success/failure endpoint. Costs must reflect these different units. A sequencing read, a colony descended from a reused unit, a nominal concentration or an unverified sorted event does not automatically supply an introduced-cell denominator.

In route order W,A,M, let v=(−1/2,1,−1/2), observed biological probabilities b and t, and control recovery probabilities d0,d1. Under route-relative recovery transport, the corrected contrast is v·[log(t)−log(b)−log(d1)+log(d0)]. Independent regular-model variance is:

```text
A(x) = sum_i v_i²/x_i
Var(theta_corrected) ≈ A(b)/M + A(t)/N
                     + sum_i v_i² (1−d0_i)/(L0_i d0_i)
                     + sum_i v_i² (1−d1_i)/(L1_i d1_i)
```

The control term follows Var(d_hat)≈d(1−d)/L and the derivative of log(d), or inverse expected Fisher information for log(d). The binomial **observed** Hessian is (L−k)d/(1−d)²; expected Fisher information is Ld/(1−d). They coincide when k=Ld. The joint fit's inverse observed-Hessian standard error and this expected-information planning approximation need not coincide exactly for noisy constrained tables.

An equal-frequency illustration with 100 recovered biological observations per arm and 100 introduced units per route/branch, each recovered with probability 0.5, gives variance 0.12 and standard error 0.3464. Both controls' uncertainty is included. These counts are not recommended biological sample sizes.

Across six control cells this costs 600 introduced units and yields 300 expected recovered units. Their variance contribution is 0.03. A 0.3.0 conditional-mixture comparison with uniform recovered route composition and 150 recovered controls in each branch gives 0.06. The fixed-input design records route-specific successes and failures, information discarded by a conditional recovered-label likelihood. This selected equal-yield illustration is not a universal design ranking: actual input preparation, losses, independence and costs can differ.

## A precision optimum is not automatically an analyzable experiment

Write the eight variance terms as sum_g A_g/n_g. For costs c_g and budget B, the unconstrained continuous optimum is:

```text
n_g = B sqrt(A_g/c_g) / sum_h sqrt(A_h c_h)
```

The first two coefficients are A(b),A(t); the six others are v_i²(1−d)/d. When recovery approaches one, the regular binomial coefficient becomes small. That does not guarantee the conservative prototype can analyze the resulting small sample. It declines any observed categorical zero, and any control k=0 or k=L, without asserting that every such table has an infinite or boundary null MLE.

For a specified binomial control:

```text
P(0<K<L) = 1 − (1−d)^L − d^L
```

For a specified three-category multinomial, N≥1:

```text
P(all three counts positive) = 1 − sum_i(1−p_i)^N + sum_i p_i^N
```

For N<3 the probability is zero. Under independence, multiply these eight probabilities per context across all contexts. This gives the exact model probability of passing the **zero/extreme-cell policy**, not the probability of successful optimization, resolved bootstrap inference, biological admission or detection of an alternative. The formulas are evaluated in floating arithmetic; negligible tails may round to zero or one.

If all six controls per context have d=0.99 and L=100, each has probability 0.6340 of an interior count. Across four contexts, the 24-control probability is about 0.00001777, or0.001777%, with biological positivity essentially one in the stated uniform 600-observation example. Almost every such study would be declined by this software policy. This is a limitation of the supported inference, not proof that high recovery makes an experiment biologically poor. A validated boundary likelihood could use information this prototype declines.

## Minimum counts and honest budget conflicts

`minimum_policy_totals` divides an allowed global policy-failure probability 1−target equally among 8C components. It finds the smallest integer total for each marginal support probability to exceed 1−(1−target)/(8C), using monotone bracketing and binary search. The union bound then gives overall policy support at least target **conditional on the stated true planning probabilities and marginal count models**. Independence is not needed for the union bound itself; the current joint inferential model still requires independence.

For heterogeneous contexts, compute each context's floors with its own b,t,d0,d1 and the same global C and target. Floors computed for a different probability vector do not transport automatically. Equal failure-budget allocation is conservative and does not globally minimize study cost. The declared search cap returns `planning_cap_exceeded`; it does not fabricate a feasible count. Uncertain pilot probabilities require a defended worst-case envelope or an expanded design study, not treating estimated rates as known.

At d=0.99, uniform biological routes, four contexts and target 0.95, the chosen equal-error floors are 19 recovered observations per biological arm and 643 introduced units per route/branch. With all eight unit costs set to one, the floor costs 3896 per context. A budget 800 per context cannot meet those particular floors. This is a transparent model-based budget conflict, not a laboratory cost quote or a proof that every alternative design needs 3896 units.

`allocation_with_minima` minimizes the regular variance subject to these fixed component floors and budget. The continuous KKT solution is n_g=max(lower_g,s sqrt(A_g/c_g)), with s chosen to spend the budget. If the floor cost exceeds the budget it returns `budget_infeasible_for_chosen_minima`. Flooring continuous totals to integers preserves the integer minima and budget, but can leave funds unspent and is not an integer optimum. This solves a regular-variance problem for chosen floors, not the full power, support or experimental-validity design problem.

## Transport still matters

If biological recovery is control recovery times branch/route factor h, the corrected contrast has residual bias v·[log(h1)−log(h0)]. Assay-wide factors cancel; arbitrary route-specific mismatch remains confounded. The signed interval helper retains the 0.3.0 box-bias calculation. A control binomial denominator identifies absolute **control-process** recovery, not absolute biological recovery under relative transfer alone.

## Reproduce and verify

```sh
python3 design/fixed_input_design.py
python3 -m unittest discover -s design -p 'test_fixed_input_design.py' -v
```

Checks compare the support formulas with explicit finite enumeration, derive log-recovery variance independently, verify budget and KKT conditions with and without floors, test componentwise-minimal support floors, keep cap/budget failures explicit and reject numerically unresolved coefficients. The JSON examples contain no measurements or power estimates.
