# In More Basic Terms: count what went in and what came back

Imagine trying to compare three routes through a maze. You see how many travelers reach each exit, but one route may be easier to observe than another. A crowded exit could mean more travelers chose that route—or simply that fewer of them were missed.

Our new method checks that problem by keeping two numbers for each control route: how many independent units went in, and how many came back through the chosen detection step. If 100 verified cells were introduced and 60 met the recovery rule, the control recovery estimate starts at 60%. A camera reading the same cell twice does not make two independent trials. A sorting event containing two cells is also different from one verified cell.

That information helps adjust the biological comparison and includes the uncertainty of the adjustment. It does not mean the control cells behave exactly like evolving cells. We still need to check that the relevant recovery differences carry over to the real experiment.

## Why a very good recovery rate can still cause a software problem

Suppose a route recovers about 99% of introduced cells. A small control sample may recover every cell. The current conservative test is designed for samples containing both successes and failures, so it declines an answer when every control succeeds. That is a limit of this version of the method; it does not make excellent recovery a bad thing.

The new planner checks for that issue before recommending counts. It can say, “Your chosen budget cannot meet these minimum counts.” That is more useful than a precise-looking calculation built around an experiment the current test cannot analyze. The planner still depends on its assumptions about the real probabilities, costs and independence.

## What we have actually achieved

We have added and checked a tool for a specific kind of control experiment. In simulated examples, it removes a false difference caused by recovery and still detects a deliberately built-in biological difference. Other simulated experiments show its practical limits.

Those examples do not prove Mutation by Natural Dominance. The next important step is to apply the method to a suitable real panel, with clear records and controls that match the observation process. We should be able to explain what would count against the hypothesis just as clearly as what would support it.
