# Independent calibration and summary-claim review

**PASS.** The calibration author confirmed all five calibration artifacts final/frozen before this review. No inference, calibration, design or root summary file was edited. An independently written verification runner and receipt are in this audit directory.

## Verified records and likelihood use

All six recorded runner/inference/solver/generator/fixture source hashes match the final files. Each separately recorded planner hash also matches the final planner, and the calibration artifact manifest matches its four listed artifacts. Calibration files were unchanged before/after verification.

The three generators were reconstructed independently from rational probabilities, latent q/p and route-control efficiencies. Dense null truth is theta=log(2) throughout; dense departure changes only context four to log(4). The high-recovery generator preserves the null latent q/p, sets all control efficiencies to .99, and correctly recomputes observed compositions. Route-relative transport is exact by construction; no biological transport claim follows.

All **120** categorical/control count tables reproduce exactly from their saved seeds. Every categorical context/branch total is 600. Dense introduced totals are 600 **per route/branch**, and high-recovery totals are 100 per route/branch. The spawned seed tree and all 240 data/bootstrap seeds match, with no reused seed. Independent multinomial and binomial draws match the specified model; all datasets, including policy declines, are retained.

For every admitted fit, stored bootstrap exceedances were independently recounted using the recorded tolerance. P-values and computational bounds match (1+E)/100 at 99 draws, and decisions correctly use the upper/lower bounds at .05. All **7,920** attempted dense bootstrap draws resolved. Six dense datasets—indices 0, 19 and 39 in both scenarios—were fully replayed through the final API, reproducing their **594** statistics and decisions to numerical tolerance. This does not claim all 7,920 draws were rerun.

| Scenario | Fit admissions | Rejections among admitted | Bootstrap draws attempted |
| --- | ---: | ---: | ---: |
| Dense shared theta | 40/40 | 1/40 | 3,960 |
| Dense departure | 40/40 | 33/40 | 3,960 |
| High recovery, d=.99 and L=100 | 0/40 | Not tested | 0 |

All 40 high-recovery records correctly report `extreme_binomial_not_supported`. Their 3,960 potential bootstrap draws were not attempted. Their rejection fraction is undefined, not zero statistical nonrejections. Admission, testing and unresolved-draw denominators are kept separate, with no replacements.

## Independent support and uncertainty checks

A separate 100-digit Decimal calculation from rational inputs reproduced every recorded 80-digit support oracle. It multiplies eight categorical occupancy probabilities `1−sum(1−p)^600+sum(p^600)` and 24 control interior probabilities `1−d^L−(1−d)^L`. High-recovery policy admission is approximately **1.7766851793×10^-5**, agreeing with the planner to floating-point tolerance. Expected admissions in 40 are .000710674; zero admissions has model probability .999289572. This predicts the support-policy event only, not optimizer success, resolved inference or biological eligibility.

All support/fit/rejection and per-dataset bootstrap-tail Wilson intervals were independently checked by solving their score-interval quadratic. Dense rejection intervals are [.004427,.128814] for 1/40 and [.680500,.912546] for 33/40. These concern fixed synthetic scenarios and the finite-bootstrap decision procedure. The null interval includes .05; neither empirical 2.5% rejection nor 82.5% departure detection establishes general test size or power. At 99 draws, p resolution is .01 and Monte Carlo decisions near .05 are variable. High-recovery admission interval [0,.087622] does not validate a boundary likelihood.

## Summary claims

`README.md`, `SCIENTIFIC_PROGRESS.md` and `IN_MORE_BASIC_TERMS.md` consistently distinguish synthetic checks from biological validation, absolute control recovery from unknown biological branch-wide scales, and policy declines from nonrejection. The initially imprecise convex-likelihood wording was corrected to **joint negative log likelihood convex in log-recovery coordinates u=log(d)<0**. The README now describes observed samples explicitly. No further required model/statistical claim edit was found. Literature findings and reference-inventory scope belong to their separate evidence audits.

Reproduce this review with `python audit/verify_calibration_review.py` from the 0.4.0 package root. `CALIBRATION_REVIEW_RECEIPT.json` records reviewed calibration hashes and verification totals. No exact finite-sample calibration, global power, mechanism validation or real experimental sample-size guarantee is claimed.
