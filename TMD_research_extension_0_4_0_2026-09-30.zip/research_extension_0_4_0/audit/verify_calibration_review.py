"""Independent read-only 0.4.0 calibration audit; writes no source artifacts.
Copyright (c) 2026 Ricardo Maldonado. MIT; see ../inference/LICENSE.
"""
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys
import numpy as np

BASE=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(BASE/'inference'))
from fixed_route_control_inference import bootstrap_fixed_route_controls


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def wilson_independent(k,n):
    if not n:return None
    z=1.959963984540054;a=n+z*z;b=-(2*k+z*z);c=k*k/n
    disc=math.sqrt(max(0.,b*b-4*a*c))
    return [max(0.,(-b-disc)/(2*a)),min(1.,(-b+disc)/(2*a))]

def assert_close(actual,expected):
    if expected is None:assert actual is None
    else:np.testing.assert_allclose(actual,expected,rtol=0,atol=1e-12)


def main():
    calibration=BASE/'calibration'
    frozen={name:sha(calibration/name) for name in ('run_repeated_sample_calibration.py','repeated_sample_results.json','sampled_counts.json','CALIBRATION.md','artifact_hashes.json')}
    results=json.loads((calibration/'repeated_sample_results.json').read_text())
    counts_only=json.loads((calibration/'sampled_counts.json').read_text())
    manifest=json.loads((calibration/'artifact_hashes.json').read_text())
    assert all(sha(calibration/name)==h for name,h in manifest['sha256'].items())
    assert results['source_sha256']==counts_only['source_sha256']
    assert all(sha(BASE/name)==h for name,h in results['source_sha256'].items())
    assert results['configuration']['master_seed']==counts_only['master_seed']==2026100104
    scenario_seeds=np.random.SeedSequence(2026100104).spawn(3)
    summaries=[];all_data_seeds=[];all_bootstrap_seeds=[];replays=0;resolved_draws=0;not_attempted=0
    for scenario,simple,seed in zip(results['scenarios'],counts_only['scenarios'],scenario_seeds):
        name=scenario['scenario'];g=scenario['generator'];assert name==simple['scenario'] and g==simple['generator']
        assert len(scenario['records'])==len(simple['records'])==40
        fixture=json.loads((BASE/g['source_fixture']).read_text())
        exact=[[[Fraction(v) for v in row] for row in context] for context in g['observed_probabilities_exact_rational']]
        latent=[[[Fraction(v) for v in row] for row in context] for context in g['latent_baseline_selected_exact_rational']]
        dexact=[[[Fraction(v) for v in row] for row in context] for context in g['control_efficiencies_exact_rational']]
        probabilities=np.array([[[float(v) for v in row] for row in context] for context in exact])
        efficiencies=np.array([[[float(v) for v in row] for row in context] for context in dexact])
        np.testing.assert_array_equal(probabilities,g['observed_probabilities'])
        np.testing.assert_array_equal(efficiencies,g['control_efficiencies'])
        L=np.asarray(g['introduced_each_route_branch']);high=name=='high_recovery_support_stress'
        assert L.shape==(4,2,3) and np.all(L==(100 if high else 600))
        truths=[]
        for j,truth in enumerate(fixture['generating_parameters']):
            np.testing.assert_allclose([[float(v) for v in row] for row in latent[j]],[truth['q'],truth['p']],rtol=0,atol=1e-14)
            if high:assert all(v==Fraction(99,100) for row in dexact[j] for v in row)
            else:np.testing.assert_allclose(efficiencies[j],[truth['control_d0'],truth['control_d1']],rtol=0,atol=1e-14)
            for branch in range(2):
                weights=[v*d for v,d in zip(latent[j][branch],dexact[j][branch])]
                assert [v/sum(weights) for v in weights]==exact[j][branch]
            ratio=probabilities[j,1]*efficiencies[j,0]/(probabilities[j,0]*efficiencies[j,1])
            truths.append(math.log(ratio[1]/math.sqrt(ratio[0]*ratio[2])))
        expected_truth=[math.log(2)]*4
        if name=='dense_context_departure':expected_truth[-1]=math.log(4)
        assert_close(truths,expected_truth);assert_close(g['generating_corrected_theta'],expected_truth)
        check=g['support_planner_check'];assert sha(BASE/'design/fixed_input_design.py')==check['planner_source_sha256']
        with localcontext() as context:
            context.prec=100;one=Decimal(1);product=one
            cv=lambda value:Decimal(value.numerator)/Decimal(value.denominator)
            for pc,dc in zip(exact,dexact):
                for row in pc:
                    pp=[cv(v) for v in row]
                    product*=one-sum((one-p)**600 for p in pp)+sum(p**600 for p in pp)
                for row in dc:
                    for value in row:
                        d=cv(value);introduced=100 if high else 600
                        product*=one-d**introduced-(one-d)**introduced
            assert abs(product-Decimal(check['independent_80_digit_finite_probability']))<Decimal('1e-75')
        support_probability=float(product)
        assert_close(check['planner']['probability_of_all_supported_cells'],support_probability)
        decisions=Counter();fit_status=Counter();support_count=0;admitted_count=0;attempted=0;failures=0;rejected=0
        for record,short,ds in zip(scenario['records'],simple['records'],seed.spawn(40)):
            assert all(record[key]==value for key,value in short.items())
            dseed,bseed=ds.spawn(2)
            di=int(dseed.generate_state(1,dtype=np.uint64)[0]);bi=int(bseed.generate_state(1,dtype=np.uint64)[0])
            assert record['dataset_seed']==di and record['bootstrap_seed']==bi
            all_data_seeds.append(di);all_bootstrap_seeds.append(bi)
            rng=np.random.default_rng(di)
            n=np.array([[rng.multinomial(600,p) for p in pc] for pc in probabilities]);k=rng.binomial(L,efficiencies)
            np.testing.assert_array_equal(n,record['categorical_counts']);np.testing.assert_array_equal(k,record['control_recovered_counts'])
            assert np.all(n.sum(axis=2)==600) and np.all(k>=0) and np.all(k<=L)
            supported=bool(np.all(n>0) and np.all(k>0) and np.all(k<L));assert record['passes_supported_cell_policy']==supported
            support_count+=supported;b=record['bootstrap_result'];fit=b['fit'];fit_status[fit['status']]+=1
            admitted=fit['inference_status']=='estimable';assert record['fit_admitted']==admitted;admitted_count+=admitted
            if not admitted:
                assert b['status']=='not_evaluable' and b['p_value'] is None and 'replicates' not in b
                assert record['decision_at_5_percent']=='not_tested_dataset_fit'
                assert record['bootstrap_tail_wilson_95_given_resolved'] is None
                assert high and fit['status']=='extreme_binomial_not_supported'
                decision='not_tested_dataset_fit';not_attempted+=99
            else:
                assert not high and fit['status']=='interior' and fit['regular_degrees_of_freedom']==3
                assert b['replicates']==99 and b['seed']==bi
                statistics=np.asarray(b['bootstrap_statistics']);unresolved=b['unresolved_replicates']
                assert len(statistics)+unresolved==99 and np.all(np.isfinite(statistics)) and np.all(statistics>=0)
                exceed=int(np.sum(statistics>=fit['deviance']-b['comparison_tolerance']))
                assert exceed==b['exceedances']
                bounds=[(1+exceed)/100,(1+exceed+unresolved)/100]
                assert b['p_value_computational_bounds']==bounds
                assert b['p_value']==(bounds[0] if unresolved==0 else None)
                decision='reject' if bounds[1]<=.05 else ('do_not_reject' if bounds[0]>.05 else 'unresolved_bootstrap')
                assert record['decision_at_5_percent']==decision
                assert_close(record['bootstrap_tail_wilson_95_given_resolved'],wilson_independent(exceed,99) if not unresolved else None)
                fitted=np.asarray(fit['fitted_observed_probabilities']);d=np.asarray(fit['absolute_control_recovery_probabilities'])
                ll=float(np.sum(n*np.log(fitted))+np.sum(k*np.log(d)+(L-k)*np.log1p(-d)))
                assert abs(ll-fit['loglik_null'])<1e-8
                assert abs(2*(fit['loglik_saturated']-ll)-fit['deviance'])<1e-8
                attempted+=99;failures+=unresolved;resolved_draws+=len(statistics);rejected+=decision=='reject'
                if record['dataset_index'] in (0,19,39):
                    replay=bootstrap_fixed_route_controls(n,L,k,99,bi)
                    assert replay['status']==b['status'] and replay['p_value']==b['p_value']
                    np.testing.assert_allclose(replay['bootstrap_statistics'],statistics,rtol=0,atol=1e-9);replays+=1
            decisions[decision]+=1
        summary=scenario['summary'];assert summary['datasets_generated_and_retained']==40
        assert summary['support_policy_passes']==support_count and summary['fit_admitted']==admitted_count
        assert summary['support_policy_declines']==40-support_count and summary['fit_not_evaluable']==40-admitted_count
        assert summary['fit_status_counts']==dict(fit_status)
        assert summary['decision_counts']=={key:decisions[key] for key in ('reject','do_not_reject','unresolved_bootstrap','not_tested_dataset_fit')}
        assert_close(summary['support_policy_admission_wilson_95'],wilson_independent(support_count,40))
        assert_close(summary['fit_admission_wilson_95'],wilson_independent(admitted_count,40))
        assert_close(summary['rejection_wilson_95_among_fit_admitted'],wilson_independent(rejected,admitted_count))
        assert summary['bootstrap_draws_attempted']==attempted and summary['bootstrap_draws_unresolved']==failures==0
        assert summary['bootstrap_draws_requested_for_fit_admitted']==admitted_count*99
        assert summary['bootstrap_draws_if_all_datasets_fit_admitted']==3960
        assert summary['bootstrap_draws_not_attempted_due_to_dataset_fit']==(40-admitted_count)*99
        assert summary['rejection_fraction_bounds_among_fit_admitted']==([rejected/admitted_count]*2 if admitted_count else None)
        assert summary['rejection_count_computational_bounds_among_fit_admitted']==[rejected,rejected]
        assert_close(summary['predicted_support_admission_probability'],support_probability)
        assert_close(summary['predicted_number_support_admitted'],40*support_probability)
        assert_close(summary['probability_zero_support_admitted_under_generator'],(1-support_probability)**40)
        summaries.append({'scenario':name,'supported':support_count,'fit_admitted':admitted_count,'rejected':rejected,
                          'attempted_bootstraps':attempted,'policy_admission_probability':support_probability})
    assert len(set(all_data_seeds+all_bootstrap_seeds))==240
    assert replays==6 and resolved_draws==7920 and not_attempted==3960
    assert all(sha(calibration/name)==h for name,h in frozen.items())
    return {'result':'PASS','calibration_artifacts_sha256':frozen,'recorded_source_hashes_verified':len(results['source_sha256']),
            'generated_count_tables_replayed':120,'complete_dense_bootstrap_replays':replays,'replayed_inner_draws':replays*99,
            'resolved_draws_accounted':resolved_draws,'unattempted_draws_for_declined_datasets':not_attempted,'scenarios':summaries}

if __name__=='__main__':print(json.dumps(main(),indent=2))
