# Fixed-input recovery extension: local references and independent derivation

This read-only scoped audit extends the0.2.0 and0.3.0 inventories. Labels `TMD_ARCHIVE/` and `TMD_VECTOR_STORE/` identify relevant local reference roots without publishing private paths. No original file or archive was edited, extracted, executed or published.

## Empirical availability and prior work

No authenticated fixed-route introduced/recovered recovery-control observations or new independently matched supply dataset were found in the inspected material. The current fixed-input examples must therefore remain synthetic. Uninspected archives, four unavailable synced project sources and unpublished laboratory records remain outside this negative claim.

The older folder194 success/total template is a disabled blank conditional route assay: H482R among H482-family isolates in LB/SMM. Its companion note uses separate Beta posteriors and ratio summaries. Those denominators are endpoint sample totals, not independently introduced control units per route. This supplies established project background for binomial inference, not a recovery dataset.

The older submission reviewer checklist requests spike-ins generically. `09_Binomial_Evidence.md` explicitly calls its n=5000 result a first-fix demo; it is neither an independent recovery assay nor a new measurement. Folder197's assay scorecard supplies planning frequencies, projected sample sizes and suggested mechanistic assays. Its suggested emergence, competition and developmental proxies cannot be reclassified as route-recovery counts.

Version0.3.0 already distinguishes random input mixtures conditional on recovered totals from fixed route inputs and explicitly defers their binomial likelihood. Accordingly, implementing that previously deferred fixed-input observation model is a project software/methods advance. Binomial inference, negative controls, spike-ins, log-recovery parameters and Fisher information are not externally new concepts.

The file lists were examined first, then918 unique small TMD text files were screened with narrow introduced/exposed/recovered, denominator, fixed-input and spike-in terms. Directly read strongest relevant evidence is inventoried with hashes. Validation outputs and copies of reviewed releases were excluded; unrelated personal folders were not examined. No assertion that all archive members were inspected is made.

## Independent sign and parameter-count derivation

Let b,t be observed baseline and selected route probability vectors, and let d0,d1 be the corresponding control-process recovery probabilities. Under justified route-relative control-to-biological transfer,

```text
b ∝ q*d0,  t ∝ p*d1
u0=log(d0)<0, u1=log(d1)<0
v=(-1/2,1,-1/2)
theta=v·[log(t)−log(b)−u1+u0]
```

A branch-wide difference in biological versus control absolute efficiency cancels from this contrast. Write M-reference baseline odds B_W,B_A and selected odds T_W,T_A. Then

```text
T_A = theta + (1/2)T_W + B_A − (1/2)B_W + v·(u1−u0).
```

The recovery contrast enters with a positive sign in the selected-A logit constraint. Null coordinates are three observed-logit nuisances plus six route/branch log-recovery coordinates per context, and one shared theta:9C+1. The unrestricted alternative has four observed-logit plus six recovery coordinates per context:10C. The regular difference is C−1. One context imposes no shared-contrast restriction.

## Convexity, observed curvature and Fisher information

Independent fixed route inputs give k_ji~Binomial(L_ji,d_ji), with L genuinely introduced eligible independent units. Ignoring constants, control negative log likelihood is

```text
−k*u − (L−k)*log(1−exp(u)),  u<0.
```

This is convex on its domain. Its observed second derivative is `(L−k)*d/(1−d)^2`; expected Fisher information is `L*d/(1−d)`. These are distinct quantities and should be labeled accordingly. At k=L*d they coincide. For0<k<L, the negative likelihood diverges at either u boundary, ensuring finite interior control parameters. Combined with positive biological-category counts and a full reference-logit design, the overall likelihood is strictly convex and has a finite unique interior fit. Success/failure endpoints need a separate boundary treatment or explicit support refusal; they must not be made regular through pseudocounts.

The inverse expected information gives first-order variance of log(k/L) approximately `(1−d)/(L*d)`. With independent baseline, selected and all control route cells,

```text
Var(theta_hat) ≈ A(b)/M + A(t)/N
              + sum_i v_i²*(1−d0_i)/(L0_i*d0_i)
              + sum_i v_i²*(1−d1_i)/(L1_i*d1_i),
A(h)=sum_i v_i²/h_i.
```

Cross-category multinomial terms vanish because sum(v)=0. Binomial control-route contributions differ from the recovered-total multinomial control variance in0.3.0. Repeated cells, shared batches, uncertain introduced L or route classification require a different variance/likelihood. The control denominators count independently exposed units, not reads or clonal descendants.

## Identifiability boundary

The fixed-input denominator identifies **absolute recovery of the specific control process** d=k/L at the unrestricted fit. If transport to biological samples is only route-relative, biological absolute efficiency remains free up to branch-wide scalars. Do not claim that recording control denominators identifies absolute recovery of evolving biological units, opportunity flux or the mutation/accessibility/fitness decomposition. Corrected q,p and theta are identifiable conditional on support, baseline admission and transfer assumptions.

Controls introduced after extraction cannot measure earlier losses or establishment. An independent binomial denominator does not repair an invalid supply assay, off-diagonal misclassification, differential survival, mixing uncertainty or transport failure. Shared-theta nonrejection cannot authenticate those assumptions. Bootstrap sampling must preserve fixed L and sample each control cell binomially, alongside the two multinomial biological arms. Approximate estimated-null calibration and unresolved boundary draws must remain explicit.

## Implementation review status

This section records the preliminary mathematical review. Final frozen-code review is now recorded separately in [INDEPENDENT_METHODS_REVIEW.md](INDEPENDENT_METHODS_REVIEW.md), including18 inference and12 design checks. This reference audit supplies no general operating-characteristic or biological-calibration claim.

## Independent design-helper review

The bundled-Python run passed all8 tests of `design/test_fixed_input_design.py`. The coefficient, continuous mixed-unit allocation and sign-aware transport-bound calculations agree with the derivation above. They minimize unconstrained first-order variance; no minimum success/failure or usable-fit constraint is built into that allocation. Policy-support probability must therefore be examined separately.

Independent enumeration/inclusion-exclusion gives P(0<K<L)=1−(1−d)^L−d^L and, for a three-category sample, P(all categories observed)=1−sum_i(1−p_i)^N+sum_i p_i^N. Products apply only to independent arms/cells/contexts. With d=.99 and L=100 for24 independent control cells, the supported-cell probability is1.7766851793247758e−5; categorical samples with600 uniform observations contribute essentially unit factors. This predicts only satisfying the prototype's zero/extreme-cell policy, not statistical power, biological admission or optimizer success.

In the specified comparison, six fixed-route controls with100 inputs each and d=.5 yield300 expected recovered units and variance contribution .03. Two random-mixture controls with150 recovered observations each and uniform route probabilities contribute .06. The additional input-label/denominator information explains this selected contrast. Costs, yields, nuisance constraints and target precision differ across other designs; no universal efficiency ranking follows. Exact formulas are evaluated numerically in floating-point arithmetic.

## Policy minima and allocation with floors

After the policy-floor helpers were added, the independent design suite passed11 tests. For C contexts there are8C supported-cell components: two categorical occupancy requirements and six binary interior requirements per context. Allocating at most(1−target)/(8C) failure probability to each gives a union-bound global support guarantee conditional on the stated true planning probabilities. The union bound itself does not require cross-component independence. Heterogeneous contexts need their own marginal probabilities and floors, using the same global tolerance; floors cannot be transported from another probability vector.

Support probabilities are monotone in integer sample size. The doubling bracket, bisection to the first satisfying size, and explicit cap-failure status correctly compute componentwise minima under that error allocation. At d=.99,C=4,target=.95, tolerance is .0015625, binary L=643 and uniform categorical N=19 are minimal for their individual thresholds. Equal-unit cost is2*19+6*643=3896 per context, so budget800 is infeasible for these selected floors. This is not a globally minimal-cost support design.

With prescribed floors l_g, KKT conditions give n_g=max(l_g,s*sqrt(A_g/c_g)), with s chosen to spend the continuous budget. Free components have equal A_g/(c_g*n_g²); bound components have no larger value. Bisection in the nonnegative scale is correct because total cost is monotone. Flooring the continuous sizes retains integer floors and does not increase cost, but may waste budget and is not an integer variance optimum. This constrained regular-variance plan still supplies no power, bootstrap-resolution or biological-admission guarantee. Extremely small floating-point probabilities can overflow information coefficients; final design code now checks and declines nonfinite coefficients before allocation. The final design suite passed12 tests after this numerical guard was added.
