# Independent methods review: fixed-route controls,0.4.0

Outcome: the reviewed frozen implementation and formal/design documents passed independent mathematical and observation-contract review. The independent bundled-Python run passed18 inference tests and12 design tests. This is internal agent review, not external peer review, biological validation, certified numerical accuracy or novelty verification. No original research files were changed.

## Independent derivation and model scope

For fixed introduced L and recovered k, the supported observation model combines two categorical samples with six independent Binomial(L,d) control cells per context. Under route-relative transfer, q normalizes b/d0 and p normalizes t/d1. With v=(−1/2,1,−1/2), theta=v·[log(t)−log(b)−log(d1)+log(d0)]. Thus T_A=theta+.5*T_W+B_A−.5*B_W+v·(u1−u0),u=log(d)<0. All recovery signs in the linear design match this independent derivation.

There are3 categorical nuisance coordinates and6 recovery coordinates per context plus shared theta:9C+1. The saturated alternative has4 categorical and6 recovery coordinates per context:10C. The difference is C−1; C=1 imposes no shared-contrast test. Positive categorical cells and both positive control successes/failures supply a strictly convex, coercive interior objective. The proof does not apply automatically to zero/extreme observations.

Independent binomial differentiation gives NLL=−k*u−(L−k)*log(1−exp u), score−k+(L−k)d/(1−d), and observed curvature(L−k)d/(1−d)^2. Expected Fisher information is Ld/(1−d). The control log-recovery variance is approximately(1−d)/(Ld). The implemented four variance contributions, observed-information theta/control standard errors, and observed-versus-expected qualifications are correct. Exact information agreement is checked at noiseless model counts; it is not asserted for arbitrary noisy constrained fits.

Denominators identify absolute recovery of the **control process**. Actual biological absolute recovery can retain unknown branch-wide multipliers under relative transfer; establishment, opportunity flux and biological factorization remain unidentified. The protocol and code preserve this distinction. Fixed input labels/trials are not interchangeable with the0.3.0 conditional random-mixture likelihood. Introduced units are independently verified exposure units, not reads, nominal concentrations or clonal descendants. Transfer remains an admission assumption rather than a conclusion of corrected nonrejection.

## Numerical and inferential behavior

Analytic score/Hessian agree with independently differenced derivatives and the isolated-binomial oracle. Stable log-complement evaluation and domain-shortened Newton steps preserve u<0. Coordinate-specific score tolerances prevent very large controls from relaxing categorical/theta convergence checks. Multiple starts must agree in parameter space. Information, underflow and deviance-precision failures decline inference. The scale-based roundoff screen is properly qualified as a heuristic, not a certified total-error bound.

Missing arms/denominators, categorical zeros and k=0 or k=L are unsupported under a conservative software policy. They are not described as universally having infinite joint MLEs. There is no pseudocount replacement. Bootstrap sampling preserves categorical totals and each fixed introduced L, sampling both categorical arms and all six binomial cells. Unresolved draws stay in exceedance bounds; they are not discarded or resampled until success. Estimated-null calibration and the plus-one convention are correctly labeled approximate, with no exact-size or general-power promise.

## Independent planning check

Binomial interior support is1−d^L−(1−d)^L. Three-category positive support follows inclusion-exclusion:1−sum(1−p_i)^N+sum p_i^N. Exact model probabilities are evaluated in floating arithmetic and only predict passing the supported-cell policy. At d=.99,L=100 across24 independent controls, support is1.7766851793247758e−5, not a power calculation.

The eight-component variance allocation follows Cauchy–Schwarz. With fixed minima, KKT gives n_g=max(minimum_g,s*sqrt(A_g/c_g)); free coordinates have common marginal benefit and floor coordinates no greater benefit. Integer flooring retains prescribed floors/budget but is not a global integer optimum. Costs correctly distinguish recovered categorical observations from introduced control units.

For8C components, equal failure allowance(1−target)/(8C) and marginal monotone minima yield the documented union-bound support target conditional on true planning probabilities. Each heterogeneous context requires its own floors. The target is not a guarantee of optimizer success, usable bootstrap, biological admission or power. Caps, budget conflicts and nonfinite coefficients are explicitly rejected. For the stated d=.99,C=4,target=.95, individual floors N=19 and L=643 cost3896/context under unit costs, making budget800 infeasible for these selected floors. These are conservative chosen floors, not a global cost lower bound over all experimental designs.

## Evidence boundary

Deterministic fixture rescue/departure and minimum p=.005 at199 draws illustrate chosen arithmetic cases. Separate repeated-sample studies must retain their own fixed-scenario uncertainty and all unresolved denominators; no universal calibration follows. The scoped archive audit found no authenticated independent introduced/recovered biological controls. New measured units, independently defended transport and properly specified prediction remain necessary.

No substantive remaining correctness issue was found in the reviewed files. The earlier observed/expected-information, numerical scale, mixed-unit planning and coefficient-overflow concerns are addressed or accurately qualified.

## Reviewed source hashes

- `inference/fixed_route_control_inference.py`: `e75041e2cb02468dd64f0c3c4b458e22f55a91557af361f0f60d70e8c3ac3f75`
- `inference/_fixed_route_convex.py`: `7a70c893c14a21a33b7ebf6107cf3c8b98ea9149b44169997ba86aa811845bfd`
- `inference/test_fixed_route_control_inference.py`: `66c4c7a45b4eab5237e1bffe194fdd394d126c03995c4f771534f69409f59698`
- `design/fixed_input_design.py`: `67149749f49d211e34e466fee248e8abd70b0c8f7e057504b6081a8b1804105b`
- `design/test_fixed_input_design.py`: `47378771135fd9a5a0b88fa2b9a91cd519e5e889faa6a78df8e35d1ec82c11a9`
- `methods/FIXED_ROUTE_BINOMIAL_BRIDGE.md`: `fc9653e9dead661a3af12c052a50d4520497a71202b0acd57da12526a0195140`
- `design/PLANNING_AND_SUPPORT.md`: `7d5f2bd6b262a34221165b79971f3971863438e98453d2b51738260fea9d5ce2`
- `FIXED_INPUT_DATA_CONTRACT.md`: `b658097a338ed4434196b8e76f12bcc2e7ddcdca89b66339cbb500161ceaab6d`
