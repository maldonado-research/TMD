# Fixed-route binomial recovery controls for WS inference

**Status:** proposed observation model and verified software prototype 0.4.0. All numerical fixtures are synthetic. No laboratory observations, biological validation, external mathematical novelty, certified test size or general power are claimed. Historical releases are unchanged. Version 0.3.0 modeled recovered labels from known random input mixtures; this extension models independently introduced, fixed route-specific units with binary recovery outcomes.

## 1. Observation contract and identification

Use routes W,A,M, v=(-1/2,1,-1/2) and s=(1,0,-1). For context c, true baseline q_c and selected p_c satisfy the proposed WS restriction

\[
p_{ci}\propto q_{ci}\exp(\theta_c I_{i=A}+\eta_c s_i).
\]

The null shares theta across contexts, with free eta_c. Observed categorical compositions are

\[
b_c\propto q_c d0_c,\qquad t_c\propto p_c d1_c.
\]

Here d0,d1 are **control-process** recovery probabilities. Actual biological sample recovery need only have the same route-relative recovery: actual d0^S=kappa0_c*d0 and d1^S=kappa1_c*d1 yield the same normalized categorical probabilities. Unknown common branch-wide multipliers kappa cancel. This is an explicit transport assumption, not a conclusion from the likelihood.

Observe independent baseline and selected categorical samples,

\[
m_c\sim\operatorname{Multinomial}(M_c,b_c),\qquad
n_c\sim\operatorname{Multinomial}(N_c,t_c),
\]

and six independent route/branch controls with known fixed introduced counts,

\[
k_{cgi}\sim\operatorname{Binomial}(L_{cgi},d_{cgi}),\qquad
g=0,1,\quad i=W,A,M.
\]

Each introduced unit has a route label fixed before recovery and one binary recovery indicator. All introduced units must be independently sampled/exposed with a common recovery probability within a context/branch/route, and controls must be independent of categorical outcomes. A recovered unit can contribute at most one success. Amplified descendant-colony totals, uncertain introduced totals, pooled counts, reused units, shared-vessel effects and correlated cultures do not automatically satisfy this binomial likelihood. Route-specific denominators cannot be invented from a known mixture fraction after observing recovery.

Unlike the conditional random-mixture model, route recoveries here are not conditioned on their total. Fixed denominators identify absolute **control** recovery probabilities. In a saturated fit, d_hat=k/L. Their finite independent binomial sampling variance is d(1-d)/L. In the shared-theta joint fit, d can be adjusted by both the control and categorical likelihoods, so k/L is an initial value and the alternative MLE, not generally the constrained-null MLE.

Absolute actual biological recovery can still retain the unknown branch-wide multiplier. Absolute establishment, opportunity flux, mutation/accessibility/fitness factorization and a biological mechanism are not identified by these counts. Positive true categorical support and 0<d<1 are the interior model; structural zero or certain recovery requires a different boundary treatment.

Baseline calibration must itself be a justified context-matched categorical route sample with the same genetic background and locked winner-observation rule. Fluctuation-culture colony totals and pathway-isolated strain collections are not automatically multinomial probabilities. Declare an exhaustive triad or explicit identical triad conditioning; retain other outcomes and exclusions separately. The JSON CLI requires independent-unit, control/outcome independence, transport, calibration, unit-definition, binary-outcome and provenance declarations. Declarations and hashes do not authenticate those assumptions.

## 2. Corrected contrast and its remaining confounding

For positive probabilities, normalization cancels because sum(v)=0:

\[
\theta_c=v^T(\log p_c-\log q_c)
=v^T[\log t_c-\log b_c-\log d1_c+\log d0_c].
\tag{1}
\]

The slope eta vanishes because v^T s=0. The corrected invariant is J_c=exp(2 theta_c). Recover latent compositions by

\[
q_c=\operatorname{normalize}(b_c/d0_c),\qquad
p_c=\operatorname{normalize}(t_c/d1_c).
\tag{2}
\]

If actual and control relative recovery differ, the applied correction is shifted:

\[
\theta^{corr}_c=\theta_c+
 v^T\log(d1^S_c/d1^C_c)-v^T\log(d0^S_c/d0^C_c).
\tag{3}
\]

Fixed denominators improve control recovery identification; they do not eliminate route-specific transport confounding. A common scalar difference cancels, while a route-specific difference can create or hide a contrast departure. Misclassification that moves units between categories, within-route genotype heterogeneity, recovery dependent on mixture density or biological selection acting on controls require another observation model. Independently justified negative controls and transport checks remain necessary; the shared-theta LRT does not test control validity or theta=0.

For arbitrary positive q,p, the contrasts theta_c and eta_c=(1/2)log(p_W q_M/(p_M q_W)) reconstruct p exactly. Thus freeing theta_c gives a saturated categorical model for each choice of interior control efficiencies. The cross-context restriction is precisely shared corrected theta, not constancy of raw t_A²/(t_W t_M).

## 3. Joint likelihood and convex log-efficiency coordinates

Ignoring multinomial and binomial coefficients that cancel in the LRT,

\[
\ell=\sum_{c,i}[m_{ci}\log b_{ci}+n_{ci}\log t_{ci}]
 +\sum_{c,g,i}[k_{cgi}\log d_{cgi}+(L_{cgi}-k_{cgi})\log(1-d_{cgi})].
\]

Define u=log d<0. The negative binomial term is

\[
h(u)=-ku-(L-k)\log(1-e^u),
\]

with derivatives

\[
h'(u)=-k+(L-k)\frac{e^u}{1-e^u},\qquad
h''(u)=(L-k)\frac{e^u}{(1-e^u)^2}.
\tag{4}
\]

For 0<k<L, curvature is positive on the entire feasible domain. This log-efficiency parameterization retains a convex objective; arbitrary unconstrained recovery logits would not preserve the same linear WS restriction.

Use M-reference logits B_W,B_A for b and T_W,T_A for t. Equation (1) gives

\[
T_A=\theta+\tfrac12T_W+B_A-\tfrac12B_W+v^T(u1-u0).
\tag{5}
\]

Per context there are three free categorical coordinates and six log efficiencies, plus one shared theta: **9C+1** parameters. Each categorical logit is linear in these parameters. The joint negative likelihood is a convex sum of multinomial log-sum-exp terms and binomial terms (4). With positive counts in every categorical cell and 0<k<L in all controls, it has a finite unique minimizer: the binomial terms penalize u toward both zero and minus infinity; the remaining full-rank categorical logit differences penalize divergent categorical parameters. This proof does not assert that every zero/extreme table lacks a finite joint fit.

The implementation uses analytic multinomial and binomial derivatives, stabilized log-softmax, and stable log(1-exp(u)):

\[
\log(1-e^u)=
\begin{cases}
\log1p(-e^u),&u<-\log2,\\
\log(-\operatorname{expm1}(u)),&-\log2\le u<0.
\end{cases}
\]

Newton steps are shortened before line search so no log efficiency reaches zero. Empirical and fixed-half-efficiency starting points must converge to agreeing parameters. Coordinate-specific score tolerances keep huge control denominators from weakening convergence checks for theta and categorical coordinates. The information matrix must be finite, positive definite, have condition number at most 10^14 and produce positive finite variances. A scale-based deviance-subtraction guard declines extreme likelihood magnitudes; its recorded floating-point scale is a numerical screening heuristic, not a certified total-error bound for every operation. Numerical underflow or failed convergence is explicit and receives no inferential result.

No pseudocount changes the likelihood. The dense NumPy implementation is intended for a modest number of contexts. It adapts MIT-licensed multinomial/Newton primitives from the previous releases, with separate fixed-denominator likelihood/domain code and preserved license/version lineage.

## 4. Alternative, degrees of freedom and uncertainty

The alternative freely fits two categorical probability vectors and six recovery probabilities per context: **10C** parameters. Its likelihood supremum uses categorical proportions and d_hat=k/L, with 0 log0=0 at its closure. The null/alternative regular difference is **C-1**. The LRT statistic is D=2(ell_alt-ell_null). With one context the descriptive corrected contrast and controls can be estimated, but constancy across contexts imposes no restriction and has df=0.

The ordinary chi-square limit requires independent sampling, positive true support, interior recovery and adequate sample sizes. No asymptotic p-value is emitted. Expected categorical cells, control successes or control failures below five trigger a descriptive sparse warning; five is not a theorem of valid calibration.

For independent samples, the delta-method per-context variance is

\[
V_c\simeq
\frac{1}{M_c}\sum_i\frac{v_i^2}{b_{ci}}
+\frac{1}{N_c}\sum_i\frac{v_i^2}{t_{ci}}
+\sum_i v_i^2\left[
\frac{1-d0_{ci}}{L0_{ci}d0_{ci}}+
\frac{1-d1_{ci}}{L1_{ci}d1_{ci}}\right].
\tag{6}
\]

The categorical covariance terms vanish because sum(v)=0. Independent fixed-route binomials give Var(log d_hat) approximately (1-d)/(L*d); there is no multinomial cross-route control covariance term. These extra terms propagate control uncertainty. If relative recovery were known exactly they would disappear.

First-order expected-information variance for shared theta is [sum_c(1/V_c)]^-1. The implementation separately reports the theta standard error from **joint observed information**, regular control-efficiency standard errors d*sqrt(Var_hat u), and delta expected-information variance components. Observed binomial curvature is (L-k)d/(1-d)^2; its expectation is L*d/(1-d). Therefore observed-information and delta expected-information formulas agree exactly at the noiseless model fixture k=Ld, and asymptotically under regularity, but are not universal exact finite-sample identities for noisy constrained fits. They are not sparse-sample confidence intervals.

## 5. Conservative finite-count bootstrap

The bootstrap preserves M_c,N_c and every introduced denominator L_cgi. It independently resamples both categorical samples from the fitted b,t and **all six route-specific binomial recoveries** from their fitted control d. Every draw refits the same null and saturated alternative. Seed, draw count, statistic comparison tolerance and unresolved counts are recorded.

When all B draws resolve, p_MC=(1+#(D_b>=D_obs))/(B+1). This is an **estimated-null parametric bootstrap**, not an exact finite-sample composite-null test or certified nominal calibration. The plus-one convention sets Monte Carlo resolution and avoids reporting zero; it does not establish test size.

The prototype explicitly declines observed categorical zero cells, k=0, k=L, missing categorical samples or missing introduced denominators. Such tables can have finite or boundary joint fits; no blanket infinite-MLE assertion is made. No smoothing or arbitrary parameter box substitutes for a validated extended-MLE analysis.

Unresolved bootstrap draws are retained, not replaced. With E resolved exceedances and U unresolved draws, no single p-value is emitted; computational bounds [(1+E)/(B+1),(1+E+U)/(B+1)] classify the unresolved draws both ways. These bounds are not population confidence intervals. Rare routes and near-certain/near-zero recovery can make this prototype uninformative, and the result should say so.

## 6. Synthetic results and verification

The exact rational fixtures have four contexts, varying baseline supply/slopes/recovery and 800 introduced units for each route/branch control. Their categorical totals vary because their integer tables encode exact probabilities. They are software arithmetic checks, not biological observations or laboratory sample-size recommendations.

| Synthetic fixture | Uncorrected two-arm D | Fixed-binomial corrected D | Uncorrected bootstrap p | Corrected bootstrap p |
| --- | ---: | ---: | ---: | ---: |
| True theta=log(2) throughout; recovery varies | 543.939771 | 0 | .005 | 1 |
| Last context theta changes to log(4) | 376.060010 | 20.939714 | .005 | .005 |

Each comparison uses 199 estimated-null draws with fixed recorded seeds. All draws in these demonstrations resolved. .005 is the minimum Monte Carlo value 1/200; it does not resolve a smaller tail probability. The corrected constrained fit is theta=.693147 with regular SE=.063459 in the shared fixture, and theta=.846225 with SE=.062141 in the known-departure fixture. The latter is a pooled constrained estimate under an intentionally false restriction, not a shared biological truth.

All **18 tests pass**. Verification includes independent product-ratio algebra, latent-composition reconstruction, full gradient/Hessian finite differences, an isolated binomial curvature oracle, stabilized near-zero log complement, feasible near-one Newton steps, invalid-domain failure, single-context direct k/L and binomial SE checks, the exact-model observed/expected-information identity, fixed-efficiency precision limit, artifact rescue, genuine departure, common biological-scale nonidentification, strict route/unit contracts, zero/extreme/missing-control declines, binomial-resampling failure accounting, information failure and extreme likelihood precision decline.

The complete results are [synthetic_comparison_summary.json](../inference/fixtures/synthetic_comparison_summary.json), with input and code/solver hashes. [TEST_RECEIPT.json](../inference/TEST_RECEIPT.json) records environment, command, hashes and test log. Hashes protect artifact reproducibility; they do not verify biology. Selected synthetic scenarios do not establish global finite-sample size or power, transportability or a validated mechanism. The separate repeated-sample study and audit should be read within their own fixed-scenario limits.

## 7. Use and next steps

[fixed_route_control_inference.py](../inference/fixed_route_control_inference.py) is the entry point, with companion [_fixed_route_convex.py](../inference/_fixed_route_convex.py). Runtime is Python 3.10+ and NumPy, without SciPy. API arrays are shaped (contexts,2,3), branches baseline/selected and routes W/A/M. The JSON contract uses explicit route dictionaries and introduced/recovered dictionaries; direct API callers must enforce the same scientific observation contract.

```sh
python3 make_synthetic_fixtures.py
python3 run_synthetic_validation.py
python3 -m unittest discover -s . -p 'test_fixed_route_control_inference.py' -v
python3 fixed_route_control_inference.py fixtures/fixed_route_recovery_artifact.json --bootstrap 199 --seed 20261002 --output RESULT.json
```

Future work should establish that control units yield genuine independent binary outcomes, validate relative transport to actual samples, model correlated or heterogeneous recovery when needed, develop boundary likelihood inference, and evaluate the locked analysis across weak effects, rare routes and uncertain experimental units. Fixed-route and random-mixture controls are distinct supported observation designs, not interchangeable inputs.
