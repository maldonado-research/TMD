# Scientific progress: match the calculation to the control experiment

Version 0.4.0, research date 30 September 2026. Ricardo Maldonado, with AI-assisted development and independent agent review.

## A new supported design

The 0.3.0 model conditions on the recovered labels from a known input mixture. A practical experiment may instead introduce a fixed number of units separately for each route and record successes and failures. These designs have different likelihoods. Version 0.4.0 now implements the latter, without treating introduced units as recovered observations.

Within each context, write observed baseline and selected route probabilities as b,t and control recovery probabilities as d0,d1. With v=(−1/2,1,−1/2), the corrected Aws contrast is:

```text
theta = v · [log(t) − log(b) − log(d1) + log(d0)]
```

The calculation jointly estimates biological composition and recovery uncertainty. It tests whether that corrected contrast can be shared across contexts while leaving context-specific Wsp/Mws differences free. The joint negative log likelihood is convex in log-recovery coordinates u=log(d)<0, with multinomial logits linear in the parameters. The implementation uses this structure, feasible steps, independent starts and information checks. Standard likelihood and information identities underlie the derivation; no external novelty claim is made.

Known introduced totals identify absolute recovery in the **control process**. They do not automatically identify absolute recovery of evolving cells. Under relative transfer, unknown branch-wide factors cancel from the contrast and corrected composition; arbitrary route-dependent transfer errors remain exactly confounded with biology. The 0.3.0 residual-bias calculation therefore still applies.

## A useful planning result

For six control samples per context with recovery 0.99 and 100 introduced units each, an individual control has probability approximately 0.634 of containing both a success and a failure. Across four contexts, the probability that all 24 controls meet the prototype's interior-count policy is only about 0.001777%. Biological positivity is essentially one in the stated uniform 600-observation illustration.

This does not say that high recovery is biologically undesirable. It exposes a limitation of the current conservative inference policy. A validated boundary likelihood could use tables this implementation declines. Precision and software eligibility must therefore be planned separately.

For the same planning probabilities, an equal-error union-bound design targeting at least 95% global policy eligibility gives component floors of 19 recovered observations per biological arm and 643 introduced units per control sample. At the illustrative equal unit costs, those floors cost 3,896 per context; a budget of 800 cannot meet them. This is a conflict for the chosen floors, not a universally optimal cost bound, a power calculation or a laboratory recommendation.

The planner now returns that conflict explicitly. When feasible, it minimizes the regular variance subject to the chosen floors and budget. Integer rounding remains a feasible heuristic, not an integer optimum. Uncertain recovery rates require sensitivity planning or defended probability envelopes.

## Synthetic demonstrations and broader checks

Two exact synthetic tables show why both recovery correction and remaining biological variation matter. In the recovery-artifact table, ignoring recovery gives bootstrap p=0.005; the corrected shared-contrast model gives p=1.000. In a table with a genuine context-specific generating contrast, the corrected comparison still gives p=0.005. Each uses 199 fitted-null bootstrap draws, with no unresolved draw. These are software demonstrations, not observations or probability that TMD is true.

The [repeated-sample calibration report](calibration/CALIBRATION.md) separately assesses randomly sampled studies, preserves declined datasets, and records bootstrap resolution and Monte Carlo uncertainty. Unit checks and independent derivation review address derivatives, identification, support probabilities, numerical failures and budget constraints. None establishes universal finite-sample calibration or power.

## Evidence and data status

Four additional primary studies inform input-unit verification, transfer/cultivation endpoints, measurement bias and genetic-background contingency. The most recent selected study was published in July 2026. Their measured findings and our proposed design consequences are separated in the [literature update](literature/LITERATURE_UPDATE.md); raw third-party data are not redistributed or claimed to have been analyzed.

A scoped local audit checked 918 unique small text references. It found planning material, synthetic first-arrival demonstrations and conditional-route templates, but no authenticated fixed-input successes/trials panel for the matched W/A/M question. The [audit](audit/FIXED_INPUT_REFERENCE_AND_MATH_AUDIT.md) records that scope; it does not assert that every archive file or study on the internet has been examined.

## What would move the hypothesis forward

The priority is a real measurement panel with the [specified unit and endpoint contract](FIXED_INPUT_DATA_CONTRACT.md), plus independent checks of recovery transport. A corrected context departure can falsify the shared contrast under admitted assumptions; a nondeparture cannot establish mutation causality. Measuring mutation supply, establishment and opportunity separately would be necessary to support a causal explanation.

The next mathematical extension should be driven by actual data: a reviewed boundary likelihood for all-success/all-failure controls, or a clustered model when batches and cultures create dependence. Adding unrelated equations from physics would not resolve the current biological identification gap.
