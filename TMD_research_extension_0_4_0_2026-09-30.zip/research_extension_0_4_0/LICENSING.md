# Reuse and source rights

New software is MIT licensed; see LICENSE. New explanatory writing is CC BY 4.0: https://creativecommons.org/licenses/by/4.0/. Author: Ricardo Maldonado, with AI-assisted analysis. Numerical primitives retain their MIT lineage in inference/VERSION_LINEAGE.md. The CITATION license field names the software license; writing follows this separate notice.

Primary papers, publisher figures and third-party datasets retain their own rights. This package redistributes none of those articles, figures or source datasets. Literature notes contain attributed factual summaries and project-specific inferences, not new biological observations. Local audit inventories use portable reference labels and preserve original references without changing them.
