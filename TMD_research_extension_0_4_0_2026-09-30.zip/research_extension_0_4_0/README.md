# Mutation by Natural Dominance: fixed-input recovery controls

**Research methods extension 0.4.0 · Ricardo Maldonado · 30 September 2026**

This package adds a joint calculation for studies that introduce a known number of control units separately for each Wsp, Aws and Mws route, then count how many are recovered. It extends the 0.3.0 recovered-mixture control model to a different sampling design. It also supplies a planner that checks whether a proposed budget can meet chosen minimum counts before optimizing precision.

The result is a tested statistical tool and a proposed measurement protocol. The examples are synthetic. No authenticated matched biological panel has yet supplied the baseline route counts, selected route counts and introduced/recovered controls needed for an empirical TMD test. The shared-contrast test does not identify a mutation mechanism or establish physical unification.

## Start here

- [Scientific progress and limits](SCIENTIFIC_PROGRESS.md)
- [In More Basic Terms](IN_MORE_BASIC_TERMS.md)
- [Fixed-input measurement contract](FIXED_INPUT_DATA_CONTRACT.md)
- [Joint likelihood and identification](methods/FIXED_ROUTE_BINOMIAL_BRIDGE.md)
- [Precision, support and budget planning](design/PLANNING_AND_SUPPORT.md)
- [Repeated simulated experiments](calibration/CALIBRATION.md)
- [Four additional primary studies](literature/LITERATURE_UPDATE.md)
- [Independent methods review](audit/INDEPENDENT_METHODS_REVIEW.md)

## What is different

For each context, the model uses two independent three-route observed samples and six binomial control samples: one known introduced total and recovered count for each route in each observation branch. Those denominators identify absolute recovery probabilities for the **control assay**. Relative control-to-biology recovery transfer can identify corrected biological compositions while still leaving an unknown branch-wide biological recovery scale.

The null model has one shared corrected Aws contrast across contexts; the alternative allows a separate contrast per context. Context-specific Wsp/Mws differences are nuisance parameters. The regular comparison has C−1 degrees of freedom. One context gives descriptive estimates, with no shared-versus-contextual test.

The prototype declines categorical zeros, all-failure/all-success controls and unresolved numerical information. It neither adds invented counts nor asserts that every declined table has an infinite maximum-likelihood estimate. Its fitted-null bootstrap resamples both biological arms and every control sample. Unresolved draws remain in computational p-value bounds. Calibration is approximate.

The planner distinguishes precision from eligibility for that conservative policy. A nearly perfect recovery rate can yield all-success controls, so the variance-only optimum may recommend counts too small for the current software to analyze. Minimum-count floors and explicit budget conflicts make that limitation visible. These are conditional model calculations, not power guarantees or laboratory sample-size recommendations.

## Reproduce

Tested with Python 3.12.14 and NumPy 2.3.5. NumPy is the only external software dependency.

```sh
python3 -m pip install -r requirements.txt
python3 -m unittest discover -s inference -p 'test_fixed_route_control_inference.py' -v
python3 -m unittest discover -s design -p 'test_fixed_input_design.py' -v
python3 inference/fixed_route_control_inference.py inference/fixtures/fixed_route_recovery_artifact.json --bootstrap 199 --seed 20261002
python3 design/fixed_input_design.py
python3 calibration/run_repeated_sample_calibration.py
```

The repeated-sample runner is deliberately more expensive than the unit tests. Read its recorded seeds, scenario definitions and scope before treating any rejection frequency as transferable to a different design.

Source hashes, review hashes, input hashes and the package manifest let a reader check that the reviewed calculations correspond to the distributed files. Publication is recorded separately; this package does not invent a Zenodo DOI, GitHub tag or external mathematical priority.

## Next scientific step

Acquire or audit an independent biological panel with matched observation branches, route identity, known introduced control units, successes and failures, culture/batch lineage, and a defended recovery-transfer assumption. Challenge that transfer on held-out controls before interpreting a corrected contrast biologically. If the control outcomes are extreme or clustered, develop and validate the appropriate boundary or dependent-data likelihood rather than forcing this model onto them.

New code is MIT licensed; new writing is CC BY 4.0. See [reuse and source rights](LICENSING.md). Original papers and third-party data retain their own rights.
