"""Synthetic-only independent mathematical and software verification for TMD 0.4.0."""
import copy
import math
import unittest
from unittest.mock import patch
import numpy as np
from _fixed_route_convex import log1mexp,objective,minimize,saturated_loglik
from fixed_route_control_inference import (V,design,validate_document,validate_arrays,
    corrected_contrast,variance_components,fit_fixed_route_controls,bootstrap_fixed_route_controls)
from make_synthetic_fixtures import build_fixture


def uncorrected_lrt(counts):
    c=len(counts);x=np.zeros((2*c,3,3*c+1));y=counts.reshape(2*c,3)
    for j in range(c):
        x[2*j,0,3*j]=1;x[2*j,1,3*j+1]=1;x[2*j+1,0,3*j+2]=1
        x[2*j+1,1,[3*j,3*j+1,3*j+2,-1]]=[-.5,1,.5,1]
    empty=np.array([],float);ui=np.array([],int)
    beta,diag=minimize(x,y,empty,empty,ui,np.zeros(3*c+1))
    assert diag['converged']
    return 2*(objective(beta,x,y,empty,empty,ui)[0]+saturated_loglik(y,empty,empty))


class FixedRouteTests(unittest.TestCase):
    def setUp(self):
        self.doc=build_fixture();_,self.n,self.L,self.k=validate_document(self.doc)

    def test_exact_identity_latent_compositions_and_df(self):
        observed=self.n/self.n.sum(axis=2)[:,:,None];d=self.k/self.L
        ratio=observed[:,1]*d[:,0]/(observed[:,0]*d[:,1])
        direct=np.log(ratio[:,1]/np.sqrt(ratio[:,0]*ratio[:,2]))
        np.testing.assert_allclose(direct,math.log(2),atol=1e-14)
        np.testing.assert_allclose(corrected_contrast(observed,d),direct,atol=1e-14)
        fit=fit_fixed_route_controls(self.n,self.L,self.k)
        self.assertEqual(fit['status'],'interior');self.assertEqual(fit['regular_degrees_of_freedom'],3)
        self.assertAlmostEqual(fit['theta'],math.log(2),places=9);self.assertLess(fit['deviance'],1e-7)
        np.testing.assert_allclose(fit['corrected_baseline_probabilities'],[r['q'] for r in self.doc['generating_parameters']],atol=1e-9)
        np.testing.assert_allclose(fit['corrected_selected_probabilities'],[r['p'] for r in self.doc['generating_parameters']],atol=1e-9)
        np.testing.assert_allclose(fit['absolute_control_recovery_probabilities'],d,atol=1e-9)

    def test_derivatives_against_independent_finite_differences(self):
        x,ui=design(2);n=self.n[:2].reshape(4,3);L=self.L[:2].reshape(-1);k=self.k[:2].reshape(-1)
        beta=np.linspace(-.4,.5,x.shape[-1]);beta[ui]=np.linspace(-1.7,-.15,len(ui))
        _,g,H=objective(beta,x,n,L,k,ui);h=1e-5;ng=np.zeros_like(g);nH=np.zeros_like(H)
        for j in range(len(beta)):
            shift=np.eye(len(beta))[j]*h
            left=objective(beta-shift,x,n,L,k,ui);right=objective(beta+shift,x,n,L,k,ui)
            ng[j]=(right[0]-left[0])/(2*h);nH[:,j]=(right[1]-left[1])/(2*h)
        np.testing.assert_allclose(g,ng,rtol=1e-7,atol=1e-6)
        np.testing.assert_allclose(H,nH,rtol=1e-7,atol=1e-5)
        self.assertGreater(np.linalg.eigvalsh(H).min(),0)

    def test_independent_binomial_curvature_formula(self):
        # A single-binomial design avoids the categorical derivative contribution.
        x=np.zeros((1,3,1));n=np.array([[1,2,1]],float);L=np.array([17.]);k=np.array([6.]);ui=np.array([0])
        beta=np.array([math.log(.4)]);_,g,H=objective(beta,x,n,L,k,ui)
        self.assertAlmostEqual(g[0],-6+11*.4/.6,places=10)
        self.assertAlmostEqual(H[0,0],11*.4/.6**2,places=10)

    def test_stable_log1mexp_and_invalid_domain(self):
        u=np.array([-1000.,-math.log(2),-1e-14,-1e-4])
        result=log1mexp(u)
        self.assertTrue(np.all(np.isfinite(result)));self.assertEqual(result[0],0.)
        self.assertAlmostEqual(result[1],-math.log(2),places=14)
        self.assertAlmostEqual(result[2],math.log(1e-14),places=12)
        for bad in (0.,1.,float('inf'),float('nan')):
            with self.assertRaises(ValueError):log1mexp(bad)

    def test_feasible_newton_near_probability_one(self):
        L=np.full_like(self.L,200);k=np.full_like(self.k,199)
        fit=fit_fixed_route_controls(self.n,L,k)
        self.assertEqual(fit['status'],'interior')
        self.assertTrue(np.all(np.asarray(fit['log_control_recovery_probabilities'])<0))
        self.assertTrue(all(r['converged'] for r in fit['optimizer_checks']))

    def test_invalid_optimizer_start_declined(self):
        x,ui=design(1);start=np.zeros(x.shape[-1])
        _,diag=minimize(x,self.n[:1].reshape(2,3),self.L[:1].reshape(-1),self.k[:1].reshape(-1),ui,start)
        self.assertFalse(diag['converged']);self.assertEqual(diag['reason'],'invalid starting domain')

    def test_one_context_direct_binomial_mle_and_standard_error(self):
        fit=fit_fixed_route_controls(self.n[:1],self.L[:1],self.k[:1]);d=self.k[:1]/self.L[:1]
        self.assertEqual(fit['inference_status'],'not_evaluable');self.assertEqual(fit['regular_degrees_of_freedom'],0)
        np.testing.assert_allclose(fit['absolute_control_recovery_probabilities'],d,atol=1e-9)
        np.testing.assert_allclose(fit['absolute_control_recovery_standard_errors_regular'],np.sqrt(d*(1-d)/self.L[:1]),atol=1e-9)
        self.assertLess(fit['deviance'],1e-7)

    def test_control_uncertainty_information_identity_at_exact_model(self):
        p=self.n/self.n.sum(axis=2)[:,:,None];d=self.k/self.L
        cat=np.sum(np.array([.25,1.,.25])/p,axis=2)/self.n.sum(axis=2)
        ctrl=np.sum(np.array([.25,1.,.25])*(1-d)/(self.L*d),axis=2)
        expected_var=1/np.sum(1/(cat.sum(axis=1)+ctrl.sum(axis=1)))
        fit=fit_fixed_route_controls(self.n,self.L,self.k)
        self.assertAlmostEqual(fit['theta_standard_error_regular']**2,expected_var,places=10)
        var,parts=variance_components(p,d,self.n.sum(axis=2),self.L)
        np.testing.assert_allclose(parts,np.concatenate((cat,ctrl),axis=1),atol=1e-14)
        big=fit_fixed_route_controls(self.n,self.L*1000,self.k*1000)
        fixed_var=1/np.sum(1/cat.sum(axis=1))
        self.assertGreater(expected_var,fixed_var);self.assertLess(big['theta_standard_error_regular'],fit['theta_standard_error_regular'])
        self.assertAlmostEqual(big['theta_standard_error_regular']**2,fixed_var,delta=expected_var*.001)

    def test_artifact_uncorrected_reject_corrected_rescue(self):
        self.assertGreater(uncorrected_lrt(self.n),100)
        result=bootstrap_fixed_route_controls(self.n,self.L,self.k,19,21)
        self.assertEqual(result['status'],'resolved');self.assertEqual(result['p_value'],1.)

    def test_genuine_departure_is_detected(self):
        _,n,L,k=validate_document(build_fixture(True))
        result=bootstrap_fixed_route_controls(n,L,k,39,22)
        self.assertEqual(result['status'],'resolved');self.assertGreater(result['fit']['deviance'],20)
        self.assertEqual(result['exceedances'],0);self.assertEqual(result['p_value'],1/40)

    def test_common_biological_recovery_scale_cancels_but_not_control_d(self):
        # Control denominators identify d; actual sample may have an unknown common scale.
        q=np.array([.25,.5,.25]);d=np.array([.2,.4,.3])
        b=q*d/(q@d);scaled=q*(.3*d)/(q@(.3*d))
        np.testing.assert_allclose(b,scaled,atol=1e-14)
        self.assertFalse(np.allclose(d,.3*d))
        fit=fit_fixed_route_controls(self.n,self.L,self.k)
        self.assertIn('unknown branch-wide multiplier',fit['identification_limit'])

    def test_conservative_extreme_and_zero_declines(self):
        n=self.n.copy();n[0,0,0]=0
        self.assertEqual(fit_fixed_route_controls(n,self.L,self.k)['status'],'categorical_zero_not_supported')
        for value in (0,self.L[0,0,0]):
            k=self.k.copy();k[0,0,0]=value
            result=fit_fixed_route_controls(self.n,self.L,k)
            self.assertEqual(result['status'],'extreme_binomial_not_supported');self.assertNotIn('theta',result)
        L=self.L.copy();k=self.k.copy();L[0,0,0]=k[0,0,0]=0
        self.assertEqual(fit_fixed_route_controls(self.n,L,k)['status'],'missing_introduced_units')

    def test_bootstrap_all_binomials_resampled_failure_accounting(self):
        n=np.full((2,2,3),20);L=np.full((2,2,3),2);k=np.ones((2,2,3),int)
        result=bootstrap_fixed_route_controls(n,L,k,19,32)
        self.assertEqual(result['status'],'partially_unresolved');self.assertIsNone(result['p_value'])
        self.assertGreater(result['unresolved_reasons'].get('extreme_binomial_not_supported',0),0)
        self.assertEqual(len(result['bootstrap_statistics'])+result['unresolved_replicates'],19)
        self.assertLess(result['p_value_computational_bounds'][0],result['p_value_computational_bounds'][1])

    def test_strict_dictionary_and_unit_contract(self):
        for key in ('independent_exposed_control_units','independent_controls_and_outcomes','control_relative_recovery_transports'):
            doc=copy.deepcopy(self.doc);doc['metadata'][key]=False
            with self.assertRaisesRegex(ValueError,key):validate_document(doc)
        for key,value in [('control_sampling_design','random_mixture'),('exposed_unit_definition',''),
                          ('control_outcome_definition','amplified_colony_counts')]:
            doc=copy.deepcopy(self.doc);doc['metadata'][key]=value
            with self.assertRaises(ValueError):validate_document(doc)
        doc=copy.deepcopy(self.doc);doc['contexts'][0]['baseline_counts']['Other']=1
        with self.assertRaisesRegex(ValueError,'exactly W,A,M'):validate_document(doc)
        for value in (-1,.5,float('nan'),True):
            k=self.k.tolist();k[0][0][0]=value
            with self.assertRaises(ValueError):validate_arrays(self.n,self.L,k)
        k=self.k.copy();k[0,0,0]=self.L[0,0,0]+1
        with self.assertRaises(ValueError):validate_arrays(self.n,self.L,k)

    def test_information_failure_not_inference(self):
        with patch('fixed_route_control_inference.np.linalg.eigvalsh',return_value=np.array([-1.,1.])):
            result=fit_fixed_route_controls(self.n,self.L,self.k)
        self.assertEqual(result['status'],'information_unresolved');self.assertNotIn('theta',result)

    def test_extreme_likelihood_scale_is_not_reported_as_exact_deviance(self):
        result=fit_fixed_route_controls(self.n,self.L*10**9,self.k*10**9)
        self.assertEqual(result['inference_status'],'not_evaluable')
        self.assertIn(result['status'],('information_unresolved','optimizer_unresolved','likelihood_precision_unresolved'))
        self.assertNotIn('theta',result)

    def test_public_helpers_simplex_efficiency_contract(self):
        p=self.n/self.n.sum(axis=2)[:,:,None];d=self.k/self.L
        with self.assertRaises(ValueError):corrected_contrast(p*2,d)
        with self.assertRaises(ValueError):corrected_contrast(p,np.ones_like(d))
        with self.assertRaises(ValueError):variance_components(p,d,np.zeros((4,2)),self.L)

    def test_fixed_seed_reproducible(self):
        a=bootstrap_fixed_route_controls(self.n,self.L,self.k,5,41)
        b=bootstrap_fixed_route_controls(self.n,self.L,self.k,5,41)
        self.assertEqual(a,b)

if __name__=='__main__':unittest.main(verbosity=2)
