"""Exact rational fixtures for fixed-route controls; no biological data.
Copyright (c) 2026 Ricardo Maldonado. MIT; see LICENSE.
"""
from fractions import Fraction as F
from functools import reduce
from math import gcd,log
from pathlib import Path
import json

ROOT=Path(__file__).parent/'fixtures'
ROUTES=('W','A','M')
META={'provenance':'synthetic','independent_categorical_samples':True,'independent_exposed_control_units':True,
      'independent_controls_and_outcomes':True,'independent_replicates_across_contexts':True,
      'common_genetic_background':True,'context_matched_calibration':True,
      'control_relative_recovery_transports':True,'eligible_winner_observation_rule_locked':True,
      'control_sampling_design':'fixed_route_independent_binomial',
      'control_outcome_definition':'one_binary_recovery_per_introduced_unit',
      'exposed_unit_definition':'Synthetic independently introduced, traceable route-labeled unit with one recovery indicator.',
      'calibration_design':'matched_route_multinomial','calibration_validation':'validated_for_route_probability',
      'triad_sampling':'exhaustive_triad','description':'Exact arithmetic fixtures, not sampled biological observations.'}

def norm(values):
    values=[F(v) for v in values];s=sum(values);return [v/s for v in values]

def exact_counts(probabilities,multiplier=200):
    denominator=reduce(lambda a,b:a*b//gcd(a,b),(p.denominator for p in probabilities))
    return [int(p*denominator)*multiplier for p in probabilities]

def build_fixture(departure=False):
    qweights=[[1,2,1],[2,1,2],[1,1,3],[3,2,1]];slopes=[F(1),F(2),F(1,2),F(1)]
    d0=[[F(1,2)]*3,[F(1,4),F(1,2),F(1,2)],[F(1,2),F(1,4),F(1,2)],[F(1,2),F(1,2),F(1,4)]]
    d1=[[F(1,2),F(1,4),F(1,2)],[F(1,2)]*3,[F(1,2),F(3,4),F(1,2)],[F(1,2),F(1,8),F(1,2)]]
    contexts=[];truth=[]
    for c in range(4):
        q=norm(qweights[c]);axis=F(4) if departure and c==3 else F(2)
        p=norm([q[0]*slopes[c],q[1]*axis,q[2]/slopes[c]])
        b=norm([v*d for v,d in zip(q,d0[c])]);t=norm([v*d for v,d in zip(p,d1[c])])
        row={'context':f'synthetic_fixed_route_context_{c+1}'}
        for branch,prob,d in zip(('baseline','selected'),(b,t),(d0[c],d1[c])):
            row[branch+'_counts']=dict(zip(ROUTES,exact_counts(prob)))
            row[branch+'_recovery_controls']={r:{'introduced':800,'recovered':int(800*di)} for r,di in zip(ROUTES,d)}
        contexts.append(row);truth.append({'q':[float(v) for v in q],'p':[float(v) for v in p],
            'control_d0':[float(v) for v in d0[c]],'control_d1':[float(v) for v in d1[c]],
            'theta':log(float(axis)),'eta':log(float(slopes[c]))})
    return {'route_order':list(ROUTES),'branch_order':['baseline','selected'],'metadata':META.copy(),
            'generating_parameters':truth,'contexts':contexts}

if __name__=='__main__':
    for name,departure in [('fixed_route_recovery_artifact',False),('fixed_route_theta_departure',True)]:
        (ROOT/(name+'.json')).write_text(json.dumps(build_fixture(departure),indent=2)+'\n')
