"""Synthetic 0.4.0 correction/uncorrected comparison with complete code/input hashes.
Copyright (c) 2026 Ricardo Maldonado. MIT; see LICENSE and VERSION_LINEAGE.md.
"""
from pathlib import Path
import hashlib
import json
import platform
import numpy as np
from _fixed_route_convex import objective,minimize,log_softmax,saturated_loglik
from fixed_route_control_inference import V,validate_document,corrected_contrast,bootstrap_fixed_route_controls

ROOT=Path(__file__).parent


def fit_uncorrected(counts):
    c=len(counts);y=np.asarray(counts).reshape(2*c,3)
    if np.any(y<=0):return {'status':'categorical_zero_not_supported'}
    x=np.zeros((2*c,3,3*c+1))
    for j in range(c):
        x[2*j,0,3*j]=1;x[2*j,1,3*j+1]=1;x[2*j+1,0,3*j+2]=1
        x[2*j+1,1,[3*j,3*j+1,3*j+2,-1]]=[-.5,1,.5,1]
    empty=np.array([],float);ui=np.array([],int)
    beta,diag=minimize(x,y,empty,empty,ui,np.zeros(3*c+1))
    if not diag['converged']:return {'status':'optimizer_unresolved'}
    return {'status':'interior','theta':float(beta[-1]),
            'deviance':max(0.,2*(objective(beta,x,y,empty,empty,ui)[0]+saturated_loglik(y,empty,empty))),
            'probabilities':np.exp(log_softmax(x@beta)).reshape(c,2,3).tolist()}


def bootstrap_uncorrected(counts,replicates,seed):
    fit=fit_uncorrected(counts)
    if fit['status']!='interior':return {'status':'not_evaluable','fit':fit,'p_value':None}
    rng=np.random.default_rng(seed);prob=np.asarray(fit['probabilities']);totals=counts.sum(axis=2)
    exceed=0;unresolved=0;tol=1e-9*max(1.,fit['deviance'])
    for _ in range(replicates):
        sampled=np.array([[rng.multinomial(int(N),p) for N,p in zip(tc,pc)] for tc,pc in zip(totals,prob)])
        trial=fit_uncorrected(sampled)
        if trial['status']!='interior':unresolved+=1
        else:exceed+=trial['deviance']>=fit['deviance']-tol
    bounds=[(1+exceed)/(replicates+1),(1+exceed+unresolved)/(replicates+1)]
    return {'status':'resolved' if unresolved==0 else 'partially_unresolved','fit':fit,
            'replicates':replicates,'seed':seed,'exceedances':int(exceed),'unresolved_replicates':unresolved,
            'p_value':bounds[0] if unresolved==0 else None,'p_value_computational_bounds':bounds}


def main():
    summary={'provenance':'synthetic_arithmetic_fixtures','replicates_each':199,
             'python_version':platform.python_version(),'numpy_version':np.__version__,
             'code_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in
                ('fixed_route_control_inference.py','_fixed_route_convex.py','make_synthetic_fixtures.py','run_synthetic_validation.py','test_fixed_route_control_inference.py')},
             'interpretation':'Estimated-null bootstrap demonstrations on exact synthetic tables only; no biological validation, global-size/power claim or real sample-size justification.',
             'fixtures':{}}
    for index,name in enumerate(('fixed_route_recovery_artifact','fixed_route_theta_departure')):
        raw=(ROOT/'fixtures'/(name+'.json')).read_bytes();doc=json.loads(raw);h=hashlib.sha256(raw).hexdigest()
        names,n,L,k=validate_document(doc);p=n/n.sum(axis=2)[:,:,None]
        corrected=bootstrap_fixed_route_controls(n,L,k,199,20261002+index)
        uncorrected=bootstrap_uncorrected(n,199,20261102+index)
        corrected.update(input_sha256=h,metadata=doc['metadata'],contexts=names,route_order=doc['route_order'],branch_order=doc['branch_order'],
                         provenance_warning='Synthetic exact arithmetic fixture, not biological evidence.')
        (ROOT/'fixtures'/(name+'_result.json')).write_text(json.dumps(corrected,indent=2,allow_nan=False)+'\n')
        item={'input_file':name+'.json','input_sha256':h,
              'generating_theta':[row['theta'] for row in doc['generating_parameters']],
              'uncorrected_empirical_theta':((np.log(p[:,1])-np.log(p[:,0]))@V).tolist(),
              'corrected_empirical_theta':corrected_contrast(p,k/L).tolist(),
              'uncorrected':uncorrected,
              'corrected':{key:corrected[key] for key in ('status','replicates','seed','p_value','unresolved_replicates','p_value_computational_bounds')}}
        item['corrected'].update(theta=corrected['fit'].get('theta'),deviance=corrected['fit'].get('deviance'),
                                 theta_standard_error_regular=corrected['fit'].get('theta_standard_error_regular'))
        summary['fixtures'][name]=item
    (ROOT/'fixtures/synthetic_comparison_summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    print(json.dumps({name:{kind:item[kind].get('p_value') for kind in ('uncorrected','corrected')} for name,item in summary['fixtures'].items()},indent=2))

if __name__=='__main__':main()
