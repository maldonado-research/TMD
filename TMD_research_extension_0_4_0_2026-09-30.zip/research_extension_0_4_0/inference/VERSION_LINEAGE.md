# 0.4.0 version lineage and runtime

Copyright (c) 2026 Ricardo Maldonado. The complete MIT license is in `LICENSE`.

The stabilized log-softmax, multinomial score/Hessian and Newton line-search structure descend from the MIT-licensed 0.2.0 `joint_ws_inference.py` and 0.3.0 `_convex_multinomial.py`. Version 0.4.0 adds an independent fixed-route binomial recovery likelihood, a strict log-efficiency domain, stable log(1-exp(u)), feasibility-limited Newton steps, and the new 9C+1 design. It does not modify either historical release or claim new mathematical theory.

This model accepts fixed route-specific introduced denominators and recovered counts under independent one-unit/one-binary-outcome sampling. It does not accept the random-mixture conditional-multinomial controls of 0.3.0. That distinction changes the likelihood, absolute control-efficiency identification and uncertainty.

Runtime: Python 3.10+ and NumPy; SciPy is neither required nor installed. Entry point: `python fixed_route_control_inference.py INPUT.json --bootstrap 199 --output RESULT.json`. Keep `_fixed_route_convex.py` alongside the entry point. The module supports direct or package-relative imports.

Public numeric API: `fit_fixed_route_controls(counts,introduced,recovered,check_starts=True)` and `bootstrap_fixed_route_controls(counts,introduced,recovered,replicates=199,seed=20261002)`. All three arrays have shape (contexts,2,3), with branches baseline/selected and routes W/A/M. API users must enforce the same observation contract as the CLI. JSON uses named route dictionaries for each categorical sample and route dictionaries with introduced/recovered counts for each control branch.

Synthetic comparisons deliberately fit the earlier two-arm shared contrast to biased observed baseline/selected counts, then compare it with the 0.4.0 corrected model. That comparator is an arithmetic demonstration of ignoring recovery, not a validated biological alternative. Hash receipts record the inference module, solver, fixture generator, comparison runner and tests.
