#!/usr/bin/env python3
"""TMD 0.4.0: two categorical arms and six fixed-route binomial controls per context.
Copyright (c) 2026 Ricardo Maldonado. MIT; see LICENSE and VERSION_LINEAGE.md.
Absolute efficiencies refer to control processes, not unidentified biological scales.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np
try:
    from ._fixed_route_convex import log_softmax,log1mexp,objective,minimize,saturated_loglik
except ImportError:
    from _fixed_route_convex import log_softmax,log1mexp,objective,minimize,saturated_loglik

ROUTES=('W','A','M'); BRANCHES=('baseline','selected'); V=np.array([-.5,1.,-.5])


def validate_arrays(counts,introduced,recovered):
    shape=None
    for values in (counts,introduced,recovered):
        a=np.asarray(values)
        if a.ndim!=3 or a.shape[1:]!=(2,3) or len(a)<1:
            raise ValueError('All arrays must have shape (contexts,2,3)')
        if shape is not None and a.shape!=shape:raise ValueError('All context/route shapes must agree')
        shape=a.shape
        if any(isinstance(v,(bool,np.bool_)) for c in values for row in c for v in row):
            raise ValueError('Booleans are not counts')
        if a.dtype.kind not in 'iuf' or not np.all(np.isfinite(a)):
            raise ValueError('Counts and denominators must be finite numeric integers')
        if np.any(a<0) or np.any(a!=np.floor(a)) or np.any(a>2**52):
            raise ValueError('Counts and denominators must be nonnegative exactly representable integers')
    counts,introduced,recovered=map(lambda v:np.asarray(v,float),(counts,introduced,recovered))
    if np.any(counts.sum(axis=2)>2**52):raise ValueError('Categorical totals must be exactly representable')
    if np.any(recovered>introduced):raise ValueError('Recovered units cannot exceed introduced units')
    return counts,introduced,recovered


def route_dictionary(value,label):
    if not isinstance(value,dict) or set(value)!=set(ROUTES):
        raise ValueError(f'{label} must be a dictionary with exactly W,A,M')
    return [value[r] for r in ROUTES]


def validate_document(doc):
    if not isinstance(doc,dict) or not isinstance(doc.get('metadata'),dict):
        raise ValueError('Input and metadata must be objects')
    meta=doc['metadata']
    for key in ('independent_categorical_samples','independent_exposed_control_units',
                'independent_controls_and_outcomes','independent_replicates_across_contexts',
                'common_genetic_background','context_matched_calibration',
                'control_relative_recovery_transports','eligible_winner_observation_rule_locked'):
        if meta.get(key) is not True:raise ValueError(f'metadata.{key} must explicitly be true')
    if meta.get('control_sampling_design')!='fixed_route_independent_binomial':
        raise ValueError('Fixed route introduced denominators with independent binary units required; random-mixture controls unsupported')
    if meta.get('control_outcome_definition')!='one_binary_recovery_per_introduced_unit':
        raise ValueError('Each introduced unit requires exactly one binary recovery outcome')
    unit=meta.get('exposed_unit_definition')
    if not isinstance(unit,str) or not unit.strip():raise ValueError('A nonempty exposed_unit_definition is required')
    if meta.get('calibration_design')!='matched_route_multinomial' or meta.get('calibration_validation')!='validated_for_route_probability':
        raise ValueError('Validated matched-route multinomial calibration required; fluctuation-culture or pathway-isolated colony totals unsupported')
    if meta.get('triad_sampling') not in ('exhaustive_triad','conditioned_on_triad'):
        raise ValueError('Declare one exhaustive_triad or conditioned_on_triad sampling rule')
    if meta.get('provenance') not in ('synthetic','observed','literature_transcription'):
        raise ValueError('Explicit provenance required')
    if doc.get('route_order')!=list(ROUTES) or doc.get('branch_order')!=list(BRANCHES):
        raise ValueError('Route/branch order must be W,A,M and baseline,selected')
    contexts=doc.get('contexts')
    if not isinstance(contexts,list) or not contexts or any(not isinstance(c,dict) for c in contexts):
        raise ValueError('Contexts must be a nonempty list of objects')
    names=[c.get('context') for c in contexts]
    if any(not isinstance(n,str) or not n for n in names) or len(set(names))!=len(names):
        raise ValueError('Context names must be nonempty and unique')
    counts=[]; introduced=[]; recovered=[]
    for c in contexts:
        counts.append([route_dictionary(c.get(branch+'_counts'),branch+'_counts') for branch in BRANCHES])
        cc=[]; kk=[]
        for branch in BRANCHES:
            controls=route_dictionary(c.get(branch+'_recovery_controls'),branch+'_recovery_controls')
            if any(not isinstance(r,dict) or set(r)!= {'introduced','recovered'} for r in controls):
                raise ValueError('Each route control must contain exactly introduced and recovered counts')
            cc.append([r['introduced'] for r in controls]);kk.append([r['recovered'] for r in controls])
        introduced.append(cc);recovered.append(kk)
    counts,introduced,recovered=validate_arrays(counts,introduced,recovered)
    return names,counts,introduced,recovered


def design(c):
    """Unknowns per context: B_W,B_A,T_W,u0_W,u0_A,u0_M,u1_W,u1_A,u1_M."""
    x=np.zeros((2*c,3,9*c+1));u_indices=[]
    for j in range(c):
        bw,ba,tw,u0w,u0a,u0m,u1w,u1a,u1m=range(9*j,9*j+9)
        x[2*j,0,bw]=x[2*j,1,ba]=1
        x[2*j+1,0,tw]=1
        x[2*j+1,1,[bw,ba,tw,u0w,u0a,u0m,u1w,u1a,u1m,-1]]=[-.5,1,.5,.5,-1,.5,-.5,1,-.5,1]
        u_indices.extend((u0w,u0a,u0m,u1w,u1a,u1m))
    return x,np.array(u_indices,dtype=int)


def corrected_contrast(probabilities,control_efficiencies):
    p=np.asarray(probabilities,float);d=np.asarray(control_efficiencies,float)
    if p.ndim!=3 or p.shape[1:]!=(2,3) or d.shape!=p.shape:
        raise ValueError('Probability and control efficiency shapes must be (contexts,2,3)')
    if not np.all(np.isfinite(p)) or np.any(p<=0) or not np.allclose(p.sum(axis=2),1.,rtol=0,atol=1e-10):
        raise ValueError('Positive probability simplexes required')
    if not np.all(np.isfinite(d)) or np.any(d<=0) or np.any(d>=1):
        raise ValueError('Control efficiencies must be strictly between zero and one')
    return (np.log(p[:,1])-np.log(p[:,0])-np.log(d[:,1])+np.log(d[:,0]))@V


def variance_components(probabilities,control_efficiencies,categorical_totals,introduced):
    p=np.asarray(probabilities,float);d=np.asarray(control_efficiencies,float)
    corrected_contrast(p,d) # Enforce the same probability/support contract.
    totals=np.asarray(categorical_totals,float);L=np.asarray(introduced,float)
    if totals.shape!=p.shape[:2] or L.shape!=p.shape or not np.all(np.isfinite(totals)) or not np.all(np.isfinite(L)) or np.any(totals<=0) or np.any(L<=0):
        raise ValueError('Positive totals/introduced denominators required with matching shapes')
    categorical=np.sum(V*V/p,axis=2)/totals
    controls=np.sum(V*V*(1-d)/(L*d),axis=2)
    components=np.concatenate((categorical,controls),axis=1)
    return components.sum(axis=1),components


def fit_fixed_route_controls(counts,introduced,recovered,check_starts=True):
    counts,introduced,recovered=validate_arrays(counts,introduced,recovered)
    c=len(counts);y=counts.reshape(2*c,3);L=introduced.reshape(-1);k=recovered.reshape(-1)
    result={'schema_version':'0.4.0','regular_degrees_of_freedom':c-1,
            'alternative':'Context-specific corrected theta; saturated categorical compositions and route binomials',
            'loglik_saturated':saturated_loglik(y,L,k),'asymptotic_p_value':None}
    if np.any(counts.sum(axis=2)==0):
        result.update(status='missing_categorical_arm',inference_status='not_evaluable');return result
    if np.any(introduced==0):
        result.update(status='missing_introduced_units',inference_status='not_evaluable');return result
    if np.any(counts==0):
        result.update(status='categorical_zero_not_supported',inference_status='not_evaluable',
                      reason='Prototype declines categorical zero cells; no blanket claim of infinite joint MLE');return result
    if np.any(recovered==0) or np.any(recovered==introduced):
        result.update(status='extreme_binomial_not_supported',inference_status='not_evaluable',
                      reason='Prototype declines k=0 or k=L; a finite/boundary joint fit is not asserted without extended-MLE analysis');return result
    x,ui=design(c);empirical=counts/counts.sum(axis=2)[:,:,None];dhat=recovered/introduced
    odds=np.log(empirical[:,:,:2]/empirical[:,:,2,None]);start=np.zeros(9*c+1)
    for j in range(c):start[9*j:9*j+3]=[odds[j,0,0],odds[j,0,1],odds[j,1,0]]
    start[ui]=np.log(dhat.reshape(-1));start[-1]=np.median(corrected_contrast(empirical,dhat))
    beta,diag=minimize(x,y,L,k,ui,start);checks=[diag]
    if check_starts:
        second=np.zeros_like(start);second[ui]=-math.log(2)
        other,diag2=minimize(x,y,L,k,ui,second);checks.append(diag2)
        agree=diag2['converged'] and np.max(np.abs(other-beta))<1e-5*(1+np.max(np.abs(beta)))
    else:agree=True
    if not diag['converged'] or not agree:
        result.update(status='optimizer_unresolved',inference_status='not_evaluable',optimizer_checks=checks);return result
    loss,_,hess=objective(beta,x,y,L,k,ui)
    try:
        eig=np.linalg.eigvalsh(hess)
        if not np.all(np.isfinite(eig)) or eig[0]<=0 or eig[-1]/eig[0]>1e14:raise np.linalg.LinAlgError('Unstable information')
        columns=np.concatenate((ui,np.array([len(beta)-1])))
        covariance_columns=np.linalg.solve(hess,np.eye(len(beta))[:,columns])
        variance=float(covariance_columns[-1,-1])
        u_variances=covariance_columns[ui,np.arange(len(ui))]
        if not math.isfinite(variance) or variance<=0:raise np.linalg.LinAlgError('Invalid information variance')
        if not np.all(np.isfinite(u_variances)) or np.any(u_variances<=0):raise np.linalg.LinAlgError('Invalid control information variance')
    except np.linalg.LinAlgError:
        result.update(status='information_unresolved',inference_status='not_evaluable',optimizer_checks=checks);return result
    fitted=np.exp(log_softmax(x@beta)).reshape(c,2,3);u=beta[ui].reshape(c,2,3);d=np.exp(u)
    q=np.exp(log_softmax(np.log(fitted[:,0])-u[:,0]));p=np.exp(log_softmax(np.log(fitted[:,1])-u[:,1]))
    if np.any(fitted<=0) or np.any(q<=0) or np.any(p<=0) or np.any(d<=0) or np.any(d>=1):
        result.update(status='numerical_probability_unresolved',inference_status='not_evaluable');return result
    deviation=2*(result['loglik_saturated']+loss)
    # Decline a deviance whose subtraction is unreliable at the likelihood scale.
    roundoff_bound=16*np.finfo(float).eps*(abs(loss)+abs(result['loglik_saturated']))
    if roundoff_bound>1e-5*max(1.,abs(deviation)):
        result.update(status='likelihood_precision_unresolved',inference_status='not_evaluable',
                      reason='Likelihood magnitudes prevent sufficiently precise deviance subtraction');return result
    if deviation < -1e-7*(1+y.sum()+L.sum()):
        result.update(status='optimizer_unresolved',inference_status='not_evaluable',reason='Violated model nesting');return result
    eta=.5*(np.log(p[:,0])-np.log(p[:,2])-np.log(q[:,0])+np.log(q[:,2]))
    vc,parts=variance_components(fitted,d,counts.sum(axis=2),introduced)
    expcat=fitted*counts.sum(axis=2)[:,:,None];success=introduced*d;failure=introduced*(1-d)
    minimum=min(float(expcat.min()),float(success.min()),float(failure.min()))
    result.update(status='interior',inference_status='estimable' if c>1 else 'not_evaluable',
                  theta=float(beta[-1]),eta=eta.tolist(),fitted_observed_probabilities=fitted.tolist(),
                  absolute_control_recovery_probabilities=d.tolist(),log_control_recovery_probabilities=u.tolist(),
                  absolute_control_recovery_standard_errors_regular=(d*np.sqrt(u_variances.reshape(c,2,3))).tolist(),
                  corrected_baseline_probabilities=q.tolist(),corrected_selected_probabilities=p.tolist(),
                  theta_standard_error_regular=math.sqrt(variance),per_context_contrast_variance_regular=vc.tolist(),
                  variance_components_regular=parts.tolist(),variance_component_order=['baseline_categorical','selected_categorical','baseline_binomial_controls','selected_binomial_controls'],
                  deviance=max(0.,deviation),loglik_null=-loss,optimizer_checks=checks,
                  likelihood_subtraction_roundoff_bound=roundoff_bound,
                  information_condition_number=float(eig[-1]/eig[0]),minimum_expected_cell_or_binary_outcome=minimum,sparse=minimum<5,
                  identification_limit='Absolute control recovery is identified by introduced denominators. Actual biological recovery can retain an unknown branch-wide multiplier; establishment/mechanism is not identified.')
    if c==1:result['reason']='One context gives descriptive corrected theta and control efficiencies; shared-theta constancy imposes no restriction'
    return result


def bootstrap_fixed_route_controls(counts,introduced,recovered,replicates=199,seed=20261002):
    if not isinstance(replicates,int) or isinstance(replicates,bool) or replicates<1:raise ValueError('Positive integer bootstrap count required')
    counts,introduced,recovered=validate_arrays(counts,introduced,recovered)
    fit=fit_fixed_route_controls(counts,introduced,recovered)
    if fit['inference_status']!='estimable':return {'status':'not_evaluable','fit':fit,'p_value':None}
    rng=np.random.default_rng(seed);prob=np.asarray(fit['fitted_observed_probabilities']);d=np.asarray(fit['absolute_control_recovery_probabilities'])
    totals=counts.sum(axis=2);Li=introduced.astype(np.int64);stats=[];exceed=0;unresolved={};tol=1e-9*max(1.,fit['deviance'])
    for _ in range(replicates):
        sampled=np.array([[rng.multinomial(int(N),p) for N,p in zip(nc,pc)] for nc,pc in zip(totals,prob)])
        kb=rng.binomial(Li,d)
        trial=fit_fixed_route_controls(sampled,introduced,kb,check_starts=False)
        if trial['status']!='interior':unresolved[trial['status']]=unresolved.get(trial['status'],0)+1;continue
        stats.append(trial['deviance']);exceed+=trial['deviance']>=fit['deviance']-tol
    failures=sum(unresolved.values());bounds=[(1+exceed)/(replicates+1),(1+exceed+failures)/(replicates+1)]
    return {'status':'resolved' if not failures else 'partially_unresolved','fit':fit,
            'replicates':replicates,'seed':seed,'exceedances':int(exceed),'unresolved_replicates':failures,
            'unresolved_reasons':unresolved,'bootstrap_statistics':stats,'p_value':bounds[0] if not failures else None,
            'p_value_computational_bounds':bounds,'comparison_tolerance':tol,'monte_carlo_resolution':1/(replicates+1),
            'interpretation':'Estimated-null parametric bootstrap resamples both categorical outcomes and all route-specific binomial recoveries at fixed introduced denominators. Approximate composite-null calibration; unresolved draws are retained in computational bounds, which are not confidence intervals. Nonrejection does not prove transportability or mechanism.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('input',type=Path)
    parser.add_argument('--output',type=Path);parser.add_argument('--bootstrap',type=int,default=0);parser.add_argument('--seed',type=int,default=20261002)
    args=parser.parse_args()
    try:
        raw=args.input.read_bytes();doc=json.loads(raw);names,n,L,k=validate_document(doc)
        if args.bootstrap<0:raise ValueError('Bootstrap count cannot be negative')
        result=bootstrap_fixed_route_controls(n,L,k,args.bootstrap,args.seed) if args.bootstrap else fit_fixed_route_controls(n,L,k)
        result.update(schema_version='0.4.0',input_sha256=hashlib.sha256(raw).hexdigest(),metadata=doc['metadata'],
                      contexts=names,route_order=list(ROUTES),branch_order=list(BRANCHES),
                      provenance_warning='Synthetic fixtures are software checks, not biological evidence.' if doc['metadata']['provenance']=='synthetic' else 'Declarations and hashes do not authenticate binary-unit independence or recovery transport.')
        encoded=json.dumps(result,indent=2,allow_nan=False)+'\n'
        if args.output:args.output.write_text(encoded)
        else:print(encoded,end='')
    except (ValueError,TypeError,KeyError,OSError,np.linalg.LinAlgError) as exc:parser.exit(2,f'Invalid input or unresolved analysis: {exc}\n')

if __name__=='__main__':main()
