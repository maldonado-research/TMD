"""Convex multinomial + fixed-route binomial numerical primitives, TMD 0.4.0.
Copyright (c) 2026 Ricardo Maldonado. MIT; see LICENSE and VERSION_LINEAGE.md.
Log-softmax and Newton-line-search structure adapted from 0.2.0/0.3.0.
"""
import math
import numpy as np


def log_softmax(scores):
    z=scores-np.max(scores,axis=-1,keepdims=True)
    return z-np.log(np.exp(z).sum(axis=-1,keepdims=True))


def log1mexp(u):
    """Stable log(1-exp(u)), strictly negative finite u only."""
    u=np.asarray(u,float)
    if not np.all(np.isfinite(u)) or np.any(u>=0):
        raise ValueError('log efficiencies must be finite and strictly below zero')
    answer=np.empty_like(u); mask=u < -math.log(2)
    answer[mask]=np.log1p(-np.exp(u[mask]))
    answer[~mask]=np.log(-np.expm1(u[~mask]))
    return answer


def objective(beta,x,counts,introduced,recovered,u_indices):
    lp=log_softmax(x@beta); p=np.exp(lp); totals=counts.sum(axis=1)
    u=beta[u_indices]; complement_log=log1mexp(u)
    fail=introduced-recovered
    loss=-float(np.sum(counts*lp)+np.sum(recovered*u+fail*complement_log))
    grad=np.einsum('gkd,gk->d',x,totals[:,None]*p-counts)
    mean=np.einsum('gk,gkd->gd',p,x)
    hess=np.einsum('g,gk,gkd,gke->de',totals,p,x,x)-np.einsum('g,gd,ge->de',totals,mean,mean)
    with np.errstate(over='ignore',invalid='ignore'):
        bin_grad=-recovered+fail*np.exp(u-complement_log)
        bin_curvature=fail*np.exp(u-2*complement_log)
    grad[u_indices]+=bin_grad
    hess[u_indices,u_indices]+=bin_curvature
    return loss,grad,hess


def minimize(x,counts,introduced,recovered,u_indices,start,max_iter=160):
    beta=start.copy()
    # Huge controls must not relax convergence for theta/categorical coordinates.
    scale=np.einsum('g,gd->d',counts.sum(axis=1),np.max(np.abs(x),axis=1))
    scale[u_indices]+=introduced
    tolerance=np.maximum(1e-7,2e-12*scale)
    for iteration in range(max_iter):
        try:loss,grad,hess=objective(beta,x,counts,introduced,recovered,u_indices)
        except ValueError:return beta,{'converged':False,'reason':'invalid starting domain'}
        if not np.isfinite(loss) or not np.all(np.isfinite(grad)) or not np.all(np.isfinite(hess)):
            return beta,{'converged':False,'reason':'nonfinite objective or derivatives'}
        score=float(np.max(np.abs(grad)))
        if np.all(np.abs(grad)<=tolerance):
            return beta,{'converged':True,'iterations':iteration,'score_max':score,
                         'score_to_coordinate_tolerance_max':float(np.max(np.abs(grad)/tolerance)),'loss':loss}
        try:step=np.linalg.solve(hess,grad)
        except np.linalg.LinAlgError:return beta,{'converged':False,'reason':'singular Hessian','score_max':score}
        descent=float(grad@step)
        if not math.isfinite(descent) or descent<=0:
            return beta,{'converged':False,'reason':'invalid Newton direction','score_max':score}
        # beta_new=beta-alpha*step; negative step components increase u toward 0.
        moving=step[u_indices]<0
        alpha=1.
        if np.any(moving):
            limit=np.min(-beta[u_indices][moving]/(-step[u_indices][moving]))
            alpha=min(alpha,.99*float(limit))
        for _ in range(60):
            candidate=beta-alpha*step
            if np.all(candidate[u_indices]<0):
                trial=objective(candidate,x,counts,introduced,recovered,u_indices)[0]
                if math.isfinite(trial) and (trial<=loss-1e-4*alpha*descent or
                    (abs(trial-loss)<1e-11*(1+loss) and alpha*descent<1e-8)):
                    beta=candidate;break
            alpha*=.5
        else:return beta,{'converged':False,'reason':'line search failed','score_max':score}
    return beta,{'converged':False,'reason':'iteration limit','score_max':score}


def saturated_loglik(counts,introduced,recovered):
    categorical=0.
    for row in counts:
        positive=row>0
        if row.sum():categorical+=float(np.sum(row[positive]*np.log(row[positive]/row.sum())))
    # Boundary conventions 0*log0=0; zero introduced totals supply no binomial likelihood.
    mask=introduced>0; ll=0.
    L=introduced[mask]; k=recovered[mask]; fail=L-k
    good=k>0; ll+=float(np.sum(k[good]*np.log(k[good]/L[good])))
    good=fail>0; ll+=float(np.sum(fail[good]*np.log(fail[good]/L[good])))
    return categorical+ll
