# A proposed fixed-input recovery study

Version 0.4.0; statistical protocol proposal only. No authenticated laboratory procedure, measured matched panel, executed experiment or registered preregistration is supplied. Previous 0.3.0 randomized-mixture controls remain a separate supported design; this release addresses fixed per-route introduced totals.

## Before data: lock the unit and question

Fix the Wsp/Aws/Mws route dictionary, background, environment/history, observation endpoint, excluded routes and exhaustive-triad or common conditional-triad rule. Use two or more contexts to test a shared corrected contrast. One context identifies a descriptive contrast under the assumptions but imposes no constancy restriction.

Independently justify the categorical baseline assay. Pathway-isolated sequencing totals and fluctuation colonies are not automatically mutation-supply samples. Endpoint data do not become first-arrival times. A recovered outcome must represent the same eligibility and route-classification rule in baseline and selected samples.

For each control define a known introduced unit, a locked binary recovery outcome and observation time. Count each unit once. If the unit is a verified single cell, document its verification; if it is a sorted event, preserve multiplicity and use that unit without asserting it was one cell. Growth medium, physical transfer, detection thresholds and delayed outgrowth can all change the endpoint. Reads and clonal descendants are not additional introduced trials.

## Required records and separation

For each context and baseline/selected branch, record three biological route counts and three control introduced/recovered pairs. Control introduced totals may differ by route and branch. Retain every failure, missing label, unexpected route, batch, plate, culture and lineage identifier. Do not reconstruct exact integer trials from rounded percentages, approximate concentrations or DNA mass.

The current likelihood is two independent multinomials plus six independent binomials per context. All arms, route-specific controls and contexts must have genuinely independent units under the admitted model. Shared culture or plate effects can invalidate binomial independence despite physically distinct cells; separate spreadsheet rows do not solve this. Fixed-input successes/trials cannot be sent to the 0.3.0 random-mixture likelihood, and random-mixture recovered counts cannot be relabeled as fixed-input trials. No noisy-input, misclassification, correlated or bulk-read likelihood is implemented here.

## Match control recovery to biological observation

Controls must measure the same stage and endpoint as the corresponding actual sample. A post-extraction molecule cannot calibrate pre-extraction cell loss. An outgrowth success may combine viability, transfer, growth and detection; do not call it an isolated physical recovery probability or biological establishment without independent evidence.

Absolute control-process recovery is estimable because introduced denominators are known. Relative recovery must still transfer to evolving biological units to identify the biological corrected contrast. Unknown common branch scales cancel; biological absolute recovery remains unidentified. Check different representatives within each route, abundance, matrix, batch and physiological history using held-out control batches and locked discrepancy tolerances. Nonrejection with weak controls cannot establish transfer.

## Plan whether the prototype can return an answer

Use defensible pilot b,t and control recovery probabilities, actual introduced/recovered-unit costs and dependence structure. Check expected success and failure counts, and the exact model probability of observing supported cells. The prototype conservatively declines categorical zeros and all-success/all-failure control cells. These are computational support limits, not automatic biological failures or a theorem that finite fits are impossible.

The planner reports regular variance, conditional policy-support probability, component count floors and budget conflicts. Its floors guarantee a specified policy target only under true planning probabilities; uncertain pilots need worst-case analysis. They do not guarantee resolved bootstraps, sufficient power, admissible biology or transfer. Costs mix recovered biological observations with introduced control units; model yield and overhead before treating them as money.

Freeze the actual design and run repeated-sample simulations across plausible null, weak and relevant alternatives, rare/high-recovery controls, and transport failures. Retain declined datasets and unresolved draws in reported denominators. Do not rerun, discard or pseudocount a sample until it produces a favorable p-value. Boundary inference is future work; a different validated model may be preferable to collecting an impractical number of trials solely to satisfy this prototype's support policy.

## Freeze inference and a real hold-out prediction

The current convex joint likelihood constrains a shared corrected theta while allowing context slopes eta. It is a compatibility test, not a mechanistic proof or a held-out route forecast if eta is estimated from those same selected outcomes. A biological prediction must lock theta and its independently justified directional tilt before reading held-out selected data. Compare proper predictive scores with credible alternatives using equal training access.

Record strict provenance and design declarations; they are necessary input fields, not authentication. Record the code version, seed/draw policy, threshold and computational failure rule. The parametric bootstrap resamples both biological count samples and every binomial control, preserving sample/exposed totals. It is approximate for a composite null; unresolved draws remain in computational p-value bounds. Sampling uncertainty and transport sensitivity must both be reported.

Archive unsuccessful controls, negative predictions and competing explanations along with favorable results. No suitable measured panel was found in the scoped local audit. Obtaining those independent measurements remains the empirical bottleneck.
