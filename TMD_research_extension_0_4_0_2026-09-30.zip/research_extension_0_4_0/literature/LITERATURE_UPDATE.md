# Literature update: fixed-input recovery controls need an explicit unit

Targeted primary-source review completed 2026-09-30, America/Los_Angeles (2026-10-01 04:22 UTC). Publication cutoff: 2026-09-30. Four additional studies were selected after checking the prior baseline and 0.2.0/0.3.0 reviews. This is not an exhaustive search or a claim that no other useful data exist. No biological dataset is admitted to the TMD test by this update.

## New primary studies

**Chen et al., published 10 April 2024: individual transfer and cultivation.** Laser ejection targets visually identified individual microbial cells. Cultivation experiments used nine predetermined receiving positions and six independent repetitions; E. coli was assessed after 24 hours. Mean E. coli recovery differed by beam method: 19% Gaussian, 57% flat-top, 78% vortex. These are cultivation outcomes after transfer, rather than sequence-read fractions. Rounded means are not exact successes/trials; sites share dishes. Relevant methods, results, discussion and data statement were read; raw trial records were not inspected. [Primary paper](https://www.frontiersin.org/journals/microbiology/articles/10.3389/fmicb.2024.1369506/full).

**Hira et al., published 1 October 2024: a sorted event is not necessarily one cell.** CPPT links pre-sort profiles to S. aureus outgrowth. Experiments include 96-event samples and a 960-event cohort. Imaging found >80% singlets and <20% doublets in studied gates. Cultivability differed between agar and liquid; some colonies appeared only after 48 or 72 hours. Methods distinguish detectable bulk growth timing from a cell's true lag. Relevant results, sorting/growth methods, discussion and data statements were read; supplementary spreadsheets were not retrieved. [Primary paper](https://www.nature.com/articles/s42003-024-06894-z).

**Forry et al., published 29 April 2024: agreement can coexist with bias.** An interlaboratory study compared five stool reference samples and two defined genomic-DNA mixtures. The DNA mixtures contained 13 species at approximately equal or staggered genomic proportions. Measurement consensus did not ensure accuracy against known composition. Stool received cellular spike-ins at an approximate concentration; this does not establish exact introduced-cell trials. Mock DNA lacks whole-cell lysis and matrix equivalence. Relevant full-PDF results, reference-material discussion, methods and availability statement were read. [Primary paper](https://www.nature.com/articles/s41598-024-57981-4), [readable publisher PDF](https://www.nature.com/articles/s41598-024-57981-4.pdf).

**Petrungaro et al., published 28 July 2026: biological background can redirect trajectories.** Robotic E. coli evolution across 258 selected deletion backgrounds and three antibiotics found broadly repeatable trajectories with function-dependent deviations. The background panel was chosen using resistance, growth and annotation criteria, then optimized for coverage; it is not a random sample of all genetic backgrounds. This is distinct from the previously reviewed Baheti folA analysis. Relevant results, background-selection/evolution methods and data statements were read. It informs biological selection and contingency, not recovery calibration. [Primary paper](https://www.nature.com/articles/s41467-026-76025-1), [author dataset identifier](https://doi.org/10.5281/zenodo.20082950).

## What these results require of the 0.4.0 design

The following are **our proposed design consequences**, not WS findings established by these studies.

| Question | Required interpretation for a fixed-route control |
|---|---|
| What was introduced? | Record individually verified units of a defined route, or explicitly use a sorted-event unit with its multiplicity audit. An estimated concentration, a sorted gate or fixed DNA mass is not automatically an exact number of single cells. |
| What counts as success? | Lock the assay stage, route identification, growth medium, observation time and detection threshold. Distinguish physical deposition, viable outgrowth, detectable colony formation and molecular recovery. |
| What is independent? | Preserve plate, culture and batch identifiers. Separate cells from the same culture are not automatically independent biological replicates. Repeated readings of one introduced unit are repeated outcomes of that unit, not new trials. |
| Can recovery transport? | Challenge the same-route recovery coefficient using relevant physiological states, genotypes, matrices and both observation branches. Calibration in one transfer or medium does not establish equivalence in another. |
| What likelihood applies? | A binomial success/trial model requires known exposed units, one locked binary outcome each and a justified common independent recovery probability. Bulk sequencing of a fixed input mixture instead needs its own representation/amplification model. Reads are not independently introduced cells. |

A useful prospective falsifier is a held-out, independently introduced control batch whose route-wise recovery differs materially from the calibrated prediction under the prespecified matching conditions. That challenges the observation model. A separate biological test then requires independently measured supply and selected-route outcomes with the same eligible-unit definition. Neither an epistasis result nor accurate recovery prediction establishes a TMD-specific correction.

## Data status and relationship to earlier reviews

No new matched W/A/M supply, selected-outcome and fixed-route recovery dataset was authenticated. Hira's Supplementary Dataset 2 is a candidate for auditing technical event-level outgrowth, but its exact spreadsheet semantics, exclusions and dependence have not been checked. It cannot currently be called an admissible binomial control panel. Chen's planned positions and rounded summaries cannot be reverse-converted into exact successes. Forry's sequence data and defined DNA mixtures are representation controls, not fixed-cell binomial recoveries. Petrungaro's trajectories lack the required matched recovery/supply panel.

The primary Forry paper links NIST raw-data and analysis records. The raw-data landing page was read; the analysis landing page failed in the web reader. No data files were downloaded or analysed. Petrungaro's text says “Zotero,” while its cited dataset DOI explicitly identifies Zenodo; the cited DOI is preserved without inventing a second repository. Source read scope and availability limits are recorded in `sources.json`.

These papers add measured reasons to audit input units, observation times, matrix transfer and genetic backgrounds. They complement the 0.3.0 barcode-bias/history/calibration review and do not replace its uncertainty or transport requirements. No novelty or empirical TMD proof is claimed.
