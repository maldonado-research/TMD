# TMD methods 0.6.0 publication scope

**Version: 0.6.0. Prepared 2 October 2026 (America/Los_Angeles).** This packaging document preserves its original filename. Actual publication state and available version DOI are recorded under the canonical research-report concept DOI https://doi.org/10.5281/zenodo.23068055; this document is not a Zenodo publication receipt.

Title: **Mutation by Natural Dominance: recovery-transport robustness and a prospective biological test**.

Author: Ricardo Maldonado, Independent Researcher; ORCID 0009-0009-3937-6527. New documentation: CC BY 4.0; code: MIT. No funding awards are claimed.

Abstract:

> This exploratory methods update integrates existing recovery-transport sensitivity with the finite-sample confidence projection of TMD methods 0.5.0. Exact rational correction allows prespecified positive routewise bounds on the differential discrepancy between biological and control recovery. All 160 published synthetic results are reanalyzed without resampling. All 40 strong-departure examples reject at a differential bound of 1.25; none reject at 1.5. Individual compatibility frontiers are enclosed by exact rational certificates. A chosen-count counterexample demonstrates a spurious departure under invalid exact transport and restored compatibility under a valid bound. The package includes 44 tests, an independent internal review, reproducible outputs, attribution and a prospective protocol for authenticated biological panels. A targeted five-source literature update sharpens mutation-supply, fitness and drift alternatives; an article-derived source audit records lineage and replicate limitations without claiming a raw-workbook reanalysis. Results are conditional on valid sampling laws and scientifically justified bounds. No new biological measurements, causal mechanism, external mathematical priority, general power or external peer review is claimed.

This archive freezes the reviewed methods content at source commit `465850ee33f746cf42f1b3d5075fba2ea57332ad` (1 October 2026). It excludes later continuation rounds. Packaging text and citation metadata have been finalized; the scientific code, results, dated source reviews, licensing, attribution and documented failed strict portability audit remain unchanged.

The preceding methods record is https://zenodo.org/records/23075312, in research-report concept DOI family 10.5281/zenodo.23068055. Publish an intentional version in this existing family using the verified latest published version's New version workflow and reuse a linked draft when present. Verify authenticated ownership, draft family, saved metadata and uploaded filenames, sizes and checksums before publication. Preserve the separate historical software DOI family. Automatic GitHub archiving must remain disabled; a GitHub release is not needed for this publication.

GitHub research and website changes follow the established review workflow. Associated review requests: [research update](https://github.com/maldonado-research/TMD/pull/1) and [website update](https://github.com/maldonado-research/maldonado-research.github.io/pull/1). Their live review and deployment state must be checked at those links rather than inferred from this archive. The earlier 0.5.0 public-record check is retained as a dated [receipt](EXISTING_0_5_0_PUBLICATION_RECEIPT.json).
