# TMD recovery-transport research follow-up

Ricardo Maldonado · 1 October 2026 · Exploratory methods and prospective research

Start with [the formulation and next empirical test](FORMULATION_AND_NEXT_EMPIRICAL_TEST.md), then [the reproducible sensitivity analysis](transport_robustness/README.md) and [independent internal review](TRANSPORT_MATH_REVIEW.md). The [five-source literature update](literature/LITERATURE_UPDATE_2026-10-01.md) develops competing explanations; the [public source eligibility audit](public_dataset_audit/AUDIT_REPORT.md) verifies a published table inventory without relabeling its measurements as TMD trials.

The biological priority remains an authenticated, prespecified matched route/control panel. This follow-up reuses all 160 published synthetic outputs and adds a chosen-count recovery-confounding counterexample. It integrates earlier methods rather than claiming a new mutation mechanism or statistical principle. All 44 tests pass. Independent checks confirm 640 original projections, 800 sensitivity-grid evaluations and 40 exact compatibility-frontier certificates.

Reproduce from this directory with Python 3.12.14 (only the standard library is needed):

```sh
python3 -m unittest discover -s transport_robustness -p 'test_transport_robustness.py' -v
python3 transport_robustness/run_reanalysis.py --check
python3 verify_transport_review.py --public-archive ../TMD_research_extension_0_5_0_2026-09-30.zip
```

The independent oracle writes its deterministic review receipt beside itself. Copy this directory to a scratch location before regenerating receipts or result files if preserving an untouched checkout. `run_reanalysis.py --check` compares outputs without rewriting them.

[Environment reproduction evidence](ENVIRONMENT_REPRODUCIBILITY.md) distinguishes successful computational checks from the original release's strict floating-result identity failure. [Publication scope](PUBLICATION_CANDIDATE.md) documents methods 0.6.0; it is not a publication receipt. Consult the canonical [research-report concept DOI](https://doi.org/10.5281/zenodo.23068055) for current publication state and the available version-specific citation. Scientific source reviews retain their dated 1 October 2026 status. Expanded report 0.1.0 and historical software v2.6.5 retain their own identifiers.

New code is MIT; new documentation is CC BY 4.0 under the repository licensing terms. Preserved public source artifacts retain attribution and their existing terms. Prepared with AI assistance; internal independent review is not external peer review.

## Public-source audit reproduction

The source XML remains outside this repository. To reproduce against the inspected local snapshot, supply its path explicitly:

```sh
python3 public_dataset_audit/reproduce_audit.py --source /path/to/sane_pmc.xml --output /tmp/tmd_public_source_audit.json
```

Alternatively, the script can attempt an official public acquisition with `--fetch-source`. Only the pinned source hash is accepted. The supplementary workbooks were not acquired, and no raw-workbook analysis or new biological test is reported.
