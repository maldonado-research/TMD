# TMD methods 0.6.0

Ricardo Maldonado · Exploratory methods research · Prepared 2 October 2026 (America/Los_Angeles)

This archive packages the recovery-transport robustness follow-up, five-source literature update, article-derived source audit and prospective biological-test formulation. It preserves the scientific content of the reviewed source snapshot at commit `465850ee33f746cf42f1b3d5075fba2ea57332ad` (1 October 2026). Later continuation rounds are outside this archive's scope. Start with research/README.md and research/PUBLICATION_CANDIDATE.md; the latter filename is retained from the original review package and now documents the finalized publication scope.

For the actual publication state and available version-specific citation, consult the canonical research-report concept DOI: https://doi.org/10.5281/zenodo.23068055. Preparation of this archive does not certify that a Zenodo publication has occurred. Source-review documents and the earlier-publication receipt preserve their dated historical status; those statements are not current publication receipts. The preceding methods 0.5.0 record is https://zenodo.org/records/23075312. Expanded report 0.1.0 and historical software v2.6.5 retain their own identifiers.

From the archive's top directory, using Python 3.12.14:

```sh
cd research
python3 -m unittest discover -s transport_robustness -p 'test_transport_robustness.py' -v
python3 transport_robustness/run_reanalysis.py --check
python3 verify_transport_review.py
```

The independent oracle writes a deterministic review receipt beside itself. Run in an extracted scratch copy. The optional --public-archive argument can check preserved inputs against the published 0.5.0 ZIP; that earlier complete ZIP is not duplicated here. Its SHA-256 is a92d0f04c2e19cd9922a0d234fb4bacc2ee6f3550c113c9bdd66d97feab0c1db.

For the article-derived audit, provide the pinned official source XML as documented in research/public_dataset_audit/AUDIT_REPORT.md. Third-party raw XML, PDFs and supplementary workbooks are excluded. The supplemental workbooks were not acquired in this source snapshot; no workbook reanalysis or matched biological TMD test is claimed.

All 160 preserved datasets are synthetic. Differential recovery bounds are hypothetical sensitivity inputs, not measured errors. The compatibility result is conditional on valid sampling and justified control-to-biology transfer. The prior release's strict floating-fixture portability audit remains failed and documented in research/ENVIRONMENT_REPRODUCIBILITY.md. It is not hidden by this archive's successful exact-rational replay.

New code is MIT; new documentation and derived summaries are CC BY 4.0. Preserve source attribution and inherited terms. See LICENSE and LICENSING.md. AI assistance and independent internal review are disclosed; there is no external peer-review claim. No private archive files, uploaded handoffs, personal documents or sensitive datasets are included.
