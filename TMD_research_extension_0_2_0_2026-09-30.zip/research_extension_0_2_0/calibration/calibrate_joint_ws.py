"""Small prespecified synthetic exercise; not universal or biological calibration."""
import hashlib
import json
import math
from pathlib import Path
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'inference'))
from joint_ws_inference import bootstrap_lrt, log_softmax

SEED = 2026100301
DATASETS = 40
BOOTSTRAPS = 99
ALPHA = .05
Q = np.array([[.18,.63,.19],[.48,.13,.39],[.1,.25,.65],[.52,.35,.13]])
ETA = np.array([-.3,.2,.7,-.6])
SELECTED_N = 600
CALIBRATION_M = 600


def wilson(k,n):
    z = 1.959963984540054
    center = (k/n+z*z/(2*n))/(1+z*z/n)
    half = z*math.sqrt((k/n)*(1-k/n)/n+z*z/(4*n*n))/(1+z*z/n)
    return [max(0.,center-half),min(1.,center+half)]


def selected(theta):
    return np.exp(log_softmax(np.log(Q)+np.column_stack((ETA,theta,-ETA))))


def summarize_trial(fit):
    initial = fit['fit']['status']
    p = fit.get('p_value')
    bounds = fit.get('p_value_computational_bounds')
    if bounds is not None:
        decision = 'definite_rejection' if bounds[1] <= ALPHA else 'definite_nonrejection' if bounds[0] > ALPHA else 'unresolved_decision'
    else:
        decision = 'unresolved_decision'
    return {'initial_fit_status':initial,'bootstrap_status':fit['status'],
            'p_value':p,'p_value_computational_bounds':bounds,'decision':decision,
            'deviance':fit['fit'].get('deviance'),
            'unresolved_bootstrap_replicates':fit.get('unresolved_replicates',0),
            'unresolved_bootstrap_reasons':fit.get('unresolved_reasons',{})}


def scenario(name,theta,rng):
    p = selected(theta)
    trials = []
    for index in range(DATASETS):
        m = np.array([rng.multinomial(CALIBRATION_M,row) for row in Q])
        n = np.array([rng.multinomial(SELECTED_N,row) for row in p])
        bootseed = int(rng.integers(0,2**32))
        result = bootstrap_lrt(m,n,replicates=BOOTSTRAPS,seed=bootseed)
        trials.append({'dataset_index':index,'bootstrap_seed':bootseed,
                       'baseline_counts':m.tolist(),'selected_counts':n.tolist(),
                       **summarize_trial(result)})
    rejected = sum(t['decision']=='definite_rejection' for t in trials)
    uncertain = sum(t['decision']=='unresolved_decision' for t in trials)
    initial_bad = sum(t['initial_fit_status']!='interior' for t in trials)
    bootbad = sum(t['unresolved_bootstrap_replicates'] for t in trials)
    started = sum(t['initial_fit_status']=='interior' for t in trials)*BOOTSTRAPS
    return {'name':name,'true_theta_by_context':theta.tolist(),'baseline_q':Q.tolist(),
            'selected_p':p.tolist(),'datasets':DATASETS,'selected_n_per_context':SELECTED_N,
            'calibration_m_per_context':CALIBRATION_M,'definite_rejections':rejected,
            'definite_rejection_proportion':rejected/DATASETS,
            'wilson95_for_definite_rejection_indicator':wilson(rejected,DATASETS),
            'unresolved_decisions':uncertain,'rejection_proportion_computational_bounds':[rejected/DATASETS,(rejected+uncertain)/DATASETS],
            'initial_noninterior_or_unresolved_fits':initial_bad,
            'initial_failure_fraction':initial_bad/DATASETS,
            'unresolved_bootstrap_draws':bootbad,'attempted_bootstrap_draws':started,
            'unresolved_bootstrap_draw_fraction':bootbad/started if started else None,
            'trials':trials}


def main():
    started = time.monotonic()
    rng = np.random.default_rng(SEED)
    scenarios = [scenario('dense_shared_theta_null',np.full(4,.4),rng),
                 scenario('dense_heterogeneous_theta_alternative',np.array([-.5,0.,.7,1.3]),rng)]
    # Same latent q,p, but recovery differs by route and context only in selection.
    latent_theta = np.full(4,.4)
    latent_p = selected(latent_theta)
    recovery = np.ones((4,3)); recovery[[1,3],1] = .5
    recovered_p = latent_p*recovery
    recovered_p /= recovered_p.sum(axis=1)[:,None]
    v = np.array([-.5,1.,-.5])
    observed_theta = (v*(np.log(recovered_p)-np.log(Q))).sum(axis=1)
    m = np.array([rng.multinomial(CALIBRATION_M,row) for row in Q])
    n = np.array([rng.multinomial(SELECTED_N,row) for row in recovered_p])
    biasseed = int(rng.integers(0,2**32))
    biasresult = bootstrap_lrt(m,n,replicates=199,seed=biasseed)
    result = {'provenance':'synthetic_simulation_only','seed':SEED,'alpha':ALPHA,
              'datasets_per_scenario':DATASETS,'bootstrap_replicates_per_dataset':BOOTSTRAPS,
              'monte_carlo_p_resolution':1/(BOOTSTRAPS+1),
              'assumptions':['independent multinomial cultures/units and samples',
                             'fixed per-context sample totals and known route dictionary',
                             'no censoring, clustering, or measurement error in the first two scenarios',
                             'calibration and selection matched except intentionally biased recovery fixture'],
              'inference_file_sha256':hashlib.sha256((ROOT/'inference/joint_ws_inference.py').read_bytes()).hexdigest(),
              'scenarios':scenarios,
              'ascertainment_fixture':{'provenance':'synthetic','latent_theta':latent_theta.tolist(),
                 'selected_recovery':recovery.tolist(),'baseline_recovery':np.ones((4,3)).tolist(),
                 'recovered_theta':observed_theta.tolist(),'baseline_counts':m.tolist(),
                 'selected_counts':n.tolist(),'bootstrap_seed':biasseed,
                 'bootstrap_replicates':199,**summarize_trial(biasresult),
                 'interpretation':'A route recovery change produces the same contrast departure as biological model violation. This statistical test cannot distinguish these explanations.'},
              'runtime_seconds':time.monotonic()-started,
              'interpretation':'Forty generated datasets per chosen scenario, not universal calibration. Wilson intervals describe simulation rejection indicators, not biological uncertainty. Parametric bootstrap uses estimated nuisance parameters and is approximate.'}
    target=Path(__file__).with_name('synthetic_calibration_results.json')
    target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    for s in scenarios:
        print(s['name'],s['definite_rejections'],s['datasets'],s['wilson95_for_definite_rejection_indicator'],'initial failures',s['initial_failure_fraction'],'unresolved draws',s['unresolved_bootstrap_draws'],flush=True)
    print('ascertainment fixture',result['ascertainment_fixture']['p_value'],'seconds',result['runtime_seconds'],flush=True)

if __name__=='__main__':main()
