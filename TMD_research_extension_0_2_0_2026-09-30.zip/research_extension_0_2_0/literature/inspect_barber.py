"""Read-only, attributed extraction of selected factual cells from Barber 2026.

Run with bundled Python and pass paths to the original publisher workbooks.
The published workbooks are never modified or exported by this script.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import pandas as pd


def inspect(source_path, supplementary_path, output_dir):
    source_sha = hashlib.sha256(Path(source_path).read_bytes()).hexdigest()
    supplementary_sha = hashlib.sha256(Path(supplementary_path).read_bytes()).hexdigest()
    if source_sha != "1aa352f176bd5ffcc0ae2669eb15a961f45ad3719b3fe7dbcbe23c6b1205abee" or supplementary_sha != "88aa98d3e1c376e1558ebce8e9b854e6fb0758c69a46cb197b0a0e90850a1efc":
        raise ValueError("Source workbook revision differs from the inspected primary files; audit cell mapping before extraction.")
    source = pd.read_excel(source_path, sheet_name=None, header=None)
    supplementary = pd.read_excel(supplementary_path, sheet_name=None, header=None)
    sheet = source["Figure 3A"]
    sizes = ["L", "ML", "M", "MS", "S"]
    groups = []
    for background, treatment_col, isolate_col, tem_cols, pbp_cols in [
        ("delta_mutT", 0, 1, range(2, 6), range(6, 18)),
        ("delta_mutH", 19, 20, range(21, 24), range(24, 30)),
    ]:
        buckets = {x: [] for x in sizes}
        printed_labels = {}
        # Five blocks are separated by repeated headers. Preserve the author's
        # duplicated ML label on the third delta_mutH block. The M mapping is
        # an explicit inference corroborated against Figure 3B below.
        starts = [5, 16, 27, 38, 49] if background == "delta_mutT" else [5, 11, 17, 23, 29]
        expected = 10 if background == "delta_mutT" else 5
        for treatment, start in zip(sizes, starts):
            printed_labels[treatment] = sheet.iloc[start, treatment_col]
            for r in range(start, start + expected):
                row = sheet.iloc[r]
                isolate = row[isolate_col]
                assert isinstance(isolate, (int, float)) and pd.notna(isolate)
                assert float(isolate).is_integer()
                tem = [row[c] for c in tem_cols if pd.notna(row[c])]
                pbp = [row[c] for c in pbp_cols if pd.notna(row[c])]
                assert all("->" in str(x) for x in tem + pbp)
                buckets[treatment].append((int(isolate), len(tem), len(pbp), r + 1))
        for block_index, (size, records) in enumerate(buckets.items(), start=1):
            expected = 10 if background == "delta_mutT" else 5
            assert len(records) == expected
            assert sorted(x[0] for x in records) == list(range(1, expected + 1))
            groups.append({
                "background": background,
                "group_id": f"{background}_block{block_index}",
                "size_class_printed_label": printed_labels[size],
                "intended_size_class_candidate": size,
                "size_mapping_inferred": printed_labels[size] != size,
                "sequenced_isolates": len(records),
                "TEM_only": sum(t > 0 and p == 0 for _, t, p, _ in records),
                "PBP3_only": sum(p > 0 and t == 0 for _, t, p, _ in records),
                "both_focal_loci": sum(t > 0 and p > 0 for _, t, p, _ in records),
                "neither_focal_locus": sum(t == 0 and p == 0 for _, t, p, _ in records),
                "TEM_substitution_observations": sum(t for _, t, _, _ in records),
                "PBP3_substitution_observations": sum(p for _, _, p, _ in records),
                "source_sheet": "Figure 3A",
                "source_excel_rows": ",".join(str(r) for _, _, _, r in records),
                "source_TEM_columns": "C:F" if background == "delta_mutT" else "V:X",
                "source_PBP3_columns": "G:R" if background == "delta_mutT" else "Y:AD",
            })
    # Independent within-workbook crosscheck uses published per-isolate means.
    means = source["Figure 3B"]
    crosschecks = []
    for index, group in enumerate(groups):
        row = means.iloc[index + 3]
        assert row[1] == group["intended_size_class_candidate"]
        expected_tem = float(row[2] + row[3]) * group["sequenced_isolates"]
        expected_pbp = float(row[4] + row[5]) * group["sequenced_isolates"]
        crosschecks.append({"group_id": group["group_id"], "Figure3B_size_label": row[1], "Figure3B_TEM_mean_cells": f"Figure 3B!C{index+4}:D{index+4}", "Figure3B_PBP3_mean_cells": f"Figure 3B!E{index+4}:F{index+4}", "Figure3B_implied_TEM_substitutions": expected_tem, "Figure3A_TEM_substitutions": group["TEM_substitution_observations"], "Figure3B_implied_PBP3_substitutions": expected_pbp, "Figure3A_PBP3_substitutions": group["PBP3_substitution_observations"]})
    # Preserve survival percentages as reported. The ML delta_mutH denominator
    # conflicts with the stated 48 starting populations; never invent counts.
    survival = []
    for r in (16, 30):
        row = source["Figure 2B"].iloc[r]
        for c, size in enumerate(sizes, start=2):
            survival.append({
                "background": "delta_mutT" if r == 16 else "delta_mutH",
                "size_class": size,
                "CTX_mg_per_L": row[1],
                "reported_survival_percent": float(row[c]),
                "stated_initial_population_count": 24 if size == "L" else 48,
                "exact_survivor_count": None,
                "denominator_unresolved": r == 30 and size == "ML",
                "source_cell": f"Figure 2B!{chr(65+c)}{r+1}",
            })
    metadata = {
        "schema_version": "0.1",
        "access_date_local": "2026-09-30",
        "access_timezone": "America/Los_Angeles",
        "primary_article": "https://doi.org/10.1038/s41467-026-74044-6",
        "source_workbook_url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-026-74044-6/MediaObjects/41467_2026_74044_MOESM6_ESM.xlsx",
        "supplementary_workbook_url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-026-74044-6/MediaObjects/41467_2026_74044_MOESM3_ESM.xlsx",
        "observation": "Sanger focal-locus genotypes in selected longest-surviving lineages",
        "arrival_time_available": False,
        "exhaustive_adaptive_route_set": False,
        "independent_context_specific_q_available": False,
        "source_sha256": source_sha,
        "supplementary_sha256": supplementary_sha,
        "source_workbook_sheets": {k: list(v.shape) for k, v in source.items()},
        "supplementary_workbook_sheets": {k: list(v.shape) for k, v in supplementary.items()},
        "endpoint_focal_locus_groups": groups,
        "Figure3A_Figure3B_crosschecks": crosschecks,
        "endpoint_survival_percentages": survival,
        "verification": {
            "sequenced_isolates": sum(g["sequenced_isolates"] for g in groups),
            "TEM_substitution_observations": sum(g["TEM_substitution_observations"] for g in groups),
            "PBP3_substitution_observations": sum(g["PBP3_substitution_observations"] for g in groups),
            "article_reported_PBP3_substitution_observations": 91,
            "all_categories_reconcile_to_isolates": all(sum(g[k] for k in ("TEM_only", "PBP3_only", "both_focal_loci", "neither_focal_locus")) == g["sequenced_isolates"] for g in groups),
            "all_focal_substitution_totals_match_independent_Figure3B_means": all(abs(x["Figure3B_implied_TEM_substitutions"] - x["Figure3A_TEM_substitutions"]) < 1e-9 and abs(x["Figure3B_implied_PBP3_substitutions"] - x["Figure3A_PBP3_substitutions"]) < 1e-9 for x in crosschecks),
            "workbook_substitution_totals_by_background": {b: {"TEM": sum(g["TEM_substitution_observations"] for g in groups if g["background"] == b), "PBP3": sum(g["PBP3_substitution_observations"] for g in groups if g["background"] == b)} for b in ("delta_mutT", "delta_mutH")},
        },
        "admissibility_issues": [
            "Sanger lineages were selected among those that survived longest; sampling is not random among all starting populations or necessarily all day-28 survivors.",
            "Figure 2B delta_mutH ML reports 95.238095 and 85.714286 percent, which do not equal integer/48 percentages. Exact denominator remains unresolved.",
            "Figure 3A T18 repeats ML for its third delta_mutH block. Intended M is a candidate inference from five-class order and Figure 3B labels. Use stable block IDs; retain the printed label and do not assert corrected group identity.",
            "Figure 3A delta_mutT block2 G17:R26 has 13 nonblank PBP3 substitution cells, while Figure 3B E5:F5 gives (0.8+0.3)*10=11. Nine other blocks reconcile on focal substitution totals; the overall crosscheck fails.",
            "Article Results reports delta_mutT TEM24/PBP3 75 and delta_mutH TEM34/PBP3 16; Figure 3A gives TEM24/PBP3 75 and TEM32/PBP3 15. The article's overall TEM56 also conflicts with its stated 24+34=58 background subtotal. No source values are corrected.",
            "Whole-genome samples pool equal DNA from five clones per treatment; Supplementary Data 1 rows are pooled variant calls, not individually independent mutant observations.",
            "TEM-only/PBP3-only/both/neither are classifications of focal-locus observations; neither does not mean no adaptation and both cannot be assigned a single route winner.",
            "Mutation baseline is not measured per focal route in each experimental condition; referenced rifampicin mutator multipliers cannot be treated as exact q for TEM/PBP3.",
        ],
    }
    assert metadata["verification"]["sequenced_isolates"] == 75
    assert metadata["verification"]["TEM_substitution_observations"] == 56
    if metadata["verification"]["PBP3_substitution_observations"] != 91:
        metadata["admissibility_issues"].append("Figure 3A nonblank PBP3 substitution cells total " + str(metadata["verification"]["PBP3_substitution_observations"]) + ", differing from the article's 91. Preserve the workbook count and unresolved discrepancy.")
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "BARBER_DATA_INSPECTION.json").write_text(json.dumps(metadata, indent=2) + "\n")
    with (output_dir / "barber2026_focal_locus_counts.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(groups[0]))
        writer.writeheader()
        writer.writerows(groups)
    return metadata["verification"]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source_workbook")
    parser.add_argument("supplementary_workbook")
    parser.add_argument("output_dir")
    args = parser.parse_args()
    print(json.dumps(inspect(args.source_workbook, args.supplementary_workbook, args.output_dir)))
