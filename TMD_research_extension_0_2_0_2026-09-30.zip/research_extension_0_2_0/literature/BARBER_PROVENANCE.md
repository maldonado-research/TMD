# Barber 2026 source inspection

Source: Jake N. Barber and Alejandro Couce, *Mutation-biased adaptation is consequential even in large bacterial populations*, Nature Communications 17, 7357. DOI https://doi.org/10.1038/s41467-026-74044-6. Research access date: 30 September 2026 local time.

`inspect_barber.py` reads the two publisher XLSX files without modifying them. It produces a compact factual CSV and JSON inspection record. The original files are cached locally at `publisher_cache/`, outside the extension's distributable folder. Publisher article license is CC BY-NC-ND 4.0; no new license is applied to the source workbooks. File-specific terms were not independently established. New analysis code does not transfer rights to source materials.

The observational gate is **longest-surviving-lineage selection**. Source Article Methods, “Sanger sequencing,” states that 10 ΔmutT and 5 ΔmutH populations per size class were selected among lineages surviving longest. All 75 sequenced rows are retained, including those with neither focal locus. They are not first winners and have no first-event times. No inference about unobserved adaptation or establishment follows from a blank focal-locus cell.

Figure 3A row 5 contains protein-residue columns. TEM and PBP3 regions are C:F/G:R for ΔmutT and V:X/Y:AD for ΔmutH. Treatment and isolate columns are A/B and T/U. Each nonblank substitution cell is counted once; repeated focal changes within the same isolate remain multiple substitution observations. Blocks are separated by repeated headers. JSON/CSV retain exact Excel rows and stable block IDs. Category totals reconcile to 10 or 5 isolate rows per block. A separate crosscheck against Figure 3B means exposes the ΔmutT block-2 PBP3 discrepancy rather than changing either source.

Printed ΔmutH third-block label ML is preserved. Candidate intended M follows ordered design and Figure 3B, not an authenticated correction. Figure 2B endpoint percentages remain percentages; exact survivor counts are null for all cells. The ML ΔmutH denominator is unresolved. Source Data Figure 4A and Supplementary Data 1 are not counted as independent isolate mutations because the paper's WGS protocol pools DNA from five isolates per treatment.

Reproduce with the bundled Python runtime (pandas available):

```text
python inspect_barber.py publisher_cache/barber2026_source_data.xlsx publisher_cache/barber2026_supplementary_data.xlsx <output-directory>
```

This extraction produces no p-value, causal attribution, first-arrival estimate, or TMD validation result. Numeric discrepancies remain open and should be resolved before a definitive condition-level prediction comparison.

The Figure 3A/Figure 3B mismatch is specifically ΔmutT block 2: G17:R26 contains 13 PBP3 substitutions, while Figure 3B!E5:F5 implies 11. Nine other blocks match both focal totals. The article's ΔmutH subtotal TEM34/PBP3 16 differs from Figure 3A TEM32/PBP3 15, and its overall PBP3 91 differs from the workbook's 90. The article's stated TEM24+34 subtotal also differs from its overall TEM56. The script reports these discrepancies and refuses a workbook with a different hash before using this cell mapping.
