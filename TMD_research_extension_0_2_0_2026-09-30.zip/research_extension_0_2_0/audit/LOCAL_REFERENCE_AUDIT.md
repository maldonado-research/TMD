# Local reference audit for TMD extension 0.2.0

Audit date: 2026-09-30. Original research folders, archives, and `sources/` were preserved. This audit adds no new biological observations.

## Result

No newly authenticated biological dataset or independent, context-matched route baseline counts were found in the inspected local material. The usable published data remain the baseline release's WS selected-route summaries and rpoB endpoint spectra. A three-rate WS supply summary exists, but raw mutation-assay observations, uncertainties, and matched multi-context calibration counts are absent from the inspected files. This is a scoped negative finding, not proof that unopened archives, four unsynced sources, or other locations contain no data.

A substantive extension can therefore develop and validate an uncertainty-aware analysis using clearly synthetic calibration counts, and specify the real data required. It cannot present such counts as measured WS biology. Retrieving independent published supply assays and their raw data remains an empirical priority.

## Scope and method

Read the four baseline documents in `output/research_progress_2026-09-30/github_repository/`: `SCIENTIFIC_PROGRESS.md`, `DATA_AND_PROVENANCE_AUDIT.md`, `EVIDENCE_AND_CLAIMS.md`, and `PROSPECTIVE_TEST_PLAN.md`.

Listed 4,924 paths under `local_archive/TMD` and `local_archive/D-Blast_3/VECTOR STORE`. Content searching in the latter was restricted to its `MUTATION BY NATURAL DOMINANCE VECTOR STORE` subfolder. Screened 928 unique small text files in the TMD research root after excluding validation directories, `__MACOSX`, nontext files, and files over 300,000 bytes. Searched for Dirichlet, beta-binomial, independent cultures, fluctuation, baseline counts, supply calibration, unselected, and mutation-rate terms. Inspected two relevant ZIP central directories and short members; did not extract or run archived software. Large documents and all archive members were not exhaustively searched. No unrelated personal folders were examined.

`inventory.json` records 20 directly inspected evidence items with byte hashes, classifications, and relevant line numbers. A byte hash verifies a particular artifact; it does not establish biological authenticity.

## Direct evidence

All paths below are relative to `local_archive/TMD`, unless stated otherwise.

| Item | Small evidence snippet | Interpretation |
|---|---|---|
| `untitled folder 58/TMD_real_system_case_study_Pf_WS_v1_3/Pseudomonas_WS_mutation_rates_Lind2019.csv`, lines 1–4 | `pathway,mu_rate,units`; Wsp `3.7e-09`, Aws `6.5e-09`, Mws `7.4e-10`; `per cell generation` | Three published rate point estimates. There is no culture-level denominator, variance, confidence interval, or per-condition replicate series in this file. |
| Same folder, `Pseudomonas_WS_route_counts_McDonald2009_derived.csv`, lines 2–4 | Wsp 17, Aws 6, Mws 3; each `n_total=26`; source `McDonald et al. (2009) Table 1` | Selected endpoint outcomes, not independent mutation-supply calibration observations. |
| Same folder, `TMD_real_system_case_study_Pf_WS_v1_3.md`, line 6 | `pilot / demonstration` and `mutation-rate estimates and selection outcomes come from different studies (and not identical conditions)` | Local document already acknowledges cross-study mismatch. Its residual factors must not be called separately measured fixation or persistence. |
| Same folder, pilot note line 13 | `26 independent WS genotypes ... each isolated from a separate microcosm after selection` | The note reports independent selected endpoints. Primary verification and sampling eligibility remain governed by the baseline audit. |
| Same folder, `tmd_ws_case_study_analysis.py`, lines 104–107 | `Dirichlet posterior summaries (P ~ Dirichlet(counts+1))`; `rng.dirichlet(alpha, size=400_000)` | Existing selected-outcome posterior uncertainty; rates are read and treated as fixed. Generated posterior draws are not new experiments. |
| `untitled folder 120/tmd_evidence_vs_null_v0_2_uncertainq.py`, lines 8–9, 117–138 | `uncertain mechanistic null Dirichlet(beta*q)`; `beta controls confidence`; `null_alpha = float(beta) * q` | Existing prior sensitivity approach. It provides no independent baseline-count likelihood or empirical estimate of beta. |
| `untitled folder 120/TMD_flagship_prereg_WS_muonly_v0_1.md`, lines 49, 61, 113–116 | q from `independent mutation/target-size measurements`; optional `Dirichlet(β q)` | Proposed preregistration rather than evidence that matched measurements were obtained. |
| `untitled folder 111/TMD_mechanistic_null_q_builder_instructions_v0_1.md`, lines 15–20 | `Input columns you fill`; `mu_proxy`; `A_proxy` | Builder accepts supplied proxies. Its existence does not authenticate empirical q. |
| `untitled folder 241/TMD_empirical_grounding_pack_2026-04-16.zip::TMD_rpoB_minimal_empirical_campaign_2026-04-16.md`, lines 7–9, 39 | `collects literature-backed evidence`; `proposes a minimal empirical campaign`; `not a statistical posterior` | Literature synthesis and heuristic priorities. Ledger assertions and votes are not count observations or rate calibration. |
| `untitled folder 229/TMD_switch_cost_calibration_pack_2026-04-02.zip::tmd_switch_cost_calibration_2026_04_02/TMD_switch_cost_calibration_and_dwell_interval_note_v0_1_2026-04-02.md`, line 14 | `Witness-preserving calibration theorem` | Calibration concerns controller decision costs and mathematical intervals. It does not calibrate mutation supply experimentally. |

The vector-store file `local_archive/D-Blast_3/VECTOR STORE/MUTATION BY NATURAL DOMINANCE VECTOR STORE/TMD_complete_research_handoff_and_100_explore_questions_2026-09-08.md`, line 70, calls v2.6.4 a closed-loop external-validation workflow rather than new wet-lab validation. Lines 93–94 state that independent wet-lab confirmation is not claimed. These handoffs summarize the research record; they are not separate datasets.

## Duplicates and unsuitable baseline observations

The folder58 rate CSV also appears under `TMD_Zenodo_v2_3_upload_bundle_plus_all_addons_v1_5/TMD_real_system_case_study_Pf_WS_v1_3/`; their byte hashes agree. A second location is an alias, not a second rate experiment.

The folder160 locked unit-test data repeat the same normalized WS rate vector across labels. Context labels do not turn one SBW25 rate estimate into independently measured context-specific q. Legacy triad counts include the duplicated 17/6/3 vector and the 2019 pathway-isolated 46/41/18 samples. The baseline audit already excludes both from forward cross-context replication claims as appropriate.

The baseline establishes that Lind's 2019 unselected mutant samples were obtained in separate pathway-isolated genetic backgrounds. The 46/41/18 sequenced sample sizes must not be converted into multinomial supply counts for competing routes. Normalizing pathway-specific fluctuation-assay rate estimates is a different operation from pooling sequenced isolates. A Dirichlet calibration likelihood applies only to genuine independent categorical calibration observations with a justified shared sampling denominator; it is not automatically appropriate for fluctuation-assay mutant colony counts, which require their own culture/growth model.

The 59/52 rpoB route counts are selected resistant endpoints. They can support descriptive prediction with experimental blocks restored, but cannot independently supply the unknown mutation baseline for the same selected outcomes. No context-specific unselected 16-route rpoB calibration counts were found.

## What would be new in the extension

Uncertain-q priors and Dirichlet-multinomial likelihoods already occur in local notes and code, including folders120/121, folder58's posterior summaries, and older release notes for overdispersion. Accordingly, introducing a Dirichlet prior or a concentration sensitivity sweep is not a new project concept or external mathematical novelty.

An explicit two-sample model would be a useful project extension: learn q from an independently sampled calibration dataset, retain its uncertainty when predicting separate selected outcomes, and compare the restricted TMD model with a mutation-only baseline using the same held-out information. It must distinguish baseline posterior uncertainty from between-culture overdispersion, and keep calibration data separate from outcome data. Any transformed-softmax likelihood or predictive integration should be verified against limiting cases and declared synthetic examples. Suitable mutation-rate estimates should instead propagate their assay-specific rate uncertainty.

Priorities are (1) build the independent-calibration data contract and likelihood while declaring current demonstrations synthetic; (2) obtain source-authenticated supply observations and rate uncertainties in the correct genetic background and conditions; (3) preserve experimental blocks and genuine independent holdouts; and (4) measure establishment or performance separately before interpreting residual parameters mechanistically. A single transported q vector cannot test the supply-adjusted WS invariant across independently calibrated contexts.

Other physics research can contribute general practices such as null-model comparison, provenance, identifiability checks, and held-out prediction. No observation here links a physics hypothesis to WS mutation mechanisms. Do not manufacture such a biological connection.
