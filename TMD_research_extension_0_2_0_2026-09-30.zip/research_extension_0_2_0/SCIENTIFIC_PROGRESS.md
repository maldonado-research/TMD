# Scientific progress: calibration, measurement and a new source audit

This research-methods update builds on the source-audited 0.1.0 release. It adds an independent-calibration likelihood, explicit observation-bias mathematics, and synthetic operating-characteristic checks. No new biological experiment or validated TMD mechanism is reported.

## Independent supply estimates now enter the likelihood

The WS model's context-shared quantity is the supply-adjusted contrast theta=vᵀ(log p−log q), v=(−1/2,1,−1/2). Rather than plug a fixed q into selected counts, the new implementation jointly models an independent calibration sample and the selected sample. A context-specific alternative is saturated; the regular dimension difference is C−1. A convex parameterization supplies stable fitting and analytic derivatives. Bootstrap simulations resample both samples.

This is an application of standard likelihood mathematics. Earlier local code already used Dirichlet concentration sensitivity for uncertain q. The advance is an explicitly data-informed observation model and auditable implementation, not the first uncertainty treatment or an external mathematical discovery.

All 16 inference tests and seven planning tests pass in the reviewed runtime. A synthetic unequal-supply fixture estimates theta=0.6020 against its generating value 0.6; its approximate 199-draw bootstrap p-value is 0.57. This is a software illustration, not biological evidence or proof of the model.

## Measurement can mimic a biological departure

If baseline and selected samples have route-specific recovery probabilities d0 and d1, the observed contrast is theta plus vᵀlog(d1/d0). Halving only Aws recovery in a selected sample multiplies the observed adjusted invariant J by 1/4. An unknown recovery contrast is confounded with the biological contrast. More endpoint counts do not resolve that equivalence by themselves.

In a generated four-context example, the underlying theta stayed at 0.4, but halved Aws recovery in two contexts changed their observed contrast to approximately −0.2931. The statistical test rejected the recorded shared-contrast model, with 199-bootstrap p=0.005. It did not identify a biological cause. This counterexample is a reason to measure recovery, not an empirical TMD falsification.

## Simulation checks have explicit limits

Each scenario used 40 generated datasets, four contexts, 600 independent calibration units and 600 independent selected units per context, and 99 bootstrap draws per dataset. At a 0.05 threshold:

| Generated scenario | Rejections | Proportion | Wilson 95% interval |
|---|---:|---:|---:|
| Shared-contrast null | 1/40 | 0.025 | 0.00443–0.12881 |
| Deliberately strong contrast departure | 40/40 | 1.000 | 0.91238–1.00000 |

All 7,920 bootstrap draws resolved in those two dense scenarios. The broad null interval does not establish universal 5% calibration. Rare routes, weak effects, assay dependence, and sparse boundaries need separate prospective operating-characteristic studies. The software preserves unresolved draws and returns computational bounds rather than conditioning on successful fits.

## Calibration changes precision and study allocation

For independent multinomial samples, the per-context contrast variance is approximately sum(v_i²/p_i)/n + sum(v_i²/q_i)/m. A balanced example with n=m=100 has standard error 0.30; falsely treating q as exact gives about 0.212. The full standard error is a factor sqrt(2), about 41%, larger than the fixed-q estimate. Equivalently, the fixed-q estimate is about 29% below the full value.

An equal-cost allocation under a fixed per-context budget minimizes this variance at n/m=sqrt(A_p/A_q). This is a planning result under stated assumptions, not a laboratory sample-size recommendation. Unknown probabilities, failed recruitment, unequal assay costs and dependent units can change it.

## New literature and source data

The targeted primary-source review identified recent mutation-bias/population-size experiments and cross-species WS prediction work. The important questions are which measurements those studies provide, which assumptions transport to our model, and which observations remain missing. See the literature and source-inspection reports for primary citations and admissibility details.

The public Barber and Couce 2026 source workbook contains 75 focal-genotype rows from selected longest-surviving lineages. We classify focal-locus observations into TEM-only, PBP3-only, both and neither, preserving stable group IDs. Of 50 delta-mutT isolates, the counts are 10, 28, 10 and 2; of 25 delta-mutH isolates, they are 12, 1, 11 and 1. These descriptions are conditional on the authors' selection rule. Neither means neither assayed focal locus, not no adaptation; both cannot be assigned a single route winner.

The extraction flags source-label, denominator and substitution-total discrepancies without silently repairing them. It preserves original labels and workbook counts, distinguishes likely intended labels from confirmed facts, and avoids interpreting pooled whole-genome variants as individual independent samples. This strengthens source handling; it does not overturn the paper or directly test the WS triad.

## The next decisive test

The missing input is still independently authenticated, context-matched biological calibration and selected observations with a justified sampling model. Freeze a meaningful contrast bound, route dictionary, measurement rule, recovery validation, held-out prediction and comparison models before data arrive. Include a mutation-only alternative and independently measured performance where available. Use the timing branch only for valid first-event records. Report unfavorable outcomes with the same visibility as favorable ones.
