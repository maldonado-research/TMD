# TMD research extension 0.2.0: independent calibration and observation-aware tests

**Ricardo Maldonado · exploratory methods update · 30 September 2026**

This update makes the WS mutation-supply-adjusted restriction testable with independent calibration counts and explicit measurement assumptions. It also inspects a newly reviewed 2026 source dataset without turning selected survivor genotypes into first-winner observations. No new laboratory experiment, biological confirmation of TMD, new fundamental physical law, or external mathematical priority is claimed.

## Read first

- [Scientific progress](SCIENTIFIC_PROGRESS.md) and [In More Basic Terms](IN_MORE_BASIC_TERMS.md).
- [Joint calibration mathematics](inference/MATHEMATICS_AND_INFERENCE.md): likelihood, convex fitting, boundaries and approximate bootstrap.
- [Measurement and design](design/MEASUREMENT_AND_DESIGN.md): recovery bias, calibration uncertainty and sample allocation.
- [Timing integration](inference/TIMING_INTEGRATION.md): the exact likelihood decomposition and its observation requirements.
- [Literature update](literature/LITERATURE_UPDATE.md) and [2026 source-data inspection](literature/BARBER_PROVENANCE.md).
- [Synthetic calibration](calibration/SYNTHETIC_CALIBRATION.md): selected simulation results and their limits.
- [Prospective decisions](PROSPECTIVE_DECISIONS.md): what can now be fixed before new observations arrive.

## Reproduce

Use Python 3.10 or later with NumPy installed. The planning calculation uses only the standard library. The optional original-workbook inspection also needs pandas and openpyxl; publisher files are downloaded separately and are not redistributed here. Exact tested runtime and package versions are recorded in VALIDATION.json.

From this directory:

```sh
python3 -m unittest discover -s inference -p 'test_joint_ws_inference.py' -v
python3 -m unittest discover -s design -p 'test_design_precision.py' -v
python3 inference/joint_ws_inference.py inference/fixtures/simulated_shared_theta.json --bootstrap 199 --seed 32 --output regenerated_fit.json
python3 design/design_precision.py
python3 calibration/calibrate_joint_ws.py
```

The calibration script writes generated results to its own directory. Use a separate copy if preserving an untouched release. Fixture and simulation counts are explicitly synthetic. Provenance declarations do not authenticate biological measurements.

## What the update adds

The selected-sample model and independently sampled baseline are fitted together. Both count samples are resampled in the parametric bootstrap. The code reports a finite fit only after geometry, optimization and information checks. Observed zeros are allowed; unsupported boundaries or failed fits decline inference. A single context cannot test cross-context constancy.

The baseline-count observation model must be biologically justified. Lind's 46/41/18 pathway-isolated sequencing totals, fluctuation-assay colony totals, pooled sequencing calls, and preferentially recovered survivors cannot simply be relabeled as independent multinomial supply samples. Legacy project code already treated q uncertainty through assumed Dirichlet concentration. This extension adds an explicit independent calibration-count likelihood rather than claiming uncertainty was previously unknown.

In matched samples, the supply-adjusted log contrast has approximate variance A_p/n+A_q/m. Differential route recovery adds its own log contrast exactly. More endpoint observations alone cannot identify an unknown recovery bias.

## Versions and reuse

This methods package is **0.2.0**. The earlier source-audited report remains [research extension 0.1.0](https://zenodo.org/records/23068056); historical [software v2.6.5](https://zenodo.org/records/22398093) is a separate archive. Neither DOI identifies this 0.2.0 update. Original files and published archives are preserved.

New code: MIT, see LICENSE. New writing: CC BY 4.0, see LICENSING.md. Primary publications and datasets retain their original rights; factual derived counts preserve attribution and are not newly collected project data. No original publisher workbook, article prose, or figure is redistributed. This work used AI assistance under Ricardo's direction. Neither EDISON nor MOSBRI funded this work.
