# Reuse and source rights

New analysis software is MIT licensed (LICENSE). New explanatory writing is CC BY 4.0: https://creativecommons.org/licenses/by/4.0/. Author: Ricardo Maldonado, with AI-assisted analysis.

Primary publications, publisher workbooks, figures and third-party datasets retain their own licenses and attribution. No source workbook or publication figure is included. The small CSV and JSON factual summaries preserve their primary source citation, cell mapping, hashes and unresolved discrepancies. No claim is made to new biological data ownership.
