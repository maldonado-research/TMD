# In More Basic Terms: count what appears, then ask what succeeds

Imagine three routes to a useful new trait. One route shows up often, another shows up rarely. A route that appears more often may be recovered more often even if it has no special advantage after it appears.

To test TMD fairly, we need two kinds of information. First, measure how often each route appears in an appropriate separate sample. Then measure the routes recovered under the selected condition. Each sample carries uncertainty. The new analysis includes both instead of treating the first measurement as perfect.

There is another problem: our counting method can favor a route. Suppose it misses half the colonies of one kind. That alone changes the comparison. A statistical test can detect the change, but it cannot tell whether biology or the assay caused it without additional measurements.

The latest literature review gives a concrete example of why this matters. A 2026 evolution study selected genotypes from its longest-surviving lineages. Those genotypes help describe that selected collection. They cannot tell us which route first won in every population that started the experiment. We have saved an attributed summary with the sampling limits clearly visible.

The calculations and computer-generated examples in this update help us design a stronger real test. They are not new biological experiments. The important next step is an independent, matched set of observations, with the analysis fixed before we see its outcomes. A prediction that survives that test would carry more weight than another fit to an old collection.
