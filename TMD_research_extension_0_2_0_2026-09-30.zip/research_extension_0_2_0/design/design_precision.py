"""Synthetic planning calculations for the WS supply-adjusted log contrast.

Standard-library only. These are asymptotic forecasts, not biological data
or a replacement for finite-sample simulation of the actual analysis.
Route order is Wsp, Aws, Mws throughout.
"""
import json
import math
from pathlib import Path
from statistics import NormalDist

V = (-0.5, 1.0, -0.5)
NORMAL = NormalDist()


def probabilities(values):
    p = tuple(float(x) for x in values)
    if len(p) != 3 or any(not math.isfinite(x) or x <= 0 for x in p):
        raise ValueError('Three finite, strictly positive probabilities required')
    if not math.isclose(sum(p), 1.0, rel_tol=0, abs_tol=1e-10):
        raise ValueError('Probabilities must sum to one')
    return p


def selected_probabilities(q, theta, eta):
    q = probabilities(q)
    if not all(math.isfinite(x) for x in (theta, eta)):
        raise ValueError('Finite model parameters required')
    logw = (math.log(q[0]) + eta, math.log(q[1]) + theta,
            math.log(q[2]) - eta)
    peak = max(logw)
    w = tuple(math.exp(x - peak) for x in logw)
    return tuple(x / sum(w) for x in w)


def log_contrast(p, q):
    p, q = probabilities(p), probabilities(q)
    return sum(v * (math.log(a) - math.log(b)) for v, a, b in zip(V, p, q))


def coefficient(p):
    return sum(v * v / x for v, x in zip(V, probabilities(p)))


def variance(p, q, selected_n, calibration_m):
    if any(not math.isfinite(x) or x <= 0 for x in (selected_n, calibration_m)):
        raise ValueError('Both independent sample sizes must be positive')
    return coefficient(p) / selected_n + coefficient(q) / calibration_m


def optimal_allocation(p, q, budget):
    if not isinstance(budget, int) or budget < 2:
        raise ValueError('An integer budget of at least two is required')
    ap, aq = coefficient(p), coefficient(q)
    continuous_n = budget * math.sqrt(ap) / (math.sqrt(ap) + math.sqrt(aq))
    candidates = {max(1, min(budget - 1, int(continuous_n))),
                  max(1, min(budget - 1, math.ceil(continuous_n)))}
    n = min(candidates, key=lambda x: ap / x + aq / (budget - x))
    m = budget - n
    return {'selected_n': n, 'calibration_m': m,
            'selected_to_calibration_continuous_ratio': math.sqrt(ap / aq),
            'contrast_variance': ap / n + aq / m,
            'minimum_expected_selected_route_count': min(p) * n,
            'minimum_expected_calibration_route_count': min(q) * m,
            'sparse_warning': min(min(p) * n, min(q) * m) < 5}


def normal_two_sided_power(delta, standard_error, alpha=0.05):
    if not all(math.isfinite(x) for x in (delta, standard_error, alpha)) or standard_error <= 0 or not 0 < alpha < 1:
        raise ValueError('Positive standard error and valid alpha required')
    z = NORMAL.inv_cdf(1 - alpha / 2)
    effect = abs(delta) / standard_error
    return 1 - NORMAL.cdf(z - effect) + NORMAL.cdf(-z - effect)


def ascertainment_shift(selected_recovery, baseline_recovery):
    if len(selected_recovery) != 3 or len(baseline_recovery) != 3:
        raise ValueError('Exactly three recovery probabilities are required')
    d1, d0 = tuple(selected_recovery), tuple(baseline_recovery)
    if any(not math.isfinite(x) or not 0 < x <= 1 for x in d1 + d0):
        raise ValueError('Recovery probabilities must lie in (0,1]')
    return sum(v * math.log(a / b) for v, a, b in zip(V, d1, d0))


def generate():
    contexts = [('balanced', (1/3, 1/3, 1/3), 0.4, -0.2),
                ('mws_rare', (0.45, 0.45, 0.10), 0.4, -0.2),
                ('aws_rare', (0.475, 0.05, 0.475), 0.4, -0.2)]
    scenarios = []
    for name, q, theta, eta in contexts:
        p = selected_probabilities(q, theta, eta)
        for budget in (200, 600, 2000):
            optimal = optimal_allocation(p, q, budget)
            n, m = optimal['selected_n'], optimal['calibration_m']
            se = math.sqrt(variance(p, q, n, m))
            naive_se = math.sqrt(coefficient(p) / n)
            alternative_p = selected_probabilities(q, theta + 0.5, eta)
            difference_se = math.sqrt(variance(p, q, n, m) + variance(alternative_p, q, n, m))
            scenarios.append({'context': name, 'baseline_q': q, 'selected_p': p,
                              'theta': theta, 'eta': eta, 'total_budget': budget,
                              'budget_scope': 'per_context; two-context comparison requires twice this budget',
                              'optimal_allocation': optimal,
                              'joint_standard_error': se,
                              'fixed_q_standard_error_at_same_selected_n': naive_se,
                              'standard_error_understatement_factor': se / naive_se,
                              'second_context_theta': theta + 0.5,
                              'second_context_selected_p': alternative_p,
                              'second_context_uses_same_n_and_m': True,
                              'two_context_difference_standard_error': difference_se,
                              'two_context_difference_power_for_delta_0_5':
                                  normal_two_sided_power(0.5, difference_se),
                              'forecast_only': True})
    bias = ascertainment_shift((1.0, 0.5, 1.0), (1.0, 1.0, 1.0))
    return {'provenance': 'synthetic_design_forecast',
            'route_order': ['Wsp', 'Aws', 'Mws'],
            'assumptions': ['independent multinomial baseline and selected samples',
                            'strictly positive interior probabilities',
                            'matched biological context and route definitions',
                            'no unmodeled clusters or differential ascertainment',
                            'normal approximation; confirm with finite-sample simulations'],
            'scenarios': scenarios,
            'recovery_bias_example': {'selected_recovery': [1, 0.5, 1],
                                     'baseline_recovery': [1, 1, 1],
                                     'log_contrast_shift': bias,
                                     'adjusted_J_multiplier': math.exp(2 * bias)}}


if __name__ == '__main__':
    out = Path(__file__).with_name('design_precision_results.json')
    out.write_text(json.dumps(generate(), indent=2) + '\n')
    print(out)
