# Measure the routes before interpreting their contrast

This extension applies standard multinomial and delta-method mathematics to the TMD WS restriction. Its equations are derived here for review; external mathematical novelty is not claimed. All numerical design examples are synthetic forecasts. No new laboratory observations were collected.

## The quantity being tested

Use route order Wsp, Aws, Mws. For strictly positive route probabilities, let

\[
v=(-1/2,1,-1/2),\qquad
\theta_c=v^\top(\log p_c-\log q_c),\qquad J_c=e^{2\theta_c}.
\]

Here q is context-matched mutation supply and p is the selected route distribution for the specified observation rule. Under the WS model p is proportional to q times exp(theta times the Aws indicator plus eta times (1,0,-1)). Taking the contrast cancels both normalization and eta, leaving theta exactly. The cross-context restriction is shared theta; it is not constancy of the raw selected ratio p_A²/(p_W p_M).

The new joint likelihood in [MATHEMATICS_AND_INFERENCE.md](../inference/MATHEMATICS_AND_INFERENCE.md) fits q and the shared contrast simultaneously from independent calibration and selected samples. Its data contract requires categorical route samples with a justified multinomial observation model. Colony totals from fluctuation cultures, pathway-isolated strain collections, pooled genomes, or preferentially chosen survivors do not automatically satisfy that contract.

## An exact observation-bias identity

Suppose a baseline sample recovers a route with probability d0_i and a selected sample with probability d1_i. Within each assay, the observed distributions are

\[
\widetilde q_i=\frac{q_i d0_i}{\sum_j q_j d0_j},\qquad
\widetilde p_i=\frac{p_i d1_i}{\sum_j p_j d1_j}.
\]

Because the entries of v sum to zero, both normalizers cancel:

\[
\widetilde\theta_c=\theta_c+
v^\top\log(d1_c/d0_c).
\tag{1}
\]

This identity concerns multiplicative recovery probabilities, not every possible ascertainment process. If relative recovery differs across contexts, a constant biological theta can produce differing observed contrasts. Halving only Aws recovery in the selected sample shifts theta by −log(2) and multiplies observed J by 1/4, even though biology is unchanged. A common scalar change in recovery cancels. A fixed route-specific recovery ratio across all contexts shifts every theta equally and preserves cross-context constancy, but changes its mechanistic interpretation.

If d0 and d1 are known, equation (1) supplies a correction. If they are estimated, their uncertainty must also be propagated. This release does not estimate or fit unknown recovery efficiencies. An arbitrary unknown differential recovery contrast is exactly confounded with the biological contrast: additional endpoint counts alone cannot resolve it.

The practical requirement is to validate route recovery, retain all eligible units and exclusions, and match biological backgrounds and contexts. Use a common, justified triad conditioning rule where other routes exist. Statistical rejection then concerns the recorded sampling model; it must not be promoted directly to a claim about biological mechanism.

## Why calibration uncertainty changes the required sample size

Suppose n selected units and m independent baseline units are sampled multinomially. Interior multinomial proportions have asymptotic covariance (diag(p)−ppᵀ)/n. Applying the gradient v_i/p_i and using sum(v)=0 gives

\[
\operatorname{Var}(\widehat\theta_c)\simeq
\frac{A_p}{n}+\frac{A_q}{m},\qquad
A_p=\sum_i\frac{v_i^2}{p_i},\quad A_q=\sum_i\frac{v_i^2}{q_i}.
\tag{2}
\]

The covariance between baseline and selected estimates is zero only under the assumed independent sampling. Paired or clustered cultures require a different covariance model. Zero observed counts cannot be inserted into log ratios; use a suitable likelihood and evaluate its boundaries. Equation (2) is an asymptotic planning approximation, not a finite-sample confidence interval.

For a fixed per-context budget B=n+m and equal cost per usable observation, differentiating A_p/n+A_q/(B−n) gives

\[
\frac{n}{m}=\sqrt{A_p/A_q},\qquad
\min\operatorname{Var}(\widehat\theta_c)\simeq
\frac{(\sqrt{A_p}+\sqrt{A_q})^2}{B}.
\tag{3}
\]

The implementation checks the two neighboring integer allocations. Different costs, assay failures, unequal recruitment yields, shared controls, or block effects change the optimum. This is not a prescription for a laboratory sample size without those inputs.

For uniform p=q=(1/3,1/3,1/3), A_p=A_q=4.5. With n=m=100, variance is 0.09 and standard error 0.30. Treating q as known would report standard error sqrt(0.045), about 0.212. The uncertainty is larger by sqrt(2). The precision loss is caused by finite calibration, not evidence against TMD.

## Forecasts and their limits

[design_precision_results.json](design_precision_results.json) evaluates balanced supply and rare-route examples at budgets of 200, 600 and 2,000 observations **per context**. Two-context comparisons require twice that total. The first context uses theta=0.4 and eta=−0.2; the second uses theta=0.9, with its own resulting selected probabilities and variance. The nominal contrast difference is 0.5. Reported power uses an independent two-context normal approximation with both variances, not the joint multi-context bootstrap test. These are different analyses.

The expected-count threshold of five is only a warning heuristic. Exceeding it does not establish valid asymptotic calibration. Before fixing a real study, simulate the actual finite-sample test over plausible probabilities, effect bounds, recovery uncertainty, censoring if relevant, and culture/block dependence. Choosing probabilities after seeing the outcomes would defeat the prospective purpose.

## In More Basic Terms

Imagine counting three kinds of successful mutations. Before asking which kind gets an advantage, we need a separate estimate of how often each kind appears. That estimate is uncertain too. Ignoring its uncertainty can make an ordinary fluctuation look more convincing than it is.

We also need to check our counting method. If the assay misses half the colonies from one route, the results can look different even when the underlying biology has not changed. The useful advance is a test that accounts for the first problem and states exactly what measurements are needed to address the second.
