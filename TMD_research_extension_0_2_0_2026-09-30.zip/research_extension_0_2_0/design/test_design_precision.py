import math
import unittest
from design_precision import (ascertainment_shift, coefficient, log_contrast,
                              normal_two_sided_power, optimal_allocation,
                              selected_probabilities, variance)


class DesignPrecisionTests(unittest.TestCase):
    def test_recovers_shared_contrast_with_different_supply(self):
        for q in [(0.25, 0.5, 0.25), (0.4, 0.2, 0.4), (0.6, 0.3, 0.1)]:
            for theta, eta in [(0, 0), (0.4, -0.7), (-0.9, 1.2)]:
                self.assertAlmostEqual(log_contrast(selected_probabilities(q, theta, eta), q), theta)

    def test_uniform_exact_variance(self):
        q = (1/3, 1/3, 1/3)
        self.assertAlmostEqual(coefficient(q), 4.5)
        self.assertAlmostEqual(variance(q, q, 100, 100), 0.09)

    def test_allocation_is_discrete_global_minimum(self):
        q = (0.475, 0.05, 0.475)
        p = selected_probabilities(q, 0.4, -0.2)
        result = optimal_allocation(p, q, 200)
        exhaustive = min(variance(p, q, n, 200 - n) for n in range(1, 200))
        self.assertAlmostEqual(result['contrast_variance'], exhaustive)

    def test_common_detection_change_cancels(self):
        self.assertAlmostEqual(ascertainment_shift((0.3, 0.3, 0.3), (0.6, 0.6, 0.6)), 0)

    def test_route_specific_detection_exact_shift(self):
        self.assertAlmostEqual(ascertainment_shift((1, 0.5, 1), (1, 1, 1)), -math.log(2))
        self.assertAlmostEqual(math.exp(2*ascertainment_shift((1, 0.5, 1), (1, 1, 1))), 0.25)

    def test_power_under_null_and_monotonicity(self):
        self.assertAlmostEqual(normal_two_sided_power(0, 0.1), 0.05)
        self.assertGreater(normal_two_sided_power(0.5, 0.1), normal_two_sided_power(0.5, 0.5))

    def test_invalid_inputs_rejected(self):
        for q in [(0, 0.5, 0.5), (0.2, 0.2, 0.2), (float('nan'), 0.5, 0.5)]:
            with self.assertRaises(ValueError): coefficient(q)
        with self.assertRaises(ValueError): variance((1/3,)*3, (1/3,)*3, 0, 100)
        with self.assertRaises(ValueError): variance((1/3,)*3, (1/3,)*3, float('nan'), 100)
        with self.assertRaises(ValueError): normal_two_sided_power(float('nan'), 0.1)
        with self.assertRaises(ValueError): normal_two_sided_power(0.5, float('inf'))
        with self.assertRaises(ValueError): ascertainment_shift((1, 0, 1), (1, 1, 1))


if __name__ == '__main__': unittest.main()
