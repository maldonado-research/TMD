# Combining the timing diagnostic with uncertain supply

The earlier 0.1.0 timing analysis and this endpoint calibration model test different restrictions. They can be combined only when the selected counts are aggregates of the same eligible, correctly observed first-event records and the independent baseline calibration sample has an appropriate observation model. Endpoint survivor samples without event times cannot supply the timing component.

With independent censoring and the earlier piecewise clock specification, the likelihood factorizes into clock terms, time-bin route terms, and the additional calibration term sum(m_ci log q_ci). Compare three nested models on exactly the same event records and baseline observations:

1. **Free:** route fractions vary by context and bin; calibration q is free by context.
2. **Common clock:** route fractions are constant across bins within each context; p and calibration q are otherwise free by context.
3. **Joint WS:** route fractions are constant across bins and p is related to q by the shared WS contrast, with q fitted jointly from independent calibration and selected samples.

Let their maximized joint log likelihoods be ell_free, ell_common and ell_WS. All models fit the same piecewise total event clock. The common and free models also maximize the same unconstrained calibration likelihood, which cancels from their difference. Therefore

\[
2(\ell_{free}-\ell_{WS})=
D_{time}+D_{joint,WS},
\]

where D_time is the original route–time deviance and D_joint,WS is the new joint two-sample deviance. This is exact likelihood bookkeeping when the required fits exist, not a claim of independent biological confirmations. The components reuse selected observations.

The second term includes calibration as well as selected-sample likelihood contributions. It is **not** the old selected-only expression evaluated at an uncertain-q fit. Conversely, the earlier fixed-q expression remains valid in its stated fixed-q model; this document does not retroactively change the published 0.1.0 report.

An observed boundary fit or unresolved fit cannot be inserted as a valid deviance. This release documents the extension but does not provide a jointly calibrated omnibus timing-plus-WS p-value. Such a test would need a prespecified simulation model for event times, censoring, independent calibration and any dependence, rather than treating two computed p-values as independent.
