# Independent calibration-count joint WS inference, prototype 0.2.0

This extension implements a standard exponential-family joint likelihood for independently observed calibration and selected-route counts. It is a statistical/software extension of the existing baseline-adjusted WS proposal, not a claim of new mathematical theory, new biological observations, or a novel mechanism. Every checked-in fixture is explicitly synthetic. The earlier `tmd_evidence_vs_null_v0_2_uncertainq.py` already explored q uncertainty with Dirichlet concentration sensitivity. The present method differs by using an explicit, independent empirical calibration sample and its multinomial sampling likelihood; it is not the first q-uncertainty method in this project.

## Data and observation contract

For each prespecified context c, observe independent samples

\[
m_c\sim\operatorname{Multinomial}(M_c,q_c),\qquad
n_c\sim\operatorname{Multinomial}(N_c,p_c).
\]

Routes are ordered W,A,M. All population calibration probabilities are assumed strictly positive. An observed zero calibration count is permitted and does not establish a population zero. Population support restrictions require another model. Counts must be nonnegative integers, with an identified sample denominator and M_c,N_c>0 for each analyzed context. A zero sample total is reported as `not_evaluable`, rather than silently discarding a context and changing the hypothesis.

Calibration and selection must use independent units, a common genetic background, and context-matched route definitions. The triad must be exhaustive or the sampling must explicitly condition both observations on a triad outcome. Other outcomes may not be quietly dropped from an exhaustive likelihood. Contexts and route classes must be frozen before examining outcomes. Unmodeled clusters, shared replicates or pooled mutation-rate measurements invalidate this simple independent-sample likelihood.

The CLI requires declarations of independence, context matching, common background, validated matched-route multinomial calibration, and exhaustive/conditioned triad sampling. These declarations do not authenticate the experiment. Pathway-isolated strain mutant totals, heterogeneous reporter/deletion summaries, and rates in incompatible units are not automatically probability-calibration counts; the CLI rejects a calibration design labeled `pathway_isolated_mutant_totals`. The prospective biological design previously proposed at least four distinct conditions. The mathematical diagnostic works for C>=2; C=1 has no cross-context restriction and is not a WS constancy test.

## Joint likelihood and the shared contrast

With s=(1,0,-1), A-indicator (0,1,0), set

\[
p_{ci}=\frac{q_{ci}\exp(\theta_1 1_{i=A}+\theta_{2,c}s_i)}
{\sum_jq_{cj}\exp(\theta_1 1_{j=A}+\theta_{2,c}s_j)}.
\]

Ignoring parameter-independent multinomial coefficients, the joint log likelihood is

\[
\ell(q,\theta)=\sum_{c,i}m_{ci}\log q_{ci}
+\sum_{c,i}n_{ci}\log p_{ci}.
\]

Zero counts contribute zero, including in the saturated alternative; no pseudocount enters this expression. q is estimated jointly from both likelihood factors under the restriction, which propagates calibration sampling uncertainty. The selection likelihood alone cannot calibrate q and supply an independent falsifier: free q can absorb all selected probabilities.

For positive p,q define v=(-1/2,1,-1/2). Then

\[
\theta_{1,c}=\sum_i v_i\log(p_{ci}/q_{ci}),\qquad
\theta_{2,c}=\tfrac12\log\frac{p_{cW}q_{cM}}{p_{cM}q_{cW}}.
\]

The null is shared theta1 across contexts. Its equivalent adjusted invariant is

\[
J_c=\frac{p_{cA}^2q_{cW}q_{cM}}
{p_{cW}p_{cM}q_{cA}^2}=e^{2\theta_1}.
\]

Raw p_A²/(p_W p_M) changes when q changes, even under this null.

## Convex fitting rather than an unconstrained nonlinear search

Use baseline reference-category log odds a_c=log(q_W/q_M), b_c=log(q_A/q_M), and selected u_c=log(p_W/p_M). For a shared t=theta1,

\[
q_c=\operatorname{softmax}(a_c,b_c,0),\qquad
p_c=\operatorname{softmax}(u_c,b_c-a_c/2+u_c/2+t,0).
\]

These logits are linear in beta=(a_1,b_1,u_1,...,a_C,b_C,u_C,t). The negative log likelihood is a sum of convex log-sum-exp terms. If X_g contains the three logit design rows for sample g, y_g its counts, T_g its total and r_g its fitted probabilities,

\[
\nabla L=\sum_g X_g^T(T_gr_g-y_g),\qquad
\nabla^2 L=\sum_gT_gX_g^T[\operatorname{diag}(r_g)-r_gr_g^T]X_g.
\]

The code uses stabilized log-softmax, analytic score/Hessian, damped Newton steps with line search, and agreement between an empirical starting point and zero starting point. A +0.5 appears only in initial log odds; it never enters the objective or output counts. Every accepted fit reports convergence, maximum score residual, smallest Hessian eigenvalue and the information condition number. Information that is not positive definite, has condition number above 10^14, or gives an invalid shared-tilt variance returns `information_unresolved` with no estimates or inference. Convexity supplies a global-optimum argument once a finite fit and numerical convergence are established. Failed convergence is `optimizer_unresolved`, not an inferential result. This numpy-only dense implementation is intended for a modest number of contexts.

## Alternative, deviance and regular degrees of freedom

Let theta1 vary with context. For positive q,p, the two contrasts above reconstruct every interior p exactly, so this alternative equals independently saturated calibration and selected multinomials. Its likelihood supremum, including observed zero cells, is

\[
\ell_{alt}=\sum_{c,i:m_{ci}>0}m_{ci}\log(m_{ci}/M_c)
+\sum_{c,i:n_{ci}>0}n_{ci}\log(n_{ci}/N_c).
\]

The likelihood-ratio statistic is D=2(ell_alt-ell_null). Null dimension is 2C baseline logits + C slopes + 1 shared contrast =3C+1. Alternative dimension is 4C. Thus the regular difference is **C-1**. Under interior true probabilities, independent sampling, identifiable finite parameters and adequate growing sample sizes, the conventional Wilks limit is chi-square(C-1). C=1 is saturated: theta1 is descriptively identifiable with calibration, but its cross-context constancy is untestable. The software reports df=0 and `not_evaluable` for the test.

No chi-square p-value is emitted, particularly for sparse data. `sparse` flags any observed zero or fitted expected cell below five; five is a descriptive warning threshold, not a validity theorem.

## Zero counts and boundary certificates

Observed zeros do not automatically make the joint null estimate infinite. For example, one selected sample containing W and A but no M can still have a finite null estimate because the other context constrains the shared tilt. Conversely, a selected sample containing only W permits a diverging context slope and has no finite interior MLE.

The code checks recession geometry before optimization. For a candidate direction d, observed categories in every sample must tie for its largest logit score. Let E d=0 encode observed-score ties and G d>=0 the gaps between an observed anchor and every zero-count category. A nonzero gap in a feasible direction increases likelihood toward a boundary at infinite parameter values. Project G into null(E). An active-set nonnegative least-squares certificate checks whether -sum(G_rows) belongs to the cone generated by those rows. If it does, all feasible gaps must vanish. Otherwise the least-squares residual supplies a checked separating direction. The numerical witness and minimum gap are recorded.

Boundary and geometry failures return no finite tilt estimates, no exact null deviance and no p-value. They do not fit an arbitrary finite parameter box, add tiny probabilities, or reinterpret a zero empirical route as a biological zero. An extended-MLE optimizer on boundary faces is a possible later enhancement. Missing calibration samples and rank deficiencies are explicitly flagged rather than repaired by priors.

## Uncertainty and joint parametric bootstrap

An interior fit reports the shared tilt's standard error from inverse joint observed information, labeled `theta1_standard_error_regular`. This includes the calibration parameter block and is a regular asymptotic quantity. It is not a calibrated sparse-sample interval.

For an independent per-context contrast, the delta-method variance at positive probabilities is

\[
V_c=\frac{1}{N_c}\sum_i\frac{v_i^2}{p_{ci}}
+\frac{1}{M_c}\sum_i\frac{v_i^2}{q_{ci}}.
\]

The terms -1 from multinomial covariance vanish because sum(v)=0. Under the shared model, the first-order efficient variance is [sum_c(1/V_c)]^-1. An exact-model fixture verifies the joint information result against this separate derivation and shows that increasing calibration effort reduces uncertainty. Treating q as exact discards the second term.

`bootstrap_lrt` fits the shared null, preserves each observed M_c,N_c, and independently resamples **both** baseline and selected counts from fitted q_c,p_c. It refits the null in every replicate and uses the saturated alternative. A fixed seed, replicate count, comparison tolerance and all resolved statistics are recorded. When every replicate is resolved,

\[
\widehat p_{MC}=\frac{1+\#(D_b\ge D_{obs})}{B+1}.
\]

This is an estimated-null parametric bootstrap for a composite null, not an exact finite-sample randomization test. The +1 convention and finite Monte Carlo resolution do not make model estimation or sparse-sample calibration exact. Near boundaries, substantial caution is needed; this tool never substitutes an arbitrary asymptotic p-value.

A bootstrap draw can itself have a boundary or numerical failure. Those draws are **not discarded and replaced**, which would condition on successful fitting. If U draws are unresolved, the tool emits no single p-value and returns computational bounds

\[
[(1+E)/(B+1),(1+E+U)/(B+1)],
\]

where E counts resolved exceedances. These bounds classify unresolved draws in both possible ways. They are not confidence intervals for the population p-value or a guarantee of correct test size. An observed boundary fit has no bootstrap p-value at all. Nonrejection means no detected cross-context departure at this precision, not model proof or biological validation.

## Use and verification

Requires Python 3.10+ and numpy. From this directory:

```sh
python3 joint_ws_inference.py fixtures/noiseless_shared_theta.json --bootstrap 199 --seed 20260930 --output noiseless_result.json
python3 -m unittest discover -s . -p 'test_joint_ws_inference.py' -v
```

The checked-in runs use the bundled Python identified by the app dependency tool; scipy is not required or installed. JSON schema version is 0.2.0, with input hash and explicit provenance. `fixtures/simulated_shared_theta.json` records four contexts generated with unequal q, shared theta1=.6, 10,000 observations in each arm and seed 7001. Its joint bootstrap run (199 draws, seed 32) fits theta1=.602015, D=1.874685 and approximate p=.57. These numbers illustrate a particular synthetic draw, not empirical evidence or a power guarantee. API users must independently satisfy the same scientific observation contract; direct numeric-array functions cannot validate sample provenance.

Tests cover exact noiseless algebra with unequal q and shared theta, analytic score/Hessian against independent finite differences, the regular-information uncertainty identity, finite and infinite zero-count cases, zero sample totals, C=1, extreme log-sum-exp, synthetic unequal-q multinomial draws, a known contrast departure, rejected unsupported calibration design, invalid counts, bootstrap reproducibility and unresolved-bootstrap accounting. The fixed synthetic draws illustrate selected scenarios only; they do not establish nominal test size, power, experiment sample size or biological transportability. Further finite-sample operating-characteristic studies are needed before a prospective analysis is locked.

Selection/ascertainment can bias calibration and selection differently. If observed proportions are proportional to d_ci times underlying probabilities, the contrast shifts by v·log(d_selected/d_baseline). Joint multinomial uncertainty cannot correct an unmeasured route-specific recovery bias, dependent cultures, mismatch of genetic background, or invalid mutation-probability calibration.
