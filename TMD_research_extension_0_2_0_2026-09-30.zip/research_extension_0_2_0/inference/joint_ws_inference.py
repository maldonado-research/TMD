#!/usr/bin/env python3
"""Joint WS multinomial inference; routes ordered W, A, M. Requires numpy only.

Every fixture shipped here is synthetic. Estimates describe a statistical restriction,
not biological validation. No pseudocounts enter the likelihood.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np

ROUTES = ('W', 'A', 'M')


def validate_document(doc):
    if not isinstance(doc, dict):
        raise ValueError('Input must be a JSON object')
    meta = doc.get('metadata', {})
    if not isinstance(meta, dict):
        raise ValueError('Metadata must be an object')
    required = ('independent_calibration_and_selection', 'independent_replicates',
                'common_genetic_background', 'context_matched_calibration')
    for key in required:
        if meta.get(key) is not True:
            raise ValueError(f'metadata.{key} must explicitly be true')
    if meta.get('calibration_design') != 'matched_route_multinomial':
        raise ValueError('Calibration must be a validated matched route multinomial; '
                         'pathway-isolated strain mutant totals are unsupported')
    if meta.get('calibration_validation') != 'validated_for_route_probability':
        raise ValueError('Explicit calibration validation for route probabilities is required')
    if meta.get('triad_sampling') not in ('exhaustive_triad', 'conditioned_on_triad'):
        raise ValueError('Declare exhaustive_triad or conditioned_on_triad sampling')
    if meta.get('provenance') not in ('synthetic', 'observed', 'literature_transcription'):
        raise ValueError('Explicit provenance required')
    if doc.get('route_order') != list(ROUTES):
        raise ValueError('route_order must be [W,A,M]')
    contexts = doc.get('contexts', [])
    if not isinstance(contexts, list) or not contexts:
        raise ValueError('At least one context required')
    if any(not isinstance(c, dict) for c in contexts):
        raise ValueError('Every context must be an object')
    names = [c.get('context') for c in contexts]
    if any(not isinstance(n, str) or not n for n in names) or len(set(names)) != len(names):
        raise ValueError('Context names must be nonempty and unique')
    m = [c.get('baseline_counts') for c in contexts]
    n = [c.get('selected_counts') for c in contexts]
    validate_counts(m, n)
    return names, np.asarray(m, dtype=float), np.asarray(n, dtype=float)


def validate_counts(m, n):
    for counts in (m, n):
        a = np.asarray(counts)
        if a.ndim != 2 or a.shape[1] != 3:
            raise ValueError('Counts must have shape (contexts,3)')
        if any(isinstance(item, (bool, np.bool_))
               for row in counts for item in row):
            raise ValueError('Boolean values are not counts')
        if a.dtype.kind not in 'iuf' or not np.all(np.isfinite(a)):
            raise ValueError('Counts must be finite numeric integers')
        if np.any(a < 0) or np.any(a != np.floor(a)) or np.any(a > 2**52):
            raise ValueError('Counts must be nonnegative exactly representable integers')
        if np.any(a.sum(axis=1) > 2**52):
            raise ValueError('Sample totals must be exactly representable integers')
    if np.shape(m) != np.shape(n) or len(m) == 0:
        raise ValueError('Baseline and selected contexts must match')


def design(c):
    """q logits (a,b,0); p logits (u,b-a/2+u/2+theta,0)."""
    d = 3*c + 1
    x = np.zeros((2*c, 3, d))
    for j in range(c):
        a,b,u = 3*j,3*j+1,3*j+2
        x[2*j,0,a] = x[2*j,1,b] = 1
        x[2*j+1,0,u] = 1
        x[2*j+1,1,[a,b,u,d-1]] = [-.5,1,.5,1]
    return x


def log_softmax(v):
    z = v - np.max(v, axis=-1, keepdims=True)
    return z - np.log(np.sum(np.exp(z), axis=-1, keepdims=True))


def objective(beta, x, y):
    lp = log_softmax(x @ beta)
    p = np.exp(lp)
    total = y.sum(axis=1)
    loss = -float(np.sum(y*lp))
    grad = np.einsum('gkd,gk->d', x, total[:,None]*p-y)
    mean = np.einsum('gk,gkd->gd', p, x)
    hess = (np.einsum('g,gk,gkd,gke->de', total,p,x,x)
            - np.einsum('g,gd,ge->de', total,mean,mean))
    return loss, grad, hess


def nnls(a, b, tol=1e-11):
    """Small Lawson-Hanson active-set NNLS used only for recession detection."""
    k = a.shape[1]
    z = np.zeros(k)
    active = np.zeros(k, dtype=bool)
    for _ in range(max(50,30*k*k)):
        w = a.T @ (b-a@z)
        candidates = np.where(~active & (w > tol))[0]
        if not len(candidates):
            return z, True
        active[candidates[np.argmax(w[candidates])]] = True
        for _ in range(max(20,5*k)):
            trial = np.zeros(k)
            trial[active] = np.linalg.lstsq(a[:,active], b, rcond=None)[0]
            if np.all(trial[active] > tol):
                z = trial
                break
            bad = active & (trial <= tol)
            ratios = z[bad] / (z[bad]-trial[bad] + 1e-300)
            alpha = max(0., min(1., float(np.min(ratios))))
            z += alpha*(trial-z)
            active[(z <= tol) & active] = False
            z[z <= tol] = 0
        else:
            return z, False
    return z, False


def geometry(x, y):
    # Every observed category must tie for the largest recession score.
    equal, gaps, all_diffs = [], [], []
    for xx, yy in zip(x,y):
        observed = np.flatnonzero(yy > 0)
        if not len(observed):
            return {'status':'not_evaluable', 'reason':'zero sample total'}
        anchor = xx[observed[0]]
        all_diffs.extend(xx[i]-xx[2] for i in (0,1))
        equal.extend(xx[i]-anchor for i in observed[1:])
        gaps.extend(anchor-xx[i] for i in np.flatnonzero(yy == 0))
    rank = int(np.linalg.matrix_rank(np.asarray(all_diffs)))
    if rank < x.shape[-1]:
        return {'status':'nonidentifiable', 'design_rank':rank}
    if not gaps:
        return {'status':'interior', 'design_rank':rank}
    e = np.asarray(equal).reshape(-1,x.shape[-1])
    if len(e):
        _, singular, vh = np.linalg.svd(e, full_matrices=True)
        erank = int(np.sum(singular > max(e.shape)*np.finfo(float).eps*singular[0]))
        null = vh[erank:].T
    else:
        null = np.eye(x.shape[-1])
    g = np.asarray(gaps) @ null
    if not g.size or np.linalg.norm(g) < 1e-10:
        return {'status':'interior', 'design_rank':rank, 'zero_cells':len(gaps)}
    target = -g.sum(axis=0)
    weights, ok = nnls(g.T,target)
    residual = target-g.T@weights
    error = float(np.linalg.norm(residual))
    if not ok:
        return {'status':'geometry_unresolved','reason':'recession solver failed'}
    if error < 1e-8*(1+np.linalg.norm(target)):
        return {'status':'interior', 'design_rank':rank, 'zero_cells':len(gaps)}
    witness = null @ (-residual)
    witness /= max(np.linalg.norm(witness),1e-300)
    gains = np.asarray(gaps)@witness
    if gains.min() < -1e-8 or gains.sum() < 1e-8:
        return {'status':'geometry_unresolved','reason':'uncertified recession direction'}
    return {'status':'boundary', 'design_rank':rank, 'zero_cells':len(gaps),
            'recession_direction':witness.tolist(), 'minimum_gap':float(gains.min())}


def minimize(x, y, start, max_iter=160):
    beta = start.copy()
    history = []
    for iteration in range(max_iter):
        loss, grad, hess = objective(beta,x,y)
        score = float(np.max(np.abs(grad)))
        # Absolute score tolerance, with a roundoff allowance for large totals.
        tolerance = max(1e-7, 2e-12*float(y.sum()))
        if score <= tolerance:
            return beta, {'converged':True,'iterations':iteration,'score_max':score,
                          'loss':loss,'hessian_min_eigenvalue':float(np.linalg.eigvalsh(hess)[0])}
        try:
            step = np.linalg.solve(hess,grad)
        except np.linalg.LinAlgError:
            return beta, {'converged':False,'reason':'singular Hessian','score_max':score}
        descent = float(grad@step)
        if not np.isfinite(descent) or descent <= 0:
            return beta, {'converged':False,'reason':'invalid Newton direction','score_max':score}
        factor = 1.
        for _ in range(60):
            candidate = beta-factor*step
            next_loss = objective(candidate,x,y)[0]
            if np.isfinite(next_loss) and (next_loss <= loss-1e-4*factor*descent
                    or (abs(next_loss-loss) < 1e-11*(1+loss) and factor*descent < 1e-8)):
                beta = candidate
                break
            factor *= .5
        else:
            return beta, {'converged':False,'reason':'line search failed','score_max':score}
        history.append(loss)
    return beta, {'converged':False,'reason':'iteration limit','score_max':score}


def saturated_loglik(y):
    out = 0.
    for row in y:
        positive = row > 0
        if row.sum():
            out += float(np.sum(row[positive]*np.log(row[positive]/row.sum())))
    return out


def fit_joint(m, n, check_starts=True):
    validate_counts(m,n)
    m,n = np.asarray(m,float),np.asarray(n,float)
    c = len(m)
    y = np.stack((m,n),axis=1).reshape(2*c,3)
    x = design(c)
    geo = geometry(x,y)
    result = {'status':geo['status'], 'geometry':geo,
              'regular_degrees_of_freedom':c-1,
              'alternative':'context-specific theta1, equivalently saturated q and p',
              'loglik_saturated':saturated_loglik(y)}
    if geo['status'] != 'interior':
        result['inference_status'] = 'not_evaluable'
        result['reason'] = ('No finite interior MLE; no pseudocount or bounded-parameter substitute '
                            'is reported as an exact fit')
        return result
    start = np.zeros(3*c+1)
    contrasts = []
    for j in range(c):
        # Starting values alone use +.5; this does not change the fitted likelihood.
        a,b = np.log((m[j,:2]+.5)/(m[j,2]+.5))
        u,v = np.log((n[j,:2]+.5)/(n[j,2]+.5))
        start[3*j:3*j+3] = [a,b,u]
        contrasts.append(v-.5*u-b+.5*a)
    start[-1] = np.median(contrasts)
    beta, diagnostics = minimize(x,y,start)
    checks = [diagnostics]
    if check_starts:
        other, diag2 = minimize(x,y,np.zeros_like(start))
        checks.append(diag2)
        agree = diag2['converged'] and abs(objective(other,x,y)[0]-objective(beta,x,y)[0]) < 1e-7*(1+y.sum())
    else:
        agree = True
    if not diagnostics['converged'] or not agree:
        result.update(status='optimizer_unresolved',inference_status='not_evaluable',optimizer_checks=checks)
        return result
    loss,_,hess = objective(beta,x,y)
    try:
        eigenvalues = np.linalg.eigvalsh(hess)
        condition = float(eigenvalues[-1]/eigenvalues[0]) if eigenvalues[0] > 0 else math.inf
        if not np.all(np.isfinite(eigenvalues)) or eigenvalues[0] <= 0 or condition > 1e14:
            raise np.linalg.LinAlgError('Information matrix is numerically singular')
        unit = np.zeros(len(beta)); unit[-1] = 1
        variance = float(np.linalg.solve(hess,unit)[-1])
        if not math.isfinite(variance) or variance <= 0:
            raise np.linalg.LinAlgError('Invalid information-based variance')
    except np.linalg.LinAlgError:
        result.update(status='information_unresolved',inference_status='not_evaluable',
                      reason='Information matrix is not sufficiently positive and numerically stable',
                      optimizer_checks=checks)
        return result
    lp = log_softmax(x@beta)
    probs = np.exp(lp).reshape(c,2,3)
    df = c-1
    raw_deviance = 2*(result['loglik_saturated']+loss)
    if raw_deviance < -1e-6*(1+y.sum()):
        result.update(status='optimizer_unresolved',inference_status='not_evaluable',reason='violated nesting')
        return result
    expected = y.sum(axis=1)[:,None]*np.exp(lp)
    sparse = bool(np.any(y == 0) or np.any(expected < 5))
    result.update(status='interior', inference_status='estimable' if df else 'not_evaluable',
                  theta1=float(beta[-1]),theta2=((beta[2:-1:3]-beta[0:-1:3])/2).tolist(),
                  baseline_probabilities=probs[:,0].tolist(),selected_probabilities=probs[:,1].tolist(),
                  loglik_null=-loss,deviance=max(0.,raw_deviance),sparse=sparse,
                  minimum_expected_count=float(expected.min()),optimizer_checks=checks,
                  information_condition_number=condition,
                  theta1_standard_error_regular=math.sqrt(variance),
                  asymptotic_p_value=None)
    if df == 0:
        result['reason'] = 'One context: shared theta1 imposes no restriction; no cross-context LRT'
    return result


def bootstrap_lrt(m, n, replicates=199, seed=20260930):
    if not isinstance(replicates,int) or isinstance(replicates,bool) or replicates < 1:
        raise ValueError('Positive integer bootstrap replicate count required')
    fit = fit_joint(m,n)
    if fit['inference_status'] != 'estimable':
        return {'status':'not_evaluable','fit':fit,'p_value':None}
    rng = np.random.default_rng(seed)
    q,p = np.asarray(fit['baseline_probabilities']),np.asarray(fit['selected_probabilities'])
    totals_m,totals_n = np.asarray(m).sum(axis=1),np.asarray(n).sum(axis=1)
    exceed, unresolved, statistics, reasons = 0,0,[],{}
    tolerance = 1e-9*max(1.,fit['deviance'])
    for _ in range(replicates):
        mb = np.array([rng.multinomial(int(t),row) for t,row in zip(totals_m,q)])
        nb = np.array([rng.multinomial(int(t),row) for t,row in zip(totals_n,p)])
        trial = fit_joint(mb,nb,check_starts=False)
        if trial['status'] != 'interior':
            unresolved += 1
            reasons[trial['status']] = reasons.get(trial['status'],0)+1
            continue
        stat = trial['deviance']
        statistics.append(stat)
        exceed += stat >= fit['deviance']-tolerance
    bounds = [(1+exceed)/(replicates+1), (1+exceed+unresolved)/(replicates+1)]
    return {'status':'resolved' if not unresolved else 'partially_unresolved',
            'fit':fit,'replicates':replicates,'seed':seed,'exceedances':int(exceed),
            'unresolved_replicates':unresolved,'unresolved_reasons':reasons,
            'p_value':bounds[0] if not unresolved else None,'p_value_computational_bounds':bounds,
            'monte_carlo_resolution':1/(replicates+1),'comparison_tolerance':tolerance,
            'bootstrap_statistics':statistics,
            'interpretation':'Estimated-null parametric bootstrap; approximate composite-null calibration. '
                             'Bounds classify unresolved replicates both ways; they are not confidence intervals. '
                             'Nonrejection does not establish WS or a biological mechanism.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    parser.add_argument('--bootstrap',type=int,default=0)
    parser.add_argument('--seed',type=int,default=20260930)
    parser.add_argument('--output',type=Path)
    args = parser.parse_args()
    try:
        raw = args.input.read_bytes()
        doc = json.loads(raw)
        names,m,n = validate_document(doc)
        if args.bootstrap < 0:
            raise ValueError('Bootstrap count must be nonnegative')
        result = bootstrap_lrt(m,n,args.bootstrap,args.seed) if args.bootstrap else fit_joint(m,n)
        result.update(schema_version='0.2.0',contexts=names,route_order=list(ROUTES),
                      metadata=doc['metadata'],input_sha256=hashlib.sha256(raw).hexdigest(),
                      provenance_warning='Synthetic data are arithmetic/software checks, not biological evidence.'
                      if doc['metadata']['provenance']=='synthetic' else
                      'Metadata declarations do not authenticate the observations or independence assumptions.')
        encoded = json.dumps(result,indent=2,allow_nan=False)+'\n'
        if args.output:
            args.output.write_text(encoded)
        else:
            print(encoded,end='')
    except (ValueError,TypeError,KeyError,OSError,json.JSONDecodeError) as exc:
        parser.exit(2,f'Invalid input or analysis failure: {exc}\n')

if __name__ == '__main__':
    main()
