"""Synthetic-only verification; no biological observations or assertions."""
import json
import math
from pathlib import Path
import unittest
from unittest.mock import patch
import numpy as np
from joint_ws_inference import (design, objective, fit_joint, geometry, bootstrap_lrt,
                                log_softmax, validate_document, validate_counts)

ROOT = Path(__file__).parent

class JointLikelihoodTests(unittest.TestCase):
    def test_noiseless_algebra_fixture(self):
        doc=json.loads((ROOT/'fixtures/noiseless_shared_theta.json').read_text())
        _,m,n=validate_document(doc)
        fit=fit_joint(m,n)
        self.assertEqual(fit['status'],'interior')
        self.assertAlmostEqual(fit['theta1'],math.log(2),places=7)
        np.testing.assert_allclose(fit['theta2'],[0,0,math.log(2),-math.log(2)],atol=1e-7)
        self.assertLess(fit['deviance'],1e-7)
        np.testing.assert_allclose(fit['baseline_probabilities'],m/m.sum(axis=1)[:,None],atol=1e-8)
        np.testing.assert_allclose(fit['selected_probabilities'],n/n.sum(axis=1)[:,None],atol=1e-8)
        raw=(n[:,1]/n.sum(axis=1))**2/((n[:,0]/n.sum(axis=1))*(n[:,2]/n.sum(axis=1)))
        self.assertGreater(raw.max()/raw.min(),10)

    def test_gradient_hessian_against_finite_differences(self):
        x=design(2); y=np.array([[12,18,10],[20,5,15],[8,15,17],[7,28,5]],float)
        beta=np.array([.3,-.4,.1,-.2,.5,.6,.8]); h=1e-5
        loss,g,H=objective(beta,x,y)
        numeric_g=np.zeros(len(beta)); numeric_H=np.zeros_like(H)
        for j in range(len(beta)):
            shift=np.eye(len(beta))[j]*h
            numeric_g[j]=(objective(beta+shift,x,y)[0]-objective(beta-shift,x,y)[0])/(2*h)
            numeric_H[:,j]=(objective(beta+shift,x,y)[1]-objective(beta-shift,x,y)[1])/(2*h)
        np.testing.assert_allclose(g,numeric_g,atol=1e-7)
        np.testing.assert_allclose(H,numeric_H,atol=1e-7)
        self.assertGreater(np.linalg.eigvalsh(H).min(),0)

    def test_zero_cell_can_have_finite_interior_fit(self):
        # Selected M absent in one context, but W and A both represented.
        fit=fit_joint([[20,20,20],[20,20,20]],[[15,10,0],[10,10,10]])
        self.assertEqual(fit['status'],'interior')
        self.assertTrue(fit['sparse'])
        self.assertGreater(min(np.array(fit['selected_probabilities']).flat),0)
        self.assertIsNone(fit['asymptotic_p_value'])

    def test_zero_boundary_refused(self):
        fit=fit_joint([[20,20,20],[20,20,20]],[[30,0,0],[10,10,10]])
        self.assertEqual(fit['status'],'boundary')
        self.assertEqual(fit['inference_status'],'not_evaluable')
        self.assertNotIn('theta1',fit)
        d=np.array(fit['geometry']['recession_direction']); x=design(2)
        self.assertGreater((x[1,0]-x[1,1])@d,0)
        self.assertAlmostEqual((x[3,0]-x[3,1])@d,0,places=7)

    def test_missing_calibration_sample(self):
        fit=fit_joint([[0,0,0],[10,10,10]],[[10,10,10],[10,10,10]])
        self.assertEqual(fit['status'],'not_evaluable')

    def test_one_context_no_cross_context_restriction(self):
        fit=fit_joint([[10,20,30]],[[25,10,25]])
        self.assertEqual(fit['regular_degrees_of_freedom'],0)
        self.assertEqual(fit['inference_status'],'not_evaluable')
        self.assertLess(fit['deviance'],1e-8)

    def test_stable_extreme_logsumexp(self):
        lp=log_softmax(np.array([[10000.,10001.,-10000.],[-9999.,-10000.,-9998.]]))
        self.assertTrue(np.all(np.isfinite(lp)))
        np.testing.assert_allclose(np.exp(lp).sum(axis=1),1,atol=1e-14)

    def test_unequal_baselines_shared_theta_simulation(self):
        rng=np.random.default_rng(7001)
        q=np.array([[.18,.63,.19],[.48,.13,.39],[.1,.25,.65],[.52,.35,.13]])
        theta=.6; slopes=np.array([-.3,.2,.7,-.6])
        p=np.exp(log_softmax(np.log(q)+np.column_stack((slopes,np.full(4,theta),-slopes))))
        m=np.array([rng.multinomial(10000,row) for row in q]); n=np.array([rng.multinomial(10000,row) for row in p])
        fit=fit_joint(m,n)
        self.assertEqual(fit['status'],'interior')
        self.assertLess(abs(fit['theta1']-theta),.08)
        self.assertLess(fit['deviance'],16)
        boot=bootstrap_lrt(m,n,replicates=39,seed=32)
        self.assertEqual(boot['status'],'resolved')
        self.assertGreater(boot['p_value'],.025)

    def test_context_specific_departure_detected(self):
        doc=json.loads((ROOT/'fixtures/noiseless_shared_theta.json').read_text())
        _,m,n=validate_document(doc)
        n=n.astype(int); n[0]=[3000,3000,3000]
        fit=fit_joint(m,n)
        self.assertGreater(fit['deviance'],100)
        boot=bootstrap_lrt(m,n,replicates=39,seed=21)
        self.assertEqual(boot['status'],'resolved')
        self.assertEqual(boot['exceedances'],0)
        self.assertEqual(boot['p_value'],1/40)

    def test_baseline_uncertainty_is_included(self):
        # At exact model counts, inverse Fisher information has a closed form.
        m=np.array([[30,60,30],[48,24,48]])
        n=np.array([[30,120,30],[60,60,60]])
        fit=fit_joint(m,n)
        v=np.array([-.5,1,-.5]); q=m/m.sum(axis=1)[:,None]; p=n/n.sum(axis=1)[:,None]
        variances=(v*v/p).sum(axis=1)/n.sum(axis=1)+(v*v/q).sum(axis=1)/m.sum(axis=1)
        expected_var=1/(1/variances).sum()
        self.assertAlmostEqual(fit['theta1_standard_error_regular']**2,expected_var,places=9)
        fit_large=fit_joint(m*1000,n)
        self.assertLess(fit_large['theta1_standard_error_regular'],fit['theta1_standard_error_regular'])

    def test_bootstrap_does_not_discard_boundary_draws(self):
        boot=bootstrap_lrt([[3,3,3],[3,3,3]],[[3,3,3],[3,3,3]],replicates=49,seed=8)
        self.assertGreater(boot['unresolved_replicates'],0)
        self.assertIsNone(boot['p_value'])
        self.assertLess(boot['p_value_computational_bounds'][0],boot['p_value_computational_bounds'][1])
        self.assertEqual(len(boot['bootstrap_statistics'])+boot['unresolved_replicates'],49)

    def test_calibration_validation_contract(self):
        doc=json.loads((ROOT/'fixtures/noiseless_shared_theta.json').read_text())
        doc['metadata']['calibration_design']='pathway_isolated_mutant_totals'
        with self.assertRaisesRegex(ValueError,'pathway-isolated'):
            validate_document(doc)

    def test_bad_counts_rejected(self):
        for m in ([[1,-1,3]],[[1,.5,3]],[[1,float('nan'),3]],[[True,False,True]],
                  [[True,2,3]],[[1,2]],None,[[2**52,1,0]]):
            with self.assertRaises(ValueError): validate_counts(m,[[1,2,3]])

    def test_malformed_document_rejected(self):
        for document in ([],None,{'metadata':None}):
            with self.assertRaises(ValueError): validate_document(document)

    def test_information_failure_is_reported(self):
        # Failure injection verifies conservative handling after optimizer convergence.
        with patch('joint_ws_inference.np.linalg.eigvalsh',return_value=np.array([-1.,1.])):
            result=fit_joint([[10,20,10],[20,10,20]],[[10,40,10],[20,20,20]])
        self.assertEqual(result['status'],'information_unresolved')
        self.assertEqual(result['inference_status'],'not_evaluable')
        self.assertNotIn('theta1',result)

    def test_bootstrap_seed_reproducible(self):
        m=[[40,80,40],[64,32,64]]; n=[[40,160,40],[80,80,80]]
        a=bootstrap_lrt(m,n,replicates=9,seed=101)
        b=bootstrap_lrt(m,n,replicates=9,seed=101)
        self.assertEqual(a,b)

if __name__=='__main__': unittest.main(verbosity=2)
