# Decisions to lock before the next biological test

This is a proposed analysis plan, not a preregistration or an executed experiment.

1. Use at least four prespecified biological contexts and a common documented background. Choose exhaustive categories or an explicit, identical triad conditioning rule. Retain other outcomes and all exclusions.
2. Establish whether supply measurements are categorical independent observations. If supply comes from fluctuation cultures, develop the appropriate culture/growth likelihood rather than feed colony totals into a multinomial. Record sample denominators, independence units and uncertainty.
3. Validate route recovery in baseline and selected assays. If relative recovery is unequal, measure it independently, propagate its uncertainty, or state which biological contrast cannot be identified. Prefer matched assays where justified.
4. Specify a practically meaningful departure in theta or J, not only a p-value threshold. Estimate required observations by simulations of the actual analysis over weak effects, rare routes and plausible calibration uncertainty. The checked-in dense strong-effect simulation is not a real sample-size justification.
5. Keep a new condition or later block unseen for prediction. Independently calibrate its q, and predeclare or independently measure its context slope. A free new-context slope fitted to its selected outcomes is a retrospective goodness-of-fit test, not a fully held-out route forecast.
6. Compare shared WS structure, context-specific structure, mutation-only prediction and an independently measured performance model. Give comparisons the same eligible data and training access. Define score, uncertainty and selection rule in advance.
7. Freeze treatment of zero cells, unestimable/boundary fits and failed bootstrap draws. Never turn a numerical failure into favorable evidence or change a route dictionary after looking at outcomes.
8. Collect first-event records only if a justified measurement system can observe that event. Endpoint survivor genotypes, pooled sequencing calls and detection thresholds require their own observation models. If timing and joint WS are combined, include calibration likelihood in every compared nested model.
9. Archive source records, provenance, prespecified choices, departures and unsuccessful predictions. Hashes protect files; they do not verify biology. A robust new condition and honest failure analysis are the next priority.
