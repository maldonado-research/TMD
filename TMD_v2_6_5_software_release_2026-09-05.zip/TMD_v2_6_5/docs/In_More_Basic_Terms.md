# In More Basic Terms

TMD studies why some evolutionary routes occur more often than others. Its models consider how often a change becomes available and how likely that change is to establish itself. Testing those models requires observations whose origin, processing, and uncertainty can be checked.

This release improves the software used to organize that testing. Think of it as a research notebook with a task planner: it selects an eligible next analysis, reads a result file, checks the record, updates the remaining budget, and records what happened. The included dry runs use examples and simulated results.

The September update repairs a Python compatibility failure and strengthens checks on returned result packages. Passing these checks means that a tested software workflow behaved as expected. It does not establish that a biological hypothesis is true, that a laboratory independently reproduced it, or that a unified theory of everything has been demonstrated.
