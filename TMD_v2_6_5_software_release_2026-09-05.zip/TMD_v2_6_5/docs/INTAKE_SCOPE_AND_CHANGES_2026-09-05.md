# TMD intake and submission consistency checks — September 5, 2026

The corrected intake validator and submission acceptor reject several malformed or internally inconsistent bundles that the prior implementation accepted. They retain their existing filenames and output filenames for command compatibility; generated reports identify implementation version v0.2.

These programs check internal consistency and campaign bookkeeping. A passing report does not authenticate the submitter, establish that an experiment occurred, verify the biological truth of a result, or validate a unified theory. They do not independently rerun the submitted certificates' tests or verify source artifact bytes. The `source_artifacts_verified`, `submitter_identity_authenticated`, and `certificate_to_ledger_binding_verified` report fields are explicitly false.

## In More Basic Terms

This update strengthens the checks used when files enter the research workflow. It checks that the records agree with one another, that required fields are present, and that the next campaign step respects the stated prerequisites and budget. Earlier checks could accept some incomplete or contradictory records; this update rejects those cases.

These checks are like checking that a research notebook's pages and arithmetic agree. They cannot tell whether the recorded experiment really happened or whether its scientific conclusion is correct. Independent measurements and scientific review are still needed. This release improves the research software; it does not establish a theory of everything.

## Changes

- Intake and acceptance require a replay ledger and a supported certificate. Empty certificates and unknown certificate versions fail explicitly.
- JSON duplicate keys, non-finite constants, non-object ledgers, and malformed event structures fail with a report rather than being silently accepted or causing the reproduced crashes.
- The supported replay ledger must contain its five expected events, in order. Event hashes and chaining are recomputed. Artifact digest fields and top-level manifest action/branch must agree with their committed event fields.
- Missing or false required hash-check flags and a non-passing ledger status reject the submission. These remain checks of recorded assertions; they are not fresh reads of the referenced source files.
- Certificate gate counts, passing flags, and return codes must agree. Multicycle Merkle roots and levels and release acceptance roots are recomputed from their listed components.
- An explicit completion action must agree with the ledger's committed action. Negative/nonintegral action costs and malformed campaign budgets are rejected. Existing completed actions must respect the configured prerequisites.
- A rejected run removes a stale generated state from its output directory, except when that file is also the campaign input. An output directory that would overwrite the campaign input is refused, preserving that input. Use a distinct output directory for each new state transition.

## Compatibility and limits

Supported certificate versions are `TMD_external_lab_preflight_gate_v0_1`, `TMD_release_acceptance_gate_v0_1`, and `TMD_multicycle_campaign_runner_v0_1`. Other certificate schemas need explicit support before acceptance. The supported ledger schema is `TMD_event_sourced_replay_ledger_v0_1` with the five events used in the bundled examples. Broader schema compatibility has not been claimed or tested.

The legacy preflight root includes a hash of its generating script, but the certificate's component list omits that script hash. Therefore the preflight root cannot be reconstructed from the certificate alone; its report records `preflight_root_recomputed: false`. Its syntax and gate fields are checked. The release root commits to the supplied component root strings, not an independently authenticated source.

The bundled valid submission is a software fixture. Its replay ledger is an H482R example; its companion multicycle certificate describes a separate dry run, and that example ledger's final hash is not one of the multicycle certificate's leaves. The compatibility test does not claim a certificate-to-ledger provenance link. Original paths such as `/mnt/data/...` remain historical evidence inside the hashed ledger. This validator does not read arbitrary paths recorded there or require those paths to exist.

A person who changes a complete ledger and recomputes all hashes can create a different internally consistent ledger. Without trusted external anchors or signatures, these checks cannot distinguish that from an authentic record. Incoming empirical results still require source-file verification, study-specific quality review, and independent scientific assessment. No claim is made that the action slate's hypotheses, cost choices, or biological premises are validated by this suite.

## Run from the release folder

No third-party Python dependencies are required. Existing valid and tampered examples remain included. The acceptor locates its templates using its `submission/workflow/` directory, so keep the sibling `submission/templates/` directory.

```bash
python3 -S intake/tmd_external_result_intake_validator_v0_1.py submission/examples/valid_submission --outdir validation/intake_example
python3 -S submission/workflow/tmd_external_submission_acceptor_v0_1.py --submission-dir submission/examples/valid_submission --campaign-state submission/templates/TMD_campaign_state_template_v0_2.json --outdir validation/acceptance_example
python3 -S submission/workflow/tmd_external_submission_acceptor_v0_1.py --submission-dir submission/examples/tampered_submission --campaign-state submission/templates/TMD_campaign_state_template_v0_2.json --outdir validation/tampered_example
python3 -S tests/run_intake_regressions.py --runtime-root runtime --outdir validation/intake_regression_run
```

The valid example returns exit code 0, completes `H482R_developmental_entry_proxy`, and leaves budget 18 from a starting budget of 23. The tampered example intentionally returns exit code 2 and generates a rejection report. The regression suite returns 0 only when all expected accept/reject behaviors and input-preservation checks pass. `--runtime-root runtime` first generates a fresh release-acceptance run and then exercises all four generated cycles. `--runtime-validation PATH` can instead consume a completed acceptance run. Omitting both options runs only the 41 targeted checks. `--outdir` for the regression suite must be a dedicated test-output directory; its named test-case folders are recreated on each run.

## Verification evidence

On the available Python 3.9 runtime, the corrected scripts pass 41/41 targeted regression checks and 8/8 fresh runtime integration checks (49/49 total). The unmodified baseline passes 10/41 of the targeted expected behaviors: 25 checks reproduce false acceptance, five reproduce malformed-input crashes, and one exposes stale generated output after rejection. The integration checks run intake and acceptance on each of the four freshly generated dry-run cycle ledgers, verify that its hash appears in the campaign certificate, and advance a campaign state through budgets 23 → 18 → 13 → 7 → 0. They confirm that the current components work together on these generated examples. These are targeted regression results, not exhaustive validation or statistical evidence about biological performance. Bundled valid and deliberately tampered examples are included in the count.

An additional software review identified an intermediate cleanup implementation's risk of deleting a reused campaign-input file, a malformed configuration-row failure, and missing campaign action fields in the current runtime manifests. The delivered components guard the input, reject the malformed row, and emit the committed action fields. The suite verifies input preservation, replacement of stale success after rejection, and composition with all four new runtime ledgers.

A local pattern scan of the two original intake/submission directories found no matching access-token/password assignments, email addresses, or personal `/Users/` or `/home/` paths in their text files. This is a bounded screening result rather than a guarantee that every possible confidential value is absent.
