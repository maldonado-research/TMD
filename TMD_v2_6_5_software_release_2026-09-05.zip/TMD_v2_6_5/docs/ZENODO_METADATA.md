# Zenodo metadata - TMD v2.6.5

Title: Theory of Mutation by Natural Dominance (TMD) — v2.6.5: portable campaign execution and stricter result acceptance

Version: 2.6.5

Date: 2026-09-05

Resource type: Software

Creator: Ricardo Maldonado, Independent Researcher

ORCID: https://orcid.org/0009-0009-3937-6527

Version DOI: 10.5281/zenodo.22398093

Version URL: https://zenodo.org/records/22398093

Previous version: https://zenodo.org/records/20186340

Record-level license: MIT

## Description

TMD (Theory of Mutation by Natural Dominance) v2.6.5 is an analysis-only software release for organizing and checking tests of mutation-route models. It builds on v2.6.4 (10.5281/zenodo.20186340), preserving the existing Zenodo version series.

What changed in v2.6.5

This update repairs Python 3.9 timestamp compatibility, aligns generated campaign manifests with the action and branch recorded in the replay ledger, and strengthens result-intake and submission checks. The tools reject the tested incomplete, malformed, or contradictory packages and handle malformed CSV files and reused output paths more safely. The source archive includes executable examples, regression checks, validation evidence, change patches, licensing, and SHA-256 manifests.

Validation performed

On CPython 3.9.6 and 3.12.14, on the same macOS ARM64 computer with third-party site packages disabled, each interpreter passed 2 acceptance gates, 4 smoke cases, 9 failure-injection controls, and 49 intake/integration checks. The 49 checks comprise 41 targeted regression cases and 8 checks using freshly generated runtime outputs across all four simulated campaign actions. The simulated campaign completed its expected four actions with the remaining budget progressing from 23 to 18 to 13 to 7 to 0. These counts describe selected software tests; they are not estimates of biological accuracy or general error rates.

Scope and interpretation

No new laboratory measurements or independently returned collaborator results are reported in this update. Validation uses bundled examples, simulated transitions, and intentionally invalid packages. It does not establish predictive performance on unseen biological data, an independent laboratory replication, or a unified theory of everything.

Replay and intake checks assess internal structure, consistency, and campaign bookkeeping. They do not authenticate a submitter, verify original experimental source bytes, or prove that an experiment occurred. Some legacy certificates and ledger fixtures represent separate simulated runs, and the legacy preflight certificate does not supply every input needed to recompute its root. The evidence and documentation state these limits explicitly.

Getting started

Extract the v2.6.5 software archive and follow README.md. From the extracted package root, run:
python3 -S verify_release.py
python3 -S runtime/run_tmd_release_acceptance_gate_v0_1.py --outdir runs/release_acceptance

The expected acceptance value is all_passed == true in the generated release-acceptance certificate. The README documents the intake/integration checks and next steps toward independent, preregistered evaluation.

Licensing

Software/code: MIT. Documentation/figures: CC BY 4.0 unless otherwise noted, following the May 14 release materials. See docs/LICENSING.md and file-specific notices. Earlier releases remain available through Zenodo's version history.

## Additional descriptions

In More Basic Terms

TMD studies why some evolutionary routes occur more often than others. Its models consider how often a change becomes available and how likely that change is to establish itself. Testing those models requires observations whose origin, processing, and uncertainty can be checked.

This release improves the software used to organize that testing. Think of it as a research notebook with a task planner: it selects an eligible next analysis, reads a result file, checks the record, updates the remaining budget, and records what happened. The included dry runs use examples and simulated results.

The September update repairs a Python compatibility failure and strengthens checks on returned result packages. Passing these checks means that a tested software workflow behaved as expected. It does not establish that a biological hypothesis is true, that a laboratory independently reproduced it, or that a unified theory of everything has been demonstrated.

The next scientific step is to define predictions and comparison models before examining new data, then test them with independent observations and report both successes and failures.

Public / Press Background

Theory of Mutation by Natural Dominance (TMD) is Ricardo Maldonado's proposed framework for studying the relative frequencies and timing of competing evolutionary mutation routes. It considers mutation supply, biological accessibility, establishment, and context when formulating testable models.

Version 2.6.5 advances the supporting software: portable campaign execution, consistent records of selected actions, stricter checks on result packages, and documented regression evidence. The purpose is to make future evaluation easier to reproduce and inspect.

This release reports software tests using examples and simulated inputs. It contains no new experimental confirmation, independent laboratory replication, or demonstrated unified theory. Whether the models improve prediction across biological systems remains a question for independent, preregistered comparison against appropriate alternatives.

## Keywords

mutation bias; evolutionary predictability; reproducible research; campaign planning; sequential analysis; result validation; replay ledger; Python; software testing
