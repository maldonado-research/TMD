# Licensing

Copyright (c) 2026 Ricardo Maldonado. Software/code is released under the MIT License. Documentation and figures are available under Creative Commons Attribution 4.0 unless a specific accompanying notice states otherwise. This preserves the split specified in the supplied May 14, 2026 v2.6.4 metadata and upload checklist. The prior Zenodo record identifies MIT as its record-level license and permits reuse of documentation and figures with attribution unless otherwise noted.

The `license` field in `CITATION.cff` describes the software. Documentation is under CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Any specific notice accompanying an inherited item takes precedence for that item. Included example data are distributed as inherited from the supplied research bundle; no new third-party dataset was acquired for this update. Licensing provenance: `TMD_Zenodo_metadata_ready_v2_6_4_2026-05-14.md`, License section, and `TMD_v2_6_4_Zenodo_upload_checklist_2026-05-14.md`, item 8, within the source archives inventoried in `evidence/source_archives.json`.

## MIT License - software

Copyright (c) 2026 Ricardo Maldonado

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
