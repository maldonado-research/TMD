# Source provenance

The latest local source bundle identified was the May 14 v2.6.4 bundle in `untitled folder 20 ZENODO`. The April 24 archives supplied in folder 252 and the May 1 patch in folder 253 are earlier material. The two May 1 ZIPs are byte-identical despite different names.

All source archives were read as references; originals were left unchanged. The source-archive inventory records their byte sizes and SHA-256 digests. This release contains a clean active runtime and selected intake/submission tools, with examples and targeted checks. It does not republish every historical archive or claim that older theoretical material has received a new scientific validation.

The May 14 handover and metadata were used for current software scope. The previous TMD task was absent from the app's recent-task listing; a local November 2025 chat-history export was available but is older. Neither that export nor archived instructions were treated as new authorization.

The preceding published record is https://zenodo.org/records/20186340 , TMD v2.6.4, dated 2026-05-14. Its live version and publication date were checked before preparing this v2.6.5 release. Zenodo maintains the version-family relationship; version-specific citation information is in `CITATION.cff`.

AI assistance was used to inspect the supplied software, propose repairs, build regression tests, and draft documentation. Ricardo Maldonado remains the named creator. Machine-generated example results and software test outcomes are distinguished from biological measurements.
