# TMD v2.6.5 - release notes

Version 2.6.5 | 2026-09-05 | Ricardo Maldonado

## Result

The update repairs a Python compatibility failure, connects generated campaign manifests to the ledger fields required by intake, and strengthens result-package acceptance. It builds on the May 14 v2.6.4 local bundle, which is later than the two April 24 ZIPs supplied in folder 252 and the May 1 portable patch in folder 253.

## Changes

1. **Portable UTC timestamp:** the campaign-state updater uses `datetime.timezone.utc` in place of `datetime.UTC`. The prior implementation failed on Python 3.9.6; the intended UTC timestamp semantics are preserved.
2. **Recorded campaign action:** the campaign-aware manifest compiler supplies the selected campaign action and its branch in the fields committed by the replay ledger. The initial runtime proposal remains separately recorded. Fresh campaign outputs can therefore pass through the stricter intake tools.
3. **Stricter intake and submission checks:** required ledger and supported certificate structure, event ordering, recorded hash checks, certificate fields, and action/budget consistency are checked. Targeted malformed or contradictory inputs are rejected with reports.
4. **Input preservation:** output reuse that would overwrite a campaign input is refused. Rejection clears stale separately generated state, and malformed/truncated CSV inputs are handled without leaving a stale success result in the reproduced cases.
5. **Clean distribution:** active source, examples, reproducible tests, compact evidence, exact patches, and a manifest replace the need to untangle multiple historical ZIPs. Original source archives remain unchanged.

## Verification

The final staged source package was tested on CPython 3.9.6 and 3.12.14 on the same macOS ARM64 computer, with third-party site initialization disabled (`-S`). On each interpreter:

| Check | Result |
| --- | --- |
| Portable acceptance gates | 2/2 passed |
| Smoke cases | 4/4 passed |
| Failure-injection controls | 9/9 passed |
| Synthetic four-action campaign | Finished at budget 0 |
| Intake/submission regression and integration checks | 49/49 passed |

The 49 checks consist of 41 targeted controls and eight checks of four newly generated campaign ledgers, including sequential accepted budgets of 18, 13, 7, and 0 from a starting budget of 23. These suite counts overlap and must not be added as if they represented independent experiments.

On the same 41 targeted controls, the inherited intake/submission implementation passed 10. The remaining cases reproduced 25 false acceptances, five malformed-input crashes, and one stale-output issue. These cases were selected to test identified defects; their proportions are not estimates of error frequency in real use.

The unmodified inherited portable runtime failed both top-level acceptance gates on Python 3.9.6 because of the UTC compatibility issue. The final runtime source inventory is supplied with both interpreter summaries. Raw local run outputs remain available in the working directory; the distribution includes compact summaries and reproducible commands.

## In More Basic Terms

This software is a research notebook with a task planner. It helps choose an eligible next analysis, process a returned result, check the record, and update the campaign's remaining budget. This update makes those steps run more reliably and rejects more kinds of incomplete or inconsistent files.

Passing these checks tells us about the tested software's behavior. It does not demonstrate biological truth or an independent laboratory replication. No new biological observations were generated or added for this release.

## Limits and next scientific step

The intake tools verify internal consistency and bookkeeping. They do not authenticate the submitter, verify original measurement bytes, independently rerun submitted certificates, or establish a certificate-to-measurement provenance link. A fully rewritten, consistently rehashed ledger can still pass internal checks. Historical fixture certificates and ledgers may describe separate simulated runs; the compatibility examples are not authenticated scientific submissions.

The inherited preflight certificate omits one component needed to recompute its root; the validators explicitly report that its root was not independently recomputed. Supported schemas and remaining limits are documented in the intake scope note.

The next empirical step remains an independently documented test using specified predictions, source observations, uncertainty estimates, appropriate comparison models, and study-specific quality review. This software release does not establish a unified theory of everything.

## Version continuity

This release follows TMD v2.6.4, published 2026-05-14 at https://zenodo.org/records/20186340 . It continues that record's version family. The earlier release remains the reference for the broader historical materials; this archive distributes the active software and the documented September corrections.
