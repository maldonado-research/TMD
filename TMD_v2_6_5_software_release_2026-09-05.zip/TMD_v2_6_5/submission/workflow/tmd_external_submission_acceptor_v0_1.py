#!/usr/bin/env python3
"""TMD external submission acceptor v0.2 (legacy filename retained).

Checks internal consistency of supported submissions and updates campaign bookkeeping.
Does not authenticate the submitter or original artifacts, or establish empirical truth.
Pure-Python, no third-party dependencies.
"""
import argparse, csv, hashlib, json, sys
from pathlib import Path


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write("\n")


def load_csv_dict(path):
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise ValueError('missing or duplicate CSV headers')
        rows = list(reader)
    if not rows or any(None in row or any(value is None for value in row.values()) for row in rows):
        raise ValueError('empty CSV or row length differs from header')
    return rows


def parse_requires(s):
    s = (s or "").strip()
    if not s or s.lower() == "(none)":
        return []
    return [x.strip() for x in s.split("|") if x.strip()]


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key: ' + key)
        result[key] = value
    return result


def _reject_constant(value):
    raise ValueError('non-finite JSON number: ' + value)


def read_json(path):
    with open(path, encoding='utf-8') as stream:
        return json.load(stream, object_pairs_hook=_unique_object,
                         parse_constant=_reject_constant)


def _is_hash(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def _positive_int(value):
    return type(value) is int and value > 0


def _merkle(leaves):
    levels = [sorted(leaves)]
    while len(levels[-1]) > 1:
        level = levels[-1]
        levels.append([sha256_text(level[i] + (level[i+1] if i+1 < len(level) else level[i]))
                       for i in range(0, len(level), 2)])
    return levels[-1][0], levels


def verify_ledger(path):
    out = {'file': str(path), 'type': 'ledger', 'status': 'invalid', 'errors': [], 'warnings': []}
    try:
        d = read_json(path)
    except (ValueError, OSError) as error:
        out['errors'].append('json_parse_error: ' + str(error)); return out
    if not isinstance(d, dict):
        out['errors'].append('ledger must be a JSON object'); return out
    events = d.get('events')
    if not isinstance(events, list) or not events:
        out['errors'].append('missing_or_empty_events'); return out
    if d.get('status') != 'valid': out['errors'].append('ledger status is not valid')
    if d.get('ledger_version') != 'TMD_event_sourced_replay_ledger_v0_1':
        out['errors'].append('unsupported or missing ledger_version')
    required = ['state_before', 'manifest_issued', 'result_observed', 'feedback_reduced', 'state_after']
    if [e.get('event_type') if isinstance(e, dict) else None for e in events] != required:
        out['errors'].append('ledger must contain the five supported events in order')
    by_type = {}
    previous = 'GENESIS'
    for index, event in enumerate(events, start=1):
        if not isinstance(event, dict):
            out['errors'].append(f'event {index}: must be an object'); continue
        if type(event.get('index')) is not int or event['index'] != index:
            out['errors'].append(f'event {index}: index mismatch')
        if event.get('previous_event_hash') != previous:
            out['errors'].append(f'event {index}: previous_event_hash mismatch')
        payload = event.get('payload')
        if not isinstance(payload, dict):
            out['errors'].append(f'event {index}: payload must be an object')
        elif isinstance(event.get('event_type'), str):
            by_type[event['event_type']] = payload
        committed = {k: event.get(k) for k in ['index', 'event_type', 'previous_event_hash', 'payload']}
        if not _is_hash(event.get('event_hash')) or sha256_text(canonical(committed)) != event.get('event_hash'):
            out['errors'].append(f'event {index}: event_hash mismatch')
        previous = event.get('event_hash')
    if not _is_hash(d.get('final_event_hash')) or d.get('final_event_hash') != previous:
        out['errors'].append('final_event_hash does not match last event')
    checks = d.get('hash_checks')
    required_checks = ['state_before_matches_feedback_spec', 'manifest_matches_feedback',
                       'result_matches_feedback', 'state_after_exists']
    if not isinstance(checks, dict) or any(checks.get(key) is not True for key in required_checks):
        out['errors'].append('missing or failed required hash_checks')
    elif any(value is not True for value in checks.values()):
        out['errors'].append('hash_checks contains a non-passing value')
    artifacts = d.get('artifact_hashes')
    if not isinstance(artifacts, dict):
        out['errors'].append('missing artifact_hashes')
    else:
        for key, event_type in [('state_before','state_before'), ('manifest','manifest_issued'),
                                ('result_csv','result_observed'), ('feedback_report','feedback_reduced'),
                                ('state_after','state_after')]:
            digest = artifacts.get(key)
            if not _is_hash(digest) or digest != by_type.get(event_type, {}).get('sha256'):
                out['errors'].append('artifact hash does not match committed event: ' + key)
    manifest = by_type.get('manifest_issued', {})
    action = manifest.get('recommended_action')
    if not isinstance(action, str) or not action or action != d.get('manifest_action'):
        out['errors'].append('manifest_action differs from committed manifest event')
    if manifest.get('recommended_branch') != d.get('manifest_branch'):
        out['errors'].append('manifest_branch differs from committed manifest event')
    feedback = by_type.get('feedback_reduced', {})
    if feedback.get('status') != d.get('feedback_status'):
        out['errors'].append('feedback_status differs from committed feedback event')
    patch = feedback.get('patch_report', {})
    if not isinstance(patch, dict) or patch.get('action') != action:
        out['errors'].append('feedback action differs from committed manifest event')
    out.update({'run_id': d.get('run_id'), 'manifest_action': action,
                'manifest_branch': manifest.get('recommended_branch'),
                'final_event_hash': d.get('final_event_hash'), 'ledger_status_field': d.get('status'),
                'verification_scope': 'internal consistency only; source artifacts and submitter identity not authenticated'})
    out['status'] = 'valid' if not out['errors'] else 'invalid'
    return out


def check_certificate(path):
    out = {'file': str(path), 'type': 'certificate', 'status': 'invalid', 'errors': [], 'warnings': []}
    try:
        d = read_json(path)
    except (ValueError, OSError) as error:
        out['errors'].append('json_parse_error: ' + str(error)); return out
    if not isinstance(d, dict):
        out['errors'].append('certificate must be a JSON object'); return out
    version = d.get('certificate_version')
    out['certificate_version'] = version
    known = {'TMD_external_lab_preflight_gate_v0_1', 'TMD_release_acceptance_gate_v0_1',
             'TMD_multicycle_campaign_runner_v0_1'}
    if not isinstance(version, str) or version not in known:
        out['errors'].append('unsupported or missing certificate_version'); return out
    if 'all_passed' in d and d['all_passed'] is not True:
        out['errors'].append('all_passed is not true')
    if 'status' in d and d['status'] not in ('valid', 'ok'):
        out['errors'].append('certificate status is not passing')
    if version == 'TMD_multicycle_campaign_runner_v0_1':
        leaves = d.get('final_event_hashes_sorted')
        actions = d.get('cycle_completed_actions')
        count = d.get('n_cycles')
        if not _positive_int(count) or not isinstance(leaves, list) or not leaves or not all(_is_hash(x) for x in leaves):
            out['errors'].append('missing or invalid campaign cycle/hash fields')
        else:
            root, levels = _merkle(leaves)
            if len(leaves) != count or leaves != sorted(leaves) or len(set(leaves)) != len(leaves):
                out['errors'].append('campaign hash count/order/uniqueness mismatch')
            if d.get('campaign_merkle_root') != root or d.get('merkle_levels') != levels:
                out['errors'].append('campaign Merkle root/levels mismatch')
        if not isinstance(actions, list) or not all(isinstance(a, str) and a for a in actions) or len(actions) != count:
            out['errors'].append('campaign action count/type mismatch')
        elif len(set(actions)) != len(actions): out['errors'].append('duplicate campaign actions')
        if type(d.get('final_budget_after')) is not int or d['final_budget_after'] < 0:
            out['errors'].append('invalid final_budget_after')
    else:
        gates = d.get('gates')
        if d.get('all_passed') is not True: out['errors'].append('missing passing all_passed flag')
        if not isinstance(gates, list) or not gates or not all(isinstance(g, dict) for g in gates):
            out['errors'].append('missing or invalid certificate gates')
        else:
            if type(d.get('n_gates')) is not int or d['n_gates'] != len(gates) or type(d.get('n_passed')) is not int or d['n_passed'] != len(gates):
                out['errors'].append('certificate gate counts disagree')
            for gate in gates:
                if gate.get('pass') is not True or type(gate.get('returncode')) is not int or gate['returncode'] != 0:
                    out['errors'].append('certificate contains a failed/malformed gate')
                if 'summary_exists' in gate and gate['summary_exists'] is not True:
                    out['errors'].append('gate summary is missing')
                if 'n_cases' in gate and (not _positive_int(gate['n_cases']) or gate.get('n_pass') != gate['n_cases']):
                    out['errors'].append('gate case/pass counts disagree')
        if version == 'TMD_release_acceptance_gate_v0_1':
            roots = d.get('component_roots')
            if not isinstance(roots, list) or not roots or not all(_is_hash(root) for root in roots):
                out['errors'].append('missing or invalid component_roots')
            elif d.get('release_acceptance_root') != sha256_text(canonical(roots)):
                out['errors'].append('release acceptance root mismatch')
            if isinstance(gates, list) and all(isinstance(g, dict) for g in gates) and roots != [g.get('root') for g in gates]:
                out['errors'].append('gate roots disagree with component_roots')
        else:
            if not _is_hash(d.get('preflight_merkle_like_root')):
                out['errors'].append('missing or invalid preflight root')
            components = d.get('component_hashes_or_roots')
            if not isinstance(components, list) or not components or not all(_is_hash(x) for x in components):
                out['errors'].append('missing or invalid preflight components')
            # Legacy certificates omit the runner-file hash included in their root.
            out['preflight_root_recomputed'] = False
    for key in ['release_acceptance_root', 'preflight_merkle_like_root', 'campaign_merkle_root']:
        if key in d: out[key] = d[key]
    out['verification_scope'] = 'schema and internal consistency only; no independent execution or issuer authentication'
    out['status'] = 'valid' if not out['errors'] else 'invalid'
    return out


def scan_submission(submission_dir):
    root = Path(submission_dir)
    ledger_results = []
    cert_results = []
    for p in sorted(root.rglob("*.json")):
        name = p.name.lower()
        if "event_sourced_replay_ledger" in name or ("replay_ledger" in name and "certificate" not in name):
            ledger_results.append(verify_ledger(p))
        elif "certificate" in name or "preflight" in name or "acceptance" in name:
            cert_results.append(check_certificate(p))
    return ledger_results, cert_results


def load_action_slate(path):
    rows = load_csv_dict(path)
    actions = {}
    for r in rows:
        action = r["action"]
        if not action or action in actions:
            raise ValueError('missing or duplicate action in slate')
        cost_text = r['cost_units'].strip()
        if not cost_text.isdigit():
            raise ValueError('action cost must be a nonnegative integer: ' + action)
        actions[action] = {
            "cost": int(cost_text),
            "priority": float(r.get("priority_score", 0) or 0),
            "requires": parse_requires(r.get("requires", "")),
            "row": r,
        }
    return actions


def load_runtime_map(path):
    rows = load_csv_dict(path)
    return {r["runtime_action"]: r["campaign_action"] for r in rows}


def infer_campaign_action(valid_ledgers, runtime_map, explicit=None):
    mapped = []
    for r in valid_ledgers:
        runtime_action = r.get("manifest_action")
        if runtime_action in runtime_map:
            mapped.append(runtime_map[runtime_action])
        elif runtime_action:
            mapped.append(runtime_action)
    unique = sorted(set(mapped))
    if len(unique) == 1:
        if explicit and explicit != unique[0]:
            return None, {'method': 'failed', 'reason': 'explicit_action_disagrees_with_ledger', 'candidate_campaign_actions': unique}
        return unique[0], {"method": "inferred_from_ledger_manifest_action", "candidate_campaign_actions": unique, "candidate_runtime_actions": [x.get("manifest_action") for x in valid_ledgers]}
    if not unique:
        return None, {"method": "failed", "reason": "no_mappable_manifest_actions"}
    return None, {"method": "failed", "reason": "multiple_candidate_campaign_actions", "candidate_campaign_actions": unique}


def update_campaign_state(state, action, actions, final_hashes, submission_dir):
    errors = []
    if not isinstance(state, dict):
        return None, ['campaign state must be an object']
    completed = state.get('completed_actions')
    budget = state.get('budget_remaining')
    if not isinstance(completed, list) or not all(isinstance(a, str) for a in completed):
        return None, ['completed_actions must be a list of action names']
    if len(set(completed)) != len(completed):
        errors.append('campaign state contains duplicate completed actions')
    if type(budget) is not int or budget < 0:
        errors.append('budget_remaining must be a nonnegative integer')
    history = state.get('campaign_history', [])
    if not isinstance(history, list) or not all(isinstance(event, dict) for event in history):
        errors.append('campaign_history must be a list of objects')
    for prior in completed:
        if prior not in actions:
            errors.append('unknown completed campaign action: ' + prior)
        elif any(required not in completed for required in actions[prior]['requires']):
            errors.append('existing campaign state violates prerequisites: ' + prior)
    if errors:
        return None, errors
    if action not in actions:
        errors.append(f"unknown campaign action: {action}")
        return None, errors
    if action in completed:
        errors.append(f"duplicate completed action: {action}")
    missing = [r for r in actions[action]["requires"] if r not in completed]
    if missing:
        errors.append("missing prerequisites: " + ", ".join(missing))
    cost = actions[action]["cost"]
    if cost > budget:
        errors.append(f"budget overrun: cost {cost} > budget_remaining {budget}")
    if not final_hashes:
        errors.append("no verified final event hash")
    if errors:
        return None, errors
    new_completed = completed + [action]
    new_budget = budget - cost
    prev_event_hash = state.get("campaign_event_hash", "GENESIS")
    event_payload = {
        "previous_campaign_event_hash": prev_event_hash,
        "completed_action": action,
        "ledger_final_event_hashes": final_hashes,
        "budget_before": budget,
        "budget_after": new_budget,
        "completed_before": completed,
        "completed_after": new_completed,
        "submission_dir": str(submission_dir),
    }
    event_hash = sha256_text(canonical(event_payload))
    hist = list(state.get("campaign_history", []))
    hist.append({
        "event_type": "external_submission_accepted",
        "completed_action": action,
        "action_cost": cost,
        "budget_before": budget,
        "budget_after": new_budget,
        "ledger_final_event_hashes": final_hashes,
        "campaign_event_hash": event_hash,
    })
    new_state = dict(state)
    new_state["completed_actions"] = new_completed
    new_state["budget_remaining"] = new_budget
    new_state["campaign_history"] = hist
    new_state["campaign_event_hash"] = event_hash
    return new_state, []


def main():
    ap = argparse.ArgumentParser(description="Validate external TMD submission and update campaign state if accepted.")
    ap.add_argument("--submission-dir", required=True)
    ap.add_argument("--campaign-state", required=True)
    ap.add_argument("--action-slate", default=None)
    ap.add_argument("--runtime-map", default=None)
    ap.add_argument("--completion-action", default=None)
    ap.add_argument("--outdir", default="external_submission_acceptance")
    ap.add_argument("--allow-warnings", action="store_true", help="Allow advisory warnings; failed integrity checks always reject.")
    args = ap.parse_args()
    this = Path(__file__).resolve()
    base = this.parent.parent if this.parent.name == "workflow" else Path(".")
    action_slate = Path(args.action_slate) if args.action_slate else base / "templates" / "TMD_adaptive_campaign_action_slate_v0_1.csv"
    runtime_map_path = Path(args.runtime_map) if args.runtime_map else base / "templates" / "TMD_runtime_to_campaign_action_map_v0_1.csv"
    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)

    ledgers, certs = scan_submission(args.submission_dir)
    invalid = [x for x in ledgers + certs if x.get("status") == "invalid"]
    warnings = [w for x in ledgers + certs for w in x.get("warnings", [])]
    valid_ledgers = [x for x in ledgers if x.get("status") == "valid"]
    acceptance_errors = []
    output_is_input = (outdir / 'updated_campaign_state_v0_1.json').resolve() == Path(args.campaign_state).resolve()
    if output_is_input:
        acceptance_errors.append('output state would overwrite the campaign input; use a different outdir')
    if invalid:
        acceptance_errors.append(f"invalid artifacts: {len(invalid)}")
    if warnings and not args.allow_warnings:
        acceptance_errors.append('warnings require --allow-warnings')
    if not valid_ledgers:
        acceptance_errors.append("no valid replay ledger found")
    if not certs:
        acceptance_errors.append('no supported certificate found')

    actions, runtime_map, campaign_state = {}, {}, {}
    try:
        actions = load_action_slate(action_slate)
        runtime_map = load_runtime_map(runtime_map_path)
        campaign_state = read_json(args.campaign_state)
        if not isinstance(campaign_state, dict):
            campaign_state = {}
            raise ValueError('campaign state must be an object')
    except (ValueError, OSError, KeyError, TypeError, csv.Error) as error:
        acceptance_errors.append('invalid campaign inputs: ' + str(error))
    completion_action = None
    inference = {}
    if not acceptance_errors:
        completion_action, inference = infer_campaign_action(valid_ledgers, runtime_map, args.completion_action)
        if not completion_action:
            acceptance_errors.append("could not infer a unique campaign action: " + json.dumps(inference))
    updated_state = None
    state_errors = []
    final_hashes = [x.get("final_event_hash") for x in valid_ledgers if x.get("final_event_hash")]
    if not acceptance_errors:
        updated_state, state_errors = update_campaign_state(campaign_state, completion_action, actions, final_hashes, args.submission_dir)
        if state_errors:
            acceptance_errors.extend(state_errors)
    accepted = not acceptance_errors
    report = {
        "acceptor_version": "TMD_external_submission_acceptor_v0_2",
        "verification_scope": "internal consistency and campaign bookkeeping only; not authenticated provenance or empirical validation",
        "source_artifacts_verified": False,
        "submitter_identity_authenticated": False,
        "certificate_to_ledger_binding_verified": False,
        "submission_dir": str(args.submission_dir),
        "campaign_state": str(args.campaign_state),
        "accepted": accepted,
        "errors": acceptance_errors,
        "warnings": warnings,
        "n_ledgers": len(ledgers),
        "n_valid_ledgers": len(valid_ledgers),
        "n_certificates": len(certs),
        "completion_action": completion_action,
        "action_inference": inference,
        "verified_final_event_hashes": final_hashes,
        "ledger_results": ledgers,
        "certificate_results": certs,
    }
    if accepted:
        write_json(outdir / "updated_campaign_state_v0_1.json", updated_state)
        report["updated_campaign_state_path"] = str(outdir / "updated_campaign_state_v0_1.json")
        report["budget_before"] = campaign_state.get("budget_remaining")
        report["budget_after"] = updated_state.get("budget_remaining")
        report["completed_actions_after"] = updated_state.get("completed_actions")
        report["campaign_event_hash"] = updated_state.get("campaign_event_hash")
    else:
        # Reusing an output folder must not leave an earlier success as this run's state.
        stale_state = outdir / 'updated_campaign_state_v0_1.json'
        if stale_state.exists() and not output_is_input:
            stale_state.unlink()
    write_json(outdir / "TMD_external_submission_acceptance_report_v0_1.json", report)
    # CSV summary
    with open(outdir / "TMD_external_submission_acceptance_summary_v0_1.csv", "w", newline="", encoding="utf-8") as f:
        fieldnames = ["accepted", "completion_action", "budget_before", "budget_after", "campaign_event_hash", "errors", "warnings", "verified_final_event_hashes"]
        w = csv.DictWriter(f, fieldnames=fieldnames); w.writeheader()
        w.writerow({
            "accepted": accepted,
            "completion_action": completion_action or "",
            "budget_before": campaign_state.get("budget_remaining"),
            "budget_after": report.get("budget_after", ""),
            "campaign_event_hash": report.get("campaign_event_hash", ""),
            "errors": json.dumps(acceptance_errors),
            "warnings": json.dumps(warnings),
            "verified_final_event_hashes": json.dumps(final_hashes),
        })
    print(json.dumps({"accepted": accepted, "completion_action": completion_action, "errors": acceptance_errors, "budget_after": report.get("budget_after")}, indent=2))
    return 0 if accepted else 2


if __name__ == "__main__":
    sys.exit(main())
