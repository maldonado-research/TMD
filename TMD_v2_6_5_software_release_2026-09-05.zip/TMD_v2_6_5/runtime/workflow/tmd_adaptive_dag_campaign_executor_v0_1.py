#!/usr/bin/env python3
"""TMD adaptive DAG campaign executor v0.1.

Usage:
  python tmd_adaptive_dag_campaign_executor_v0_1.py --state state.json --outdir out

State JSON fields:
  completed_actions: list[str]
  budget_remaining: int
  runtime_next_action: optional str
  prefer_runtime_when_frontier_equivalent: bool
"""
from __future__ import annotations
import argparse, csv, json, itertools, pathlib

ACTIONS = [
    'H482R_developmental_entry_proxy',
    'S487L_pairwise_competition',
    'WS_new_context_flagship_replication',
    'S487_Asn_homeostasis_perturbation',
    'H482_family_mu_bias_count_assay',
    'S487_mutation_spectrum_assay',
    'Q469_block_exploratory_pairwise',
]
META = {
    'H482R_developmental_entry_proxy': {'cost':5,'score':15},
    'S487L_pairwise_competition': {'cost':5,'score':14},
    'WS_new_context_flagship_replication': {'cost':6,'score':14},
    'S487_Asn_homeostasis_perturbation': {'cost':7,'score':13},
    'H482_family_mu_bias_count_assay': {'cost':8,'score':11},
    'S487_mutation_spectrum_assay': {'cost':7,'score':9},
    'Q469_block_exploratory_pairwise': {'cost':5,'score':7},
}
REQS = {
    'H482R_developmental_entry_proxy': set(),
    'S487L_pairwise_competition': set(),
    'WS_new_context_flagship_replication': set(),
    'S487_Asn_homeostasis_perturbation': {'S487L_pairwise_competition'},
    'H482_family_mu_bias_count_assay': {'H482R_developmental_entry_proxy'},
    'S487_mutation_spectrum_assay': {'S487L_pairwise_competition','S487_Asn_homeostasis_perturbation'},
    'Q469_block_exploratory_pairwise': {'H482R_developmental_entry_proxy','S487L_pairwise_competition'},
}
RUNTIME_MAP = {
    'continue_one_more_primary_pair': 'H482R_developmental_entry_proxy',
    'H482R_developmental_entry_proxy': 'H482R_developmental_entry_proxy',
    'transport_homeostasis_then_counts_300': 'H482_family_mu_bias_count_assay',
    'transport_homeostasis_then_counts_350': 'H482_family_mu_bias_count_assay',
    'H482_family_mu_bias_count_assay': 'H482_family_mu_bias_count_assay',
    'run_mu': 'S487_mutation_spectrum_assay',
    'S487_mutation_spectrum_assay': 'S487_mutation_spectrum_assay',
    'Asn_homeostasis_topup_then_run_mu': 'S487_Asn_homeostasis_perturbation',
    'S487_Asn_homeostasis_perturbation': 'S487_Asn_homeostasis_perturbation',
    'S487L_pairwise_competition': 'S487L_pairwise_competition',
    'sample_next_replicate_in::Pf_WS_routes_v1': 'WS_new_context_flagship_replication',
    'sample_next_replicate_in::Pf5_2021_WspAwsMws': 'WS_new_context_flagship_replication',
    'sample_next_replicate_in::WS_2019_fluct_WspAwsMws': 'WS_new_context_flagship_replication',
    'WS_new_context_flagship_replication': 'WS_new_context_flagship_replication',
    'Q469_block_exploratory_pairwise': 'Q469_block_exploratory_pairwise',
}

def cost(S): return sum(META[a]['cost'] for a in S)
def score(S): return sum(META[a]['score'] for a in S)
def is_ideal(S):
    S=set(S)
    return all(REQS[a].issubset(S) for a in S)
def unlocked(S,B=None):
    S=set(S)
    return [a for a in ACTIONS if a not in S and REQS[a].issubset(S) and (B is None or META[a]['cost']<=B)]
def optimal_completion(S,B):
    S=set(S); rem=[a for a in ACTIONS if a not in S]
    best=(set(),0,0)
    for mask in range(1<<len(rem)):
        T={rem[i] for i in range(len(rem)) if mask>>i & 1}
        U=S|T
        if is_ideal(U) and cost(T)<=B:
            C=cost(T); P=score(T)
            if P>best[2] or (P==best[2] and C<best[1]): best=(T,C,P)
    return best
def first_actions(S,B):
    S=set(S); optT,optC,optP=optimal_completion(S,B)
    vals=[]; first=[]
    for a in unlocked(S,B):
        T,C,P=optimal_completion(S|{a}, B-META[a]['cost'])
        total=META[a]['score']+P
        vals.append({'action':a,'best_score_after_taking':total,'score_gap_to_optimum':optP-total,'on_some_optimal_path':total==optP})
        if total==optP: first.append(a)
    return first, vals, optP, optT, optC

def choose(state):
    S=set(state.get('completed_actions', [])); B=int(state.get('budget_remaining',0)); runtime=state.get('runtime_next_action')
    errors=[]
    if not is_ideal(S): errors.append('completed_actions_not_DAG_feasible')
    first, vals, optP, optT, optC=first_actions(S,B)
    mapped=RUNTIME_MAP.get(runtime) if runtime else None
    recommended=None; reason='default_frontier_tiebreak'
    if state.get('prefer_runtime_when_frontier_equivalent', True) and mapped:
        if mapped in first:
            recommended=mapped; reason='runtime_action_is_DAG_valid_and_frontier_equivalent'
        elif mapped not in ACTIONS: errors.append('runtime_action_not_mapped_to_campaign_action')
        elif mapped in S: errors.append('runtime_action_already_completed')
        elif not REQS[mapped].issubset(S): errors.append('runtime_action_blocked_by_prerequisites')
        elif META[mapped]['cost']>B: errors.append('runtime_action_not_affordable')
        else: errors.append('runtime_action_not_on_optimal_frontier')
    if recommended is None and first:
        recommended=sorted(first, key=lambda a:(-META[a]['score'], META[a]['cost'], ACTIONS.index(a)))[0]
    return {
        'status':'ok' if not errors else 'ok_with_warnings',
        'recommended_action': recommended,
        'reason': reason,
        'runtime_mapped_action': mapped,
        'completed_actions': sorted(S),
        'budget_remaining': B,
        'unlocked_affordable_actions': unlocked(S,B),
        'frontier_equivalent_first_actions': first,
        'optimal_additional_score': optP,
        'optimal_additional_cost': optC,
        'optimal_completion_bundle': sorted(list(optT)),
        'first_action_values': vals,
        'warnings': errors,
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--state', required=True)
    ap.add_argument('--outdir', required=True)
    args=ap.parse_args()
    out=pathlib.Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    state=json.load(open(args.state))
    res=choose(state)
    (out/'adaptive_campaign_executor_output_v0_1.json').write_text(json.dumps(res, indent=2))
    with open(out/'adaptive_campaign_first_action_values_v0_1.csv','w',newline='') as f:
        fieldnames=['action','best_score_after_taking','score_gap_to_optimum','on_some_optimal_path']
        w=csv.DictWriter(f, fieldnames=fieldnames); w.writeheader(); w.writerows(res['first_action_values'])
    print(json.dumps(res, indent=2))
if __name__ == '__main__': main()
