#!/usr/bin/env python3
"""
TMD replay-ledger verifier v0.1

Verifies event-sourced TMD closed-loop ledgers produced by
`tmd_event_sourced_replay_ledger_v0_1.py`.

Checks:
  1. event indices are consecutive
  2. previous_event_hash links are correct
  3. each event_hash equals SHA256(canonical event without event_hash)
  4. final_event_hash equals last event hash
  5. top-level artifact_hashes agree with event payload sha256s
  6. top-level hash_checks are all true, unless --allow-warning
  7. optional filesystem artifact hashes if paths are present

Also emits a Merkle-style campaign certificate over final_event_hash leaves.
"""
from __future__ import annotations

import argparse
import csv
import glob
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple


ARTIFACT_EVENT_MAP = {
    "state_before": "state_before",
    "manifest": "manifest_issued",
    "result_csv": "result_observed",
    "feedback_report": "feedback_reduced",
    "state_after": "state_after",
}


def canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def event_hash(event: Dict[str, Any]) -> str:
    payload = {k: v for k, v in event.items() if k != "event_hash"}
    return sha256_bytes(canonical(payload))


def load_json(path: Path) -> Any:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def save_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=False), encoding="utf-8")


def write_csv(path: Path, rows: List[Dict[str, Any]], fieldnames: List[str]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in fieldnames})


def expand_inputs(patterns: Iterable[str]) -> List[Path]:
    paths: List[Path] = []
    for pat in patterns:
        matches = glob.glob(pat, recursive=True)
        if matches:
            paths.extend(Path(m) for m in matches)
        else:
            paths.append(Path(pat))
    # unique stable sort
    seen = set()
    out = []
    for p in sorted(paths, key=lambda x: str(x)):
        rp = str(p.resolve()) if p.exists() else str(p)
        if rp not in seen:
            seen.add(rp)
            out.append(p)
    return out


def verify_ledger(path: Path, *, check_filesystem: bool = True, allow_warning: bool = False) -> Dict[str, Any]:
    errors: List[str] = []
    warnings: List[str] = []
    ledger = load_json(path)
    events = ledger.get("events", [])
    if not isinstance(events, list) or not events:
        errors.append("events missing or empty")
        events = []

    prev_expected = "GENESIS"
    recomputed_hashes: List[str] = []
    event_type_seen: Dict[str, Dict[str, Any]] = {}
    for i, ev in enumerate(events, start=1):
        if ev.get("index") != i:
            errors.append(f"event {i}: index mismatch, got {ev.get('index')}")
        if ev.get("previous_event_hash") != prev_expected:
            errors.append(
                f"event {i}: previous_event_hash mismatch, got {ev.get('previous_event_hash')}, expected {prev_expected}"
            )
        rh = event_hash(ev)
        recomputed_hashes.append(rh)
        if ev.get("event_hash") != rh:
            errors.append(f"event {i}: event_hash mismatch, got {ev.get('event_hash')}, expected {rh}")
        prev_expected = ev.get("event_hash")
        et = ev.get("event_type")
        if et in event_type_seen:
            warnings.append(f"duplicate event type {et}")
        if et:
            event_type_seen[et] = ev

    final_event_hash = ledger.get("final_event_hash")
    expected_final = events[-1].get("event_hash") if events else None
    if final_event_hash != expected_final:
        errors.append(f"final_event_hash mismatch, got {final_event_hash}, expected {expected_final}")

    # Validate artifact_hashes against event payload hashes.
    artifact_hashes = ledger.get("artifact_hashes", {}) or {}
    for artifact_key, event_type in ARTIFACT_EVENT_MAP.items():
        ev = event_type_seen.get(event_type)
        if ev is None:
            errors.append(f"missing event type {event_type}")
            continue
        payload_hash = (ev.get("payload") or {}).get("sha256")
        top_hash = artifact_hashes.get(artifact_key)
        if payload_hash != top_hash:
            errors.append(f"artifact hash mismatch for {artifact_key}: event {payload_hash}, top-level {top_hash}")

    hash_checks = ledger.get("hash_checks", {}) or {}
    failed_checks = [k for k, v in hash_checks.items() if v is not True]
    if failed_checks and not allow_warning:
        errors.append("top-level hash_checks failed: " + ",".join(failed_checks))
    elif failed_checks:
        warnings.append("top-level hash_checks failed but allowed: " + ",".join(failed_checks))

    # Optional filesystem validation: if referenced file paths exist, compare bytes.
    fs_checked = 0
    fs_missing = 0
    fs_mismatch = 0
    if check_filesystem:
        for artifact_key, event_type in ARTIFACT_EVENT_MAP.items():
            ev = event_type_seen.get(event_type)
            if not ev:
                continue
            payload = ev.get("payload") or {}
            p = payload.get("path")
            expected = payload.get("sha256")
            if not p or not expected:
                continue
            fp = Path(p)
            if not fp.exists():
                fs_missing += 1
                warnings.append(f"filesystem artifact missing for {artifact_key}: {p}")
                continue
            fs_checked += 1
            actual = sha256_file(fp)
            if actual != expected:
                fs_mismatch += 1
                errors.append(f"filesystem hash mismatch for {artifact_key}: {p}")

    status = "valid" if not errors else "invalid"
    return {
        "ledger_path": str(path),
        "run_id": ledger.get("run_id", ""),
        "ledger_version": ledger.get("ledger_version", ""),
        "status": status,
        "errors": errors,
        "warnings": warnings,
        "n_events": len(events),
        "final_event_hash": final_event_hash or "",
        "manifest_branch": ledger.get("manifest_branch", ""),
        "manifest_action": ledger.get("manifest_action", ""),
        "feedback_status": ledger.get("feedback_status", ""),
        "runtime_patch_applied": ledger.get("runtime_patch_applied", ""),
        "filesystem_artifacts_checked": fs_checked,
        "filesystem_artifacts_missing": fs_missing,
        "filesystem_artifacts_mismatch": fs_mismatch,
    }


def merkle_root(leaves: List[str]) -> Tuple[str, List[List[str]]]:
    """Simple deterministic Merkle root over sorted hex leaves.

    If a level has odd length, the final node is duplicated.
    Internal nodes are SHA256(left || right) over ASCII hex strings.
    """
    if not leaves:
        return "", []
    level = sorted(leaves)
    levels = [level]
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), 2):
            left = level[i]
            right = level[i + 1] if i + 1 < len(level) else left
            nxt.append(sha256_bytes((left + right).encode("ascii")))
        level = nxt
        levels.append(level)
    return level[0], levels


def main() -> None:
    ap = argparse.ArgumentParser(description="Verify TMD event-sourced replay ledgers and emit a campaign certificate.")
    ap.add_argument("--ledger", action="append", required=True, help="Ledger JSON path or glob. Can be repeated.")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--no-filesystem-check", action="store_true")
    ap.add_argument("--allow-warning", action="store_true")
    args = ap.parse_args()

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    paths = expand_inputs(args.ledger)
    rows: List[Dict[str, Any]] = []
    for p in paths:
        if not p.exists():
            rows.append({
                "ledger_path": str(p),
                "run_id": "",
                "status": "invalid",
                "errors": ["ledger file missing"],
                "warnings": [],
                "n_events": 0,
                "final_event_hash": "",
                "manifest_branch": "",
                "manifest_action": "",
                "feedback_status": "",
                "runtime_patch_applied": "",
                "filesystem_artifacts_checked": 0,
                "filesystem_artifacts_missing": 0,
                "filesystem_artifacts_mismatch": 0,
            })
            continue
        rows.append(verify_ledger(p, check_filesystem=not args.no_filesystem_check, allow_warning=args.allow_warning))

    valid_rows = [r for r in rows if r["status"] == "valid"]
    leaves = [r["final_event_hash"] for r in valid_rows if r.get("final_event_hash")]
    root, levels = merkle_root(leaves)
    certificate = {
        "certificate_version": "TMD_replay_ledger_verifier_v0_1",
        "n_ledgers": len(rows),
        "n_valid_ledgers": len(valid_rows),
        "n_invalid_ledgers": len(rows) - len(valid_rows),
        "merkle_root_valid_final_event_hashes": root,
        "valid_final_event_hashes_sorted": sorted(leaves),
        "merkle_levels": levels,
        "rows": rows,
    }

    # CSV with compact errors/warnings strings.
    csv_rows = []
    for r in rows:
        cr = dict(r)
        cr["errors"] = " | ".join(r.get("errors", []))
        cr["warnings"] = " | ".join(r.get("warnings", []))
        csv_rows.append(cr)
    fieldnames = [
        "ledger_path", "run_id", "ledger_version", "status", "n_events", "final_event_hash",
        "manifest_branch", "manifest_action", "feedback_status", "runtime_patch_applied",
        "filesystem_artifacts_checked", "filesystem_artifacts_missing", "filesystem_artifacts_mismatch",
        "errors", "warnings",
    ]
    write_csv(outdir / "TMD_replay_ledger_verification_results_v0_1.csv", csv_rows, fieldnames)
    save_json(outdir / "TMD_replay_ledger_campaign_certificate_v0_1.json", certificate)
    print(json.dumps({
        "status": "ok" if certificate["n_invalid_ledgers"] == 0 else "invalid_ledgers_found",
        "n_ledgers": certificate["n_ledgers"],
        "n_valid_ledgers": certificate["n_valid_ledgers"],
        "merkle_root": root,
        "outdir": str(outdir),
    }, indent=2))


if __name__ == "__main__":
    main()
