#!/usr/bin/env python3
"""Portable optimized multi-uncertainty compiled supervisor.
Computes branch-local H482R/S487/WS quantities once, then evaluates all scenario/mode top-level combinations.
"""
import argparse, importlib.util, json, math
from pathlib import Path
PAIRWISE_A_WINDOW_FLOOR=0.416451
DEFAULT_C_H=0.20
DEFAULT_C_L=0.20

def load_json(path):
    with open(path) as f: return json.load(f)
def save_json(path,obj): Path(path).write_text(json.dumps(obj,indent=2))
def import_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def classify_s487_mode(center_bits,halfwidth_bits,floor=PAIRWISE_A_WINDOW_FLOOR):
    low=center_bits-halfwidth_bits; high=center_bits+halfwidth_bits
    if low >= floor-1e-12: return {'status':'certified_A_window','admissible_modes':['A_window'],'lower_edge':low,'upper_edge':high,'floor':floor}
    if high < floor-1e-12: return {'status':'certified_pairwise_band','admissible_modes':['pairwise_band'],'lower_edge':low,'upper_edge':high,'floor':floor}
    return {'status':'ambiguous','admissible_modes':['A_window','pairwise_band'],'lower_edge':low,'upper_edge':high,'floor':floor}

def extra_pairs_to_certify(center_bits,halfwidth_bits,n_pairs,floor=PAIRWISE_A_WINDOW_FLOOR):
    out={'current_center_bits':center_bits,'current_halfwidth_bits':halfwidth_bits,'current_n_pairs':int(n_pairs),'floor_bits':floor,'extra_pairs_for_A_window':None,'extra_pairs_for_pairwise_band':None}
    if center_bits > floor:
        target=center_bits-floor; out['extra_pairs_for_A_window']=int(math.ceil(max(0.0,n_pairs*(halfwidth_bits/target)**2-n_pairs)-1e-12))
    if center_bits < floor:
        target=floor-center_bits; out['extra_pairs_for_pairwise_band']=int(math.ceil(max(0.0,n_pairs*(halfwidth_bits/target)**2-n_pairs)-1e-12))
    return out

def compare_outputs(outputs):
    branch_set={v['summary']['top_level_recommended_branch'] for v in outputs.values()}; action_set={v['summary']['top_level_recommended_action'] for v in outputs.values()}
    return {'same_branch':len(branch_set)==1,'same_action':len(action_set)==1,'branch_set':sorted(branch_set),'action_set':sorted(action_set),'nonblocking':len(branch_set)==1 and len(action_set)==1}

def blocking_axes(outputs,scenarios,modes):
    def BA(rep): return (rep['summary']['top_level_recommended_branch'],rep['summary']['top_level_recommended_action'])
    out={'scenario_blocking':False,'mode_blocking':False}
    for m in modes:
        vals=[BA(outputs[f'{s}::{m}']) for s in scenarios if f'{s}::{m}' in outputs]
        if len(set(vals))>1: out['scenario_blocking']=True
    for s in scenarios:
        vals=[BA(outputs[f'{s}::{m}']) for m in modes if f'{s}::{m}' in outputs]
        if len(set(vals))>1: out['mode_blocking']=True
    return out

def compute_conservative_trigger(state_obj,outputs,delta_h_bound=None):
    incumbent=state_obj.get('top',{}).get('incumbent','H'); c_H=float(state_obj.get('top',{}).get('c_H',DEFAULT_C_H))
    h=float(next(iter(outputs.values()))['H482R_local']['continuation_gain']); common=next(iter(outputs.values()))['summary']['top_level_recommended_branch']
    boundaries={}
    if common=='H':
        for key,out in outputs.items():
            tau=float(out['top_level']['tau']); boundaries[key]={'type':'H_to_low','boundary':tau-c_H/2.0,'low_branch':out['top_level']['recommended_low_branch']}
        cb=max(v['boundary'] for v in boundaries.values()); margin=h-cb; trigger=f'wake when h < {cb:.6f} or any scenario/mode/cost/input summary changes'
    else:
        for key,out in outputs.items():
            tau=float(out['top_level']['tau']); boundaries[key]={'type':'low_to_H','boundary':tau+c_H/2.0,'low_branch':out['top_level']['recommended_low_branch']}
        cb=min(v['boundary'] for v in boundaries.values()); margin=cb-h; trigger=f'wake when h > {cb:.6f} or any scenario/mode/cost/input summary changes'
    res={'incumbent':incumbent,'current_h_gain':h,'common_recommended_branch':common,'conservative_boundary':cb,'conservative_margin':margin,'scenario_mode_boundaries':boundaries,'trigger_rule':trigger}
    if delta_h_bound is not None and delta_h_bound>0:
        k=math.ceil(max(0.0,margin)/delta_h_bound) if margin>0 else 0; res['delta_h_bound']=delta_h_bound; res['safe_updates_before_possible_switch']=max(0,k-1); res['earliest_possible_switch_update']=None if k==0 else k
    return res

def compile_state(state_path,outdir):
    outdir.mkdir(parents=True,exist_ok=True); state=load_json(state_path); state['_base_dir']=str(state_path.parent)
    state.setdefault('top',{}); state['top'].setdefault('c_H',DEFAULT_C_H); state['top'].setdefault('c_L',DEFAULT_C_L); state['top'].setdefault('thresholds_json','TMD_coherent_automaton_thresholds_current_v0_1.json')
    scenarios=list(state['top'].get('scenarios',[])) or [state['top'].get('scenario','narrow_mid')]
    os_mod=import_module(state_path.parent/'tmd_operating_system_v0_1.py','tmd_operating_system_v0_1')
    base=state_path.parent
    thresholds=load_json(base/state['top'].get('thresholds_json','TMD_coherent_automaton_thresholds_current_v0_1.json'))
    Hcfg=load_json(base/state['H482R'].get('params_json','TMD_H482R_generic_threshold_bellman_params_v0_1.json'))
    Scfg=load_json(base/state['S487'].get('params_json','TMD_S487_generic_threshold_params_cost025_v0_1.json'))
    H=os_mod.local_branch_query(Hcfg,float(state['H482R']['center_bits']),float(state['H482R']['halfwidth_bits']),int(state['H482R']['n_current_pairs']),mode=state['H482R'].get('mode','mixture'),dev_pair_cost=float(state['H482R'].get('pair_cost',state['H482R'].get('dev_pair_cost',5.0))),n_max=int(state['H482R'].get('n_max',15)))
    S=os_mod.local_branch_query(Scfg,float(state['S487']['center_bits']),float(state['S487']['halfwidth_bits']),int(state['S487']['n_current_pairs']),mode=state['S487'].get('mode','mixture'),dev_pair_cost=float(state['S487'].get('pair_cost',0.05)),n_max=int(state['S487'].get('n_max',15)))
    WS=os_mod.ws_next_action(state['WS'])
    mode_info=classify_s487_mode(float(state['S487']['center_bits']),float(state['S487']['halfwidth_bits']))
    extra=extra_pairs_to_certify(float(state['S487']['center_bits']),float(state['S487']['halfwidth_bits']),int(state['S487']['n_current_pairs']))
    compiled_states={}; outputs={}
    for scenario in scenarios:
        for mode in mode_info['admissible_modes']:
            st=json.loads(json.dumps(state)); st['top']['scenario']=scenario; st['top']['s487_mode']=mode
            key=f'{scenario}::{mode}'; compiled_states[key]=st
            top=os_mod.coherent_top_level(scenario,mode,state['top'].get('incumbent','H'),H['continuation_gain'],float(state['top'].get('c_H',DEFAULT_C_H)),float(state['top'].get('c_L',DEFAULT_C_L)),thresholds)
            branch=top['recommended_branch']
            if branch=='H': action=H['bellman_action'] if H['bellman_action']!='stop_primary_now' else H['best_stop_action']; local=H
            elif branch=='S487': action=S['bellman_action'] if S['bellman_action']!='stop_primary_now' else S['best_stop_action']; local=S
            else: action=WS['action']; local=WS
            outputs[key]={'summary':{'top_level_recommended_branch':branch,'top_level_recommended_action':action},'top_level':top,'H482R_local':H,'S487_local':S,'WS_local':WS,'chosen_branch_local':local}
    comp=compare_outputs(outputs); axes=blocking_axes(outputs,scenarios,mode_info['admissible_modes'])
    if len(outputs)==1:
        only=next(iter(outputs.values()))['summary']; decision={'status':'fully_certified','recommended_branch':only['top_level_recommended_branch'],'recommended_action':only['top_level_recommended_action'],'action_certificate':'unique under current scenario and S487 mode'}; trigger=compute_conservative_trigger(state,outputs,state.get('top',{}).get('delta_h_bound'))
    elif comp['nonblocking']:
        rep=next(iter(outputs.values()))['summary']; decision={'status':'uncertainty_nonblocking','recommended_branch':rep['top_level_recommended_branch'],'recommended_action':rep['top_level_recommended_action'],'action_certificate':'same across all admissible scenarios and S487 modes'}; trigger=compute_conservative_trigger(state,outputs,state.get('top',{}).get('delta_h_bound'))
    else:
        decision={'status':'uncertainty_blocking','recommended_branch':None,'recommended_action':None,'action_certificate':'blocking; scenario and/or S487-mode uncertainty changes the decision'}; trigger=None
    report={'input_state':str(state_path),'admissible_scenarios':scenarios,'mode_inference':mode_info,'extra_pair_certification':extra,'comparison':comp,'blocking_axes':axes,'decision':decision,'event_trigger':trigger,'compiled_state_files':{},'scenario_mode_output_files':{},'runtime_implementation':'portable_optimized_no_third_party_v0_2'}
    for key,st in compiled_states.items():
        tag=key.replace('::','__'); sp=outdir/f'compiled_state_{tag}.json'; op=outdir/f'operating_output_{tag}.json'
        save_json(sp,st); save_json(op,outputs[key]); report['compiled_state_files'][key]=str(sp); report['scenario_mode_output_files'][key]=str(op)
    save_json(outdir/'multi_uncertainty_compiled_supervisor_report.json',report); return report

def main():
    ap=argparse.ArgumentParser(description='Portable optimized compiled TMD supervisor')
    ap.add_argument('--state',required=True); ap.add_argument('--outdir',required=True); args=ap.parse_args()
    print(json.dumps(compile_state(Path(args.state).resolve(),Path(args.outdir).resolve()),indent=2))
if __name__=='__main__': main()
