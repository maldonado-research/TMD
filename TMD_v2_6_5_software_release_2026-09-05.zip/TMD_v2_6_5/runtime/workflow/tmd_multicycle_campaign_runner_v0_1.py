#!/usr/bin/env python3
"""TMD multi-cycle campaign runner v0.1.

Runs repeated portable TMD full campaign cycles, feeding each cycle's updated raw
state and campaign state into the next cycle. This is a dry-run/simulation tool
for validating that the closed-loop stack can execute a DAG-valid campaign path
for multiple actions, not just one transition.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, subprocess, sys
from pathlib import Path
from typing import Any


def load_json(path: Path) -> Any:
    with open(path, encoding='utf-8') as f:
        return json.load(f)

def save_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=False), encoding='utf-8')

def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text('', encoding='utf-8'); return
    fields=[]
    for r in rows:
        for k in r.keys():
            if k not in fields: fields.append(k)
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for r in rows: w.writerow({k:r.get(k,'') for k in fields})

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda: f.read(1<<20), b''):
            h.update(chunk)
    return h.hexdigest()

def merkle_root(leaves: list[str]) -> tuple[str, list[list[str]]]:
    leaves=sorted([x for x in leaves if x])
    if not leaves:
        return '', []
    levels=[leaves]
    cur=leaves
    while len(cur)>1:
        nxt=[]
        for i in range(0,len(cur),2):
            a=cur[i]
            b=cur[i+1] if i+1<len(cur) else cur[i]
            nxt.append(hashlib.sha256((a+b).encode()).hexdigest())
        levels.append(nxt)
        cur=nxt
    return cur[0], levels

def run_cycle(runner: Path, raw_spec: Path, campaign_state: Path, outdir: Path, run_id: str, allow_warning: bool) -> dict[str, Any]:
    cmd=[sys.executable, '-S', str(runner), '--raw-spec', str(raw_spec), '--campaign-state', str(campaign_state), '--run-id', run_id, '--outdir', str(outdir)]
    if allow_warning:
        cmd.append('--allow-verifier-warning')
    proc=subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(f'Cycle {run_id} failed with return code {proc.returncode}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}')
    summary_path=outdir/'full_campaign_cycle_summary_v0_3_portable_wsfix.json'
    if not summary_path.exists():
        # tolerate older summary name if user swaps runner
        alt=outdir/'full_campaign_cycle_summary_v0_2_portable.json'
        if alt.exists(): summary_path=alt
        else: raise FileNotFoundError(f'No full-cycle summary found in {outdir}')
    s=load_json(summary_path)
    s['_summary_path']=str(summary_path)
    return s

def main() -> None:
    ap=argparse.ArgumentParser(description='Run multiple dry-run TMD campaign cycles using the portable v0.3 WS-safe runner.')
    ap.add_argument('--raw-spec', required=True)
    ap.add_argument('--campaign-state', required=True)
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--max-cycles', type=int, default=8)
    ap.add_argument('--run-prefix', default='TMD_MULTICYCLE')
    ap.add_argument('--stop-when-no-next-bundle', action='store_true', default=True)
    ap.add_argument('--allow-verifier-warning', action='store_true', default=True)
    args=ap.parse_args()

    outdir=Path(args.outdir).resolve(); outdir.mkdir(parents=True, exist_ok=True)
    script_dir=Path(__file__).resolve().parent
    runner=script_dir/'tmd_full_campaign_cycle_runner_v0_3_portable_wsfix.py'
    raw_spec=Path(args.raw_spec).resolve()
    campaign_state=Path(args.campaign_state).resolve()
    rows=[]; final_hashes=[]; cycle_summaries=[]

    for i in range(1, args.max_cycles+1):
        cyc_dir=outdir/f'cycle_{i:02d}'
        run_id=f'{args.run_prefix}_{i:03d}'
        s=run_cycle(runner, raw_spec, campaign_state, cyc_dir, run_id, args.allow_verifier_warning)
        cycle_summaries.append(s)
        final_hash=s.get('final_event_hash')
        if final_hash: final_hashes.append(final_hash)
        rows.append({
            'cycle': i,
            'run_id': run_id,
            'completed_action': s.get('completed_action'),
            'budget_before': s.get('budget_before'),
            'budget_after': s.get('budget_after'),
            'runtime_original_action': s.get('runtime_original_action'),
            'runtime_action_used_for_campaign': s.get('runtime_action_used_for_campaign'),
            'campaign_recommended_action': s.get('campaign_recommended_action'),
            'manifest_status': s.get('manifest_status'),
            'feedback_status': s.get('feedback_status'),
            'campaign_update_status': s.get('campaign_update_status'),
            'next_optimal_completion_bundle': ' | '.join(s.get('next_optimal_completion_bundle') or []),
            'final_event_hash': final_hash,
            'cycle_summary_path': s.get('_summary_path'),
        })
        raw_spec=Path(s['updated_raw_spec']).resolve()
        campaign_state=Path(s['updated_campaign_state']).resolve()
        if args.stop_when_no_next_bundle and not (s.get('next_optimal_completion_bundle') or []):
            break

    root, levels=merkle_root(final_hashes)
    write_csv(outdir/'TMD_multicycle_campaign_summary_v0_1.csv', rows)
    cert={
        'certificate_version':'TMD_multicycle_campaign_runner_v0_1',
        'n_cycles':len(rows),
        'cycle_completed_actions':[r['completed_action'] for r in rows],
        'final_budget_after': rows[-1]['budget_after'] if rows else None,
        'final_event_hashes_sorted': sorted(final_hashes),
        'campaign_merkle_root': root,
        'merkle_levels': levels,
        'initial_raw_spec_sha256': sha256_file(Path(args.raw_spec).resolve()),
        'initial_campaign_state_sha256': sha256_file(Path(args.campaign_state).resolve()),
        'final_raw_spec': str(raw_spec),
        'final_campaign_state': str(campaign_state),
        'notes':'Dry-run multi-cycle campaign certificate. Final event hashes are from per-cycle replay ledgers.',
    }
    save_json(outdir/'TMD_multicycle_campaign_certificate_v0_1.json', cert)
    print(json.dumps({'status':'ok','n_cycles':len(rows),'completed_actions':cert['cycle_completed_actions'],'final_budget_after':cert['final_budget_after'],'campaign_merkle_root':root,'summary_csv':str(outdir/'TMD_multicycle_campaign_summary_v0_1.csv'),'certificate_json':str(outdir/'TMD_multicycle_campaign_certificate_v0_1.json')}, indent=2))

if __name__=='__main__':
    main()
