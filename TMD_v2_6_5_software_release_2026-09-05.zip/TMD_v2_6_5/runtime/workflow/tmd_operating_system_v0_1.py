#!/usr/bin/env python3
"""TMD Operating System v0.1-portable.
Pure-Python drop-in replacement for the current-stack operating system.
Avoids numpy/pandas/scipy so the campaign cycle can run in lightweight external lab environments.
"""
import argparse, csv, json, math
from pathlib import Path

DEFAULT_WS_GAINS={"Pf_WS_routes_v1":0.080756,"SBW25_WS_2009":0.080756,"Pf5_2021_WspAwsMws":0.034010,"WS_2019_fluct_WspAwsMws":0.008810}

def load_json(path):
    with open(path) as f: return json.load(f)
def frange(start, stop, step):
    vals=[]; x=start
    while x < stop - 1e-12:
        vals.append(round(x,6)); x += step
    return vals
def interp1(xg,y,x):
    if x <= xg[0]: return y[0]
    if x >= xg[-1]: return y[-1]
    lo,hi=0,len(xg)-1
    while hi-lo>1:
        mid=(lo+hi)//2
        if xg[mid] <= x: lo=mid
        else: hi=mid
    w=(x-xg[lo])/(xg[lo+1]-xg[lo])
    return (1-w)*y[lo]+w*y[lo+1]
def interp_h(hg, table, h):
    if h <= hg[0]: return table[0]
    if h >= hg[-1]: return table[-1]
    lo,hi=0,len(hg)-1
    while hi-lo>1:
        mid=(lo+hi)//2
        if hg[mid] <= h: lo=mid
        else: hi=mid
    w=(h-hg[lo])/(hg[lo+1]-hg[lo])
    return [(1-w)*a+w*b for a,b in zip(table[lo],table[lo+1])]
def norm_cdf(x): return 0.5*(1.0+math.erf(x/math.sqrt(2.0)))
def normal_bins():
    edges=[-10,-3,-2.5,-2,-1.5,-1,-0.5,0,0.5,1,1.5,2,2.5,3,10]
    mids=[-3.5,-2.75,-2.25,-1.75,-1.25,-0.75,-0.25,0.25,0.75,1.25,1.75,2.25,2.75,3.5]
    ws=[norm_cdf(edges[i+1])-norm_cdf(edges[i]) for i in range(len(mids))]
    s=sum(ws); return mids,[w/s for w in ws]
Z_MIDS,Z_WEIGHTS=normal_bins()

def _mixture_prior(priors):
    if 'mixture' in priors: return {float(k):float(v) for k,v in priors['mixture'].items()}
    names=[k for k in priors if k!='mixture']; mix={}
    if not names: return mix
    w=1/len(names)
    for s in names:
        for t,p in priors[s].items(): mix[float(t)]=mix.get(float(t),0)+w*float(p)
    return mix

def direct_action_cost(A,ths,costs,fallback):
    for th,c in zip(ths,costs):
        if A >= float(th)-1e-12: return float(c)
    return float(fallback)
def direct_action_label(A,ths,costs,fallback,branch_name='generic'):
    name=branch_name.lower()
    if name.startswith('h482r'): labels=['counts_250','counts_300','counts_350']; fb='counts_399'
    elif name.startswith('s487'): labels=['run_mu']; fb='run_mu'
    else: labels=[f'threshold_{i}' for i in range(len(costs))]; fb='fallback'
    for i,(th,_c) in enumerate(zip(ths,costs)):
        if A >= float(th)-1e-12: return labels[i] if i<len(labels) else f'threshold_{i}'
    return fb

def expected_aux_cost_and_label(A,assay,mode,ths,costs,fallback,branch_name='generic'):
    priors=assay['priors']; label=f"{assay['name']}_then_"+direct_action_label(A,ths,costs,fallback,branch_name)
    if mode=='none': return None
    if mode=='robust':
        futures=[]
        for scen,prior in priors.items():
            if scen=='mixture': continue
            futures.append(sum(float(p)*direct_action_cost(A+float(assay['alignment'])*float(t),ths,costs,fallback) for t,p in prior.items()))
        if not futures:
            prior=_mixture_prior(priors)
            futures=[sum(float(p)*direct_action_cost(A+float(assay['alignment'])*float(t),ths,costs,fallback) for t,p in prior.items())]
        return float(assay['cost'])+max(futures), label
    prior=_mixture_prior(priors) if mode=='mixture' else {float(k):float(v) for k,v in priors[mode].items()}
    future=sum(float(p)*direct_action_cost(A+float(assay['alignment'])*float(t),ths,costs,fallback) for t,p in prior.items())
    return float(assay['cost'])+future, label

def stop_bundle(dhat,h,config,mode='mixture'):
    A=float(config['lambda_primary'])*(float(dhat)-float(h)); choices=[]
    ths=config['thresholds_aligned_bits']; costs=config['threshold_action_costs']; fb=config['fallback_action_cost']; name=config.get('name','generic')
    choices.append((direct_action_cost(A,ths,costs,fb),direct_action_label(A,ths,costs,fb,name),A))
    if mode!='none':
        for assay in config.get('optional_assays',[]):
            c=expected_aux_cost_and_label(A,assay,mode,ths,costs,fb,name)
            if c is not None: choices.append((c[0],c[1],A))
    choices.sort(key=lambda x:x[0])
    return {'aligned_lower_bits':A,'best_stop_cost':float(choices[0][0]),'best_stop_action':choices[0][1],'all_choices':[{'cost':float(c),'action':a} for c,a,_ in choices]}

def build_tables(config,mode='mixture',dev_pair_cost=5.0,n_max=15,d_min=0.10,d_max=0.451,d_step=0.02,h_min=0.01,h_max=0.121,h_step=0.02):
    dg=frange(d_min,d_max,d_step); hg=frange(h_min,h_max,h_step)
    D=[None]*(n_max+2)
    for n in range(n_max+2): D[n]=[[stop_bundle(d,h,config,mode)['best_stop_cost'] for d in dg] for h in hg]
    V=[None]*(n_max+2); P=[None]*(n_max+2); V[n_max+1]=[row[:] for row in D[n_max+1]]; P[n_max+1]=[[0 for _ in dg] for _ in hg]
    for n in range(n_max,0,-1):
        Vn=[]; Pn=[]
        for hi,h in enumerate(hg):
            hp=h*math.sqrt(n/(n+1.0)); sd=h/(1.96*math.sqrt(n+1.0)); J=interp_h(hg,V[n+1],hp)
            Vr=[]; Pr=[]
            for d,stop in zip(dg,D[n][hi]):
                exp=sum(w*interp1(dg,J,d+sd*z) for z,w in zip(Z_MIDS,Z_WEIGHTS))
                cont=float(dev_pair_cost)+exp
                if cont < stop-1e-12: Vr.append(cont); Pr.append(1)
                else: Vr.append(stop); Pr.append(0)
            Vn.append(Vr); Pn.append(Pr)
        V[n]=Vn; P[n]=Pn
    return dg,hg,V,P,D

def local_branch_query(config,center,halfwidth,n_current_pairs,mode='mixture',dev_pair_cost=5.0,n_max=15):
    dg,hg,V,P,D=build_tables(config,mode=mode,dev_pair_cost=dev_pair_cost,n_max=n_max)
    n=int(n_current_pairs); J=interp_h(hg,V[n],halfwidth); Pr=interp_h(hg,[[float(x) for x in row] for row in P[n]],halfwidth); St=interp_h(hg,D[n],halfwidth)
    bell=float(interp1(dg,J,center)); stop=float(interp1(dg,St,center)); cont=float(interp1(dg,Pr,center))>=0.5
    gamma=max(0.0,stop-bell); st=stop_bundle(center,halfwidth,config,mode)
    return {'target_name':config.get('name','unnamed'),'center_bits':center,'halfwidth_bits':halfwidth,'n_current_pairs':int(n_current_pairs),'mode':mode,'pair_cost':float(dev_pair_cost),'bellman_action':'continue_one_more_primary_pair' if cont else 'stop_primary_now','bellman_cost':bell,'stop_cost':stop,'continuation_gain':gamma,'best_stop_action':st['best_stop_action'],'aligned_lower_bits':st['aligned_lower_bits'],'stop_choices':st['all_choices']}

def read_counts_csv(path):
    with open(path,newline='') as f: return list(csv.DictReader(f))
def probs_from_counts_rows(rows):
    ctxs=[]; routes=[]; table={}
    for r in rows:
        c=r['context']; rt=r['route']; val=float(r.get('count',0))
        if c not in ctxs: ctxs.append(c)
        if rt not in routes: routes.append(rt)
        table[(c,rt)]=table.get((c,rt),0)+val
    counts=[]; P=[]
    for c in ctxs:
        vals=[table.get((c,rt),0) for rt in routes]; total=sum(vals); counts.append(total); P.append([v/total if total>0 else 0 for v in vals])
    return ctxs,routes,counts,P
def context_bits(pi,P):
    K=len(P[0]) if P else 0; m=[sum(pi[c]*P[c][i] for c in range(len(pi))) for i in range(K)]; val=0
    for c,p in enumerate(P):
        for i,px in enumerate(p):
            if px>0 and m[i]>0: val += pi[c]*px*math.log2(px/m[i])
    return val
def total_context_bits(counts,P):
    N=sum(counts); pi=[c/N for c in counts] if N>0 else [0 for _ in counts]; return N*context_bits(pi,P) if N>0 else 0
def one_step_gain(counts,P,c):
    new=counts[:]; new[c]+=1; return total_context_bits(new,P)-total_context_bits(counts,P)
def ws_next_action(ws_state):
    if ws_state.get('counts_csv'):
        ctxs,routes,counts,P=probs_from_counts_rows(read_counts_csv(ws_state['counts_csv'])); gains={ctxs[i]:one_step_gain(counts,P,i) for i in range(len(ctxs))}
    else:
        gains={k:float(v) for k,v in ws_state.get('default_current_gains_bits',DEFAULT_WS_GAINS).items()}
    best=max(gains.items(),key=lambda kv:kv[1]); return {'action':f'sample_next_replicate_in::{best[0]}','context_gains_bits':gains,'best_gain_bits':float(best[1])}

def coherent_top_level(scenario,s487_mode,incumbent,h_gain,c_H,c_L,thresholds):
    mode_key='A_window' if s487_mode.lower().startswith('a') else 'pairwise_band'; block=thresholds[scenario][mode_key]
    tau=float(block['tau']); gamma=float(block['gamma']); low=block['low_branch']; cur=incumbent; trans=[]
    if cur=='H':
        if h_gain < tau-c_H/2: cur=low; trans.append(f'H -> {low} (h below tau-c_H/2)')
    elif cur in ('WS','S487'):
        if cur!=low and c_L<gamma: trans.append(f'{cur} -> {low} (low-branch coherence)'); cur=low
        if cur==low and h_gain > tau+c_H/2: trans.append(f'{low} -> H (h above tau+c_H/2)'); cur='H'
        elif cur!=low and h_gain > tau+c_H/2: trans.append(f'{cur} -> H (incumbent wrong low branch and h above tau+c_H/2)'); cur='H'
    else: raise ValueError('incumbent must be H, WS, or S487')
    return {'scenario':scenario,'s487_mode':mode_key,'tau':tau,'gamma':gamma,'h_gain':float(h_gain),'c_H':float(c_H),'c_L':float(c_L),'incumbent':incumbent,'recommended_branch':cur,'recommended_low_branch':low,'decision_margin':2*abs(float(h_gain)-tau),'transitions':trans}

def main():
    ap=argparse.ArgumentParser(description='Portable pure-Python TMD Operating System')
    ap.add_argument('--state',required=True); ap.add_argument('--out',default=None); args=ap.parse_args()
    state=load_json(args.state); base=Path(args.state).resolve().parent
    thresholds=load_json(base/state.get('top',{}).get('thresholds_json','TMD_coherent_automaton_thresholds_current_v0_1.json'))
    Hcfg=load_json(base/state['H482R'].get('params_json','TMD_H482R_generic_threshold_bellman_params_v0_1.json')); Scfg=load_json(base/state['S487'].get('params_json','TMD_S487_generic_threshold_params_cost025_v0_1.json'))
    H=local_branch_query(Hcfg,float(state['H482R']['center_bits']),float(state['H482R']['halfwidth_bits']),int(state['H482R']['n_current_pairs']),mode=state['H482R'].get('mode','mixture'),dev_pair_cost=float(state['H482R'].get('pair_cost',state['H482R'].get('dev_pair_cost',5.0))),n_max=int(state['H482R'].get('n_max',15)))
    S=local_branch_query(Scfg,float(state['S487']['center_bits']),float(state['S487']['halfwidth_bits']),int(state['S487']['n_current_pairs']),mode=state['S487'].get('mode','mixture'),dev_pair_cost=float(state['S487'].get('pair_cost',0.05)),n_max=int(state['S487'].get('n_max',15)))
    WS=ws_next_action(state['WS'])
    top=coherent_top_level(state['top'].get('scenario','narrow_mid'),state['top'].get('s487_mode','pairwise_band'),state['top'].get('incumbent','H'),H['continuation_gain'],float(state['top'].get('c_H',0)),float(state['top'].get('c_L',0)),thresholds)
    branch=top['recommended_branch']
    if branch=='H': action=H['bellman_action'] if H['bellman_action']!='stop_primary_now' else H['best_stop_action']; local=H
    elif branch=='S487': action=S['bellman_action'] if S['bellman_action']!='stop_primary_now' else S['best_stop_action']; local=S
    else: action=WS['action']; local=WS
    out={'summary':{'top_level_recommended_branch':branch,'top_level_recommended_action':action,'notes':'Portable pure-Python TMD operating system result.'},'top_level':top,'H482R_local':H,'S487_local':S,'WS_local':WS,'chosen_branch_local':local,'runtime_implementation':'portable_pure_python_v0_2'}
    txt=json.dumps(out,indent=2)
    if args.out: Path(args.out).write_text(txt)
    else: print(txt)
if __name__=='__main__': main()
