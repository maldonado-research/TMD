#!/usr/bin/env python3
"""Portable raw-input compiled supervisor v0.2.
Pure-Python replacement: no scipy/numpy/pandas imports.
"""
import argparse, csv, importlib.util, json, math
from pathlib import Path
DEFAULT_WS_GAINS={"Pf_WS_routes_v1":0.080756,"SBW25_WS_2009":0.080756,"Pf5_2021_WspAwsMws":0.034010,"WS_2019_fluct_WspAwsMws":0.008810}
SUPERVISOR_DEPS=['tmd_operating_system_v0_1.py','tmd_multi_uncertainty_compiled_supervisor_v0_1.py','TMD_H482R_generic_threshold_bellman_params_v0_1.json','TMD_S487_generic_threshold_params_cost025_v0_1.json','TMD_coherent_automaton_thresholds_current_v0_1.json']
def load_json(path):
    with open(path) as f: return json.load(f)
def save_json(path,obj): Path(path).write_text(json.dumps(obj,indent=2))
def import_module(script_path,name):
    spec=importlib.util.spec_from_file_location(name,script_path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def _log2(x):
    if x<=0: raise ValueError(f'Factor must be >0, got {x}')
    return math.log2(float(x))
def ratio_csv_to_bits(csv_path):
    rows=list(csv.DictReader(open(csv_path))); row=rows[0]
    lo=_log2(float(row['factor_low'])); mid=_log2(float(row['factor_base'])); hi=_log2(float(row['factor_high']))
    return {'source':'ratio_csv','assay_id':row.get('assay_id',csv_path.stem),'center_bits':mid,'halfwidth_bits':max(mid-lo,hi-mid),'lower_bits':lo,'upper_bits':hi}
def _wilson_interval(k,n,z=1.96):
    if n<=0: raise ValueError('n must be positive')
    phat=k/n; denom=1+z*z/n; center=(phat+z*z/(2*n))/denom; half=(z*math.sqrt((phat*(1-phat)+z*z/(4*n))/n))/denom
    return max(1e-12,center-half),min(1-1e-12,center+half)
def count_csv_to_bits(csv_path):
    rows=list(csv.DictReader(open(csv_path))); row=rows[0]
    a=float(row.get('alpha',0.5)); b=float(row.get('beta',0.5)); ns=float(row['num_success']); nt=float(row['num_total']); ds=float(row['den_success']); dt=float(row['den_total'])
    p_num_mid=(ns+a)/(nt+a+b); p_den_mid=(ds+a)/(dt+a+b)
    p_num_low,p_num_hi=_wilson_interval(ns,nt); p_den_low,p_den_hi=_wilson_interval(ds,dt)
    lo=_log2(p_num_low/p_den_hi); mid=_log2(p_num_mid/p_den_mid); hi=_log2(p_num_hi/p_den_low)
    return {'source':'count_csv','assay_id':row.get('assay_id',csv_path.stem),'center_bits':mid,'halfwidth_bits':max(mid-lo,hi-mid),'lower_bits':lo,'upper_bits':hi,'smoothed_ratio':p_num_mid/p_den_mid,'interval_method':'wilson_portable_no_scipy'}
def resolve_assay_summary(branch_cfg,base_dir):
    mode=branch_cfg.get('input_mode','direct')
    if mode=='direct':
        c=float(branch_cfg['center_bits']); h=float(branch_cfg['halfwidth_bits']); return {'source':'direct','center_bits':c,'halfwidth_bits':h,'lower_bits':c-h,'upper_bits':c+h}
    if mode=='ratio_csv': return ratio_csv_to_bits((base_dir/branch_cfg['ratio_csv']).resolve())
    if mode=='count_csv': return count_csv_to_bits((base_dir/branch_cfg['count_csv']).resolve())
    raise ValueError(f'Unknown input_mode {mode}')
def compile_raw_state(spec_path,outdir):
    outdir.mkdir(parents=True,exist_ok=True); spec=load_json(spec_path); base_dir=spec_path.parent
    Hsum=resolve_assay_summary(spec['H482R'],base_dir); Ssum=resolve_assay_summary(spec['S487'],base_dir)
    rec_costs_path=(base_dir/spec.get('recommended_costs_json','TMD_recommended_switch_costs_current_v0_1.json')).resolve(); costs=load_json(rec_costs_path) if rec_costs_path.exists() else {}
    c_H=float(spec.get('top',{}).get('c_H',costs.get('c_H_recommended',0.2))); c_L=float(spec.get('top',{}).get('c_L',costs.get('c_L_recommended',0.2)))
    ws_counts=spec.get('WS',{}).get('counts_csv'); ws_counts_abs=str((base_dir/ws_counts).resolve()) if ws_counts else None
    state={'top':{'scenarios':spec.get('top',{}).get('scenarios',['narrow_mid','wide_mid']),'incumbent':spec.get('top',{}).get('incumbent','H'),'c_H':c_H,'c_L':c_L,'delta_h_bound':spec.get('top',{}).get('delta_h_bound',0.10),'thresholds_json':spec.get('top',{}).get('thresholds_json','TMD_coherent_automaton_thresholds_current_v0_1.json')},'H482R':{'center_bits':Hsum['center_bits'],'halfwidth_bits':Hsum['halfwidth_bits'],'n_current_pairs':int(spec['H482R'].get('n_current_pairs',4)),'mode':spec['H482R'].get('mode','mixture'),'pair_cost':float(spec['H482R'].get('pair_cost',5.0)),'n_max':int(spec['H482R'].get('n_max',15)),'params_json':spec['H482R'].get('params_json','TMD_H482R_generic_threshold_bellman_params_v0_1.json')},'S487':{'center_bits':Ssum['center_bits'],'halfwidth_bits':Ssum['halfwidth_bits'],'n_current_pairs':int(spec['S487'].get('n_current_pairs',4)),'mode':spec['S487'].get('mode','mixture'),'pair_cost':float(spec['S487'].get('pair_cost',0.05)),'n_max':int(spec['S487'].get('n_max',15)),'params_json':spec['S487'].get('params_json','TMD_S487_generic_threshold_params_cost025_v0_1.json')},'WS':{'counts_csv':ws_counts_abs,'default_current_gains_bits':spec.get('WS',{}).get('default_current_gains_bits',DEFAULT_WS_GAINS)}}
    state_path=outdir/'compiled_state_input_v0_2.json'; save_json(state_path,state)
    for fname in SUPERVISOR_DEPS:
        src=(base_dir/fname).resolve(); dst=outdir/src.name
        if src.exists() and not dst.exists(): dst.write_text(src.read_text())
    if rec_costs_path.exists():
        dst=outdir/rec_costs_path.name
        if not dst.exists(): dst.write_text(rec_costs_path.read_text())
    sup_mod=import_module(outdir/'tmd_multi_uncertainty_compiled_supervisor_v0_1.py','tmd_multi_uncertainty_compiled_supervisor_v0_1')
    report=sup_mod.compile_state(state_path,outdir/'multi_uncertainty_supervisor_run')
    final={'input_spec':str(spec_path),'resolved_assay_summaries':{'H482R':Hsum,'S487':Ssum},'compiled_state_path':str(state_path),'multi_uncertainty_supervisor_report_path':str((outdir/'multi_uncertainty_supervisor_run'/'multi_uncertainty_compiled_supervisor_report.json')),'decision_summary':report['decision'],'admissible_scenarios':report['admissible_scenarios'],'mode_inference':report['mode_inference'],'event_trigger':report.get('event_trigger'),'extra_pair_certification':report['extra_pair_certification'],'runtime_implementation':'portable_no_third_party_v0_2'}
    save_json(outdir/'raw_compiler_summary_v0_2.json',final); return final
def main():
    ap=argparse.ArgumentParser(description='Portable raw-input compiler for TMD supervisor')
    ap.add_argument('--spec',required=True); ap.add_argument('--outdir',required=True)
    args=ap.parse_args(); print(json.dumps(compile_raw_state(Path(args.spec).resolve(),Path(args.outdir).resolve()),indent=2))
if __name__=='__main__': main()
