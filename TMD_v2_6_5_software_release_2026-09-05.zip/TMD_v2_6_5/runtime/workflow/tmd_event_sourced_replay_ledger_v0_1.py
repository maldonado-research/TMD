#!/usr/bin/env python3
"""
TMD event-sourced replay ledger v0.1

Build a tamper-evident ledger for one TMD closed-loop update:
  raw state -> next-step manifest -> result file -> feedback reduction -> updated raw state.

The script does not rerun the scientific controller. It audits a completed transition
using hashes, the feedback report, and a minimal JSON diff of state_before vs state_after.
"""
import argparse
import hashlib
import json
import csv
from pathlib import Path
from typing import Any, Dict, List


def canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path) -> Any:
    with open(path) as f:
        return json.load(f)


def read_csv_rows(path: Path) -> List[Dict[str, str]]:
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def save_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=False), encoding="utf-8")


def write_csv(path: Path, rows: List[Dict[str, Any]], fieldnames: List[str]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in fieldnames})


def get_by_pointer(obj: Any, pointer: str) -> Any:
    if pointer in ("", "/"):
        return obj
    cur = obj
    for raw in pointer.strip("/").split("/"):
        key = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(cur, list):
            cur = cur[int(key)]
        else:
            cur = cur[key]
    return cur


def json_diff(before: Any, after: Any, path: str = "") -> List[Dict[str, Any]]:
    """Small, readable JSON diff. Values are embedded only when scalar/small."""
    diffs: List[Dict[str, Any]] = []
    if isinstance(before, dict) and isinstance(after, dict):
        keys = sorted(set(before) | set(after))
        for k in keys:
            p = f"{path}/{k}" if path else f"/{k}"
            if k not in before:
                diffs.append({"op": "add", "path": p, "after": after[k]})
            elif k not in after:
                diffs.append({"op": "remove", "path": p, "before": before[k]})
            else:
                diffs.extend(json_diff(before[k], after[k], p))
    elif isinstance(before, list) and isinstance(after, list):
        if before != after:
            diffs.append({"op": "replace", "path": path or "/", "before": before, "after": after})
    else:
        if before != after:
            diffs.append({"op": "replace", "path": path or "/", "before": before, "after": after})
    return diffs


def short_diff_summary(diffs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for d in diffs:
        row = {"op": d.get("op"), "path": d.get("path")}
        before = d.get("before")
        after = d.get("after")
        # Keep scalars and short strings readable; compress large objects.
        def compact(x):
            if isinstance(x, (int, float, str, bool)) or x is None:
                return x
            s = json.dumps(x, sort_keys=True)
            return s if len(s) < 180 else f"<{type(x).__name__}, {len(s)} json chars>"
        if "before" in d:
            row["before"] = compact(before)
        if "after" in d:
            row["after"] = compact(after)
        out.append(row)
    return out


def event_hash(event: Dict[str, Any]) -> str:
    payload = {k: v for k, v in event.items() if k != "event_hash"}
    return sha256_bytes(canonical(payload))


def append_event(events: List[Dict[str, Any]], event_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    prev = events[-1]["event_hash"] if events else "GENESIS"
    event = {
        "index": len(events) + 1,
        "event_type": event_type,
        "previous_event_hash": prev,
        "payload": payload,
    }
    event["event_hash"] = event_hash(event)
    events.append(event)
    return event


def build_ledger(args: argparse.Namespace) -> Dict[str, Any]:
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    state_before = Path(args.state_before).resolve()
    manifest = Path(args.manifest).resolve()
    result_csv = Path(args.result_csv).resolve()
    feedback_report = Path(args.feedback_report).resolve()
    feedback = load_json(feedback_report)
    state_after = Path(args.state_after).resolve() if args.state_after else Path(feedback.get("updated_raw_input_spec", "")).resolve()

    hashes = {
        "state_before": sha256_file(state_before),
        "manifest": sha256_file(manifest),
        "result_csv": sha256_file(result_csv),
        "feedback_report": sha256_file(feedback_report),
        "state_after": sha256_file(state_after) if state_after.exists() else None,
    }
    feedback_input_hashes = feedback.get("sha256", {})
    hash_checks = {
        "state_before_matches_feedback_spec": feedback_input_hashes.get("spec") == hashes["state_before"],
        "manifest_matches_feedback": feedback_input_hashes.get("manifest") == hashes["manifest"],
        "result_matches_feedback": feedback_input_hashes.get("result_csv") == hashes["result_csv"],
        "state_after_exists": state_after.exists(),
    }

    before_obj = load_json(state_before)
    after_obj = load_json(state_after) if state_after.exists() else None
    diffs = json_diff(before_obj, after_obj) if after_obj is not None else []
    diff_summary = short_diff_summary(diffs)

    manifest_obj = load_json(manifest)
    result_rows = read_csv_rows(result_csv)

    events: List[Dict[str, Any]] = []
    append_event(events, "state_before", {
        "path": str(state_before),
        "sha256": hashes["state_before"],
        "state_keys": sorted(before_obj.keys()) if isinstance(before_obj, dict) else None,
    })
    append_event(events, "manifest_issued", {
        "path": str(manifest),
        "sha256": hashes["manifest"],
        "recommended_branch": manifest_obj.get("recommended_branch"),
        "recommended_action": manifest_obj.get("recommended_action"),
        "n_stages": len(manifest_obj.get("stages", [])),
    })
    append_event(events, "result_observed", {
        "path": str(result_csv),
        "sha256": hashes["result_csv"],
        "n_rows": len(result_rows),
        "columns": list(result_rows[0].keys()) if result_rows else [],
    })
    append_event(events, "feedback_reduced", {
        "path": str(feedback_report),
        "sha256": hashes["feedback_report"],
        "status": feedback.get("status"),
        "reduced_summary": feedback.get("reduced_summary"),
        "patch_report": feedback.get("patch_report"),
    })
    append_event(events, "state_after", {
        "path": str(state_after),
        "sha256": hashes["state_after"],
        "n_diff_entries": len(diffs),
        "diff_summary": diff_summary,
    })

    ledger = {
        "ledger_version": "TMD_event_sourced_replay_ledger_v0_1",
        "run_id": args.run_id,
        "status": "valid" if all(hash_checks.values()) else "warning_hash_or_state_check_failed",
        "artifact_hashes": hashes,
        "hash_checks": hash_checks,
        "manifest_action": manifest_obj.get("recommended_action"),
        "manifest_branch": manifest_obj.get("recommended_branch"),
        "feedback_status": feedback.get("status"),
        "runtime_patch_applied": feedback.get("patch_report", {}).get("runtime_patch_applied"),
        "state_diff_summary": diff_summary,
        "events": events,
        "final_event_hash": events[-1]["event_hash"],
        "replay_instruction": "Verify all artifact hashes, then replay events in index order. The final_event_hash commits to the full transition.",
    }
    return ledger


def main() -> None:
    ap = argparse.ArgumentParser(description="Build a hash-chained TMD replay ledger for one closed-loop transition.")
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--state-before", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--result-csv", required=True)
    ap.add_argument("--feedback-report", required=True)
    ap.add_argument("--state-after", default=None)
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()

    ledger = build_ledger(args)
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    json_path = outdir / f"{args.run_id}_event_sourced_replay_ledger_v0_1.json"
    save_json(json_path, ledger)
    rows = []
    for ev in ledger["events"]:
        rows.append({
            "run_id": args.run_id,
            "index": ev["index"],
            "event_type": ev["event_type"],
            "previous_event_hash": ev["previous_event_hash"],
            "event_hash": ev["event_hash"],
        })
    write_csv(outdir / f"{args.run_id}_event_chain_v0_1.csv", rows, ["run_id", "index", "event_type", "previous_event_hash", "event_hash"])
    print(json.dumps({"status": ledger["status"], "ledger_json": str(json_path), "final_event_hash": ledger["final_event_hash"]}, indent=2))


if __name__ == "__main__":
    main()
