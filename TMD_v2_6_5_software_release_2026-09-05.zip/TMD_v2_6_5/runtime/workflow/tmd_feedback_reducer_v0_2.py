#!/usr/bin/env python3
"""
TMD feedback reducer v0.1

Purpose
-------
Close the loop between a TMD next-step manifest and the raw-input supervisor.
Given:
  - a current raw-input spec JSON,
  - a next-step manifest JSON,
  - one filled result CSV for a manifest stage,
this script validates the result schema, reduces the raw result to a minimal
bit/count summary, patches the raw-input spec where the current runtime can use it,
and writes a provenance-rich update report.

This is deliberately conservative: when a manifest stage produces a component
summary not yet consumed by the current runtime (e.g. a secondary A/μ assay), the
script records it under `component_summaries` rather than pretending it updates the
primary H482R/S487 pairwise state.
"""

import argparse
import csv
import hashlib
import json
import math
import shutil
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Tuple

# Portable no-third-party mode: always use Wilson fallback intervals.
beta_dist = None


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path) -> Any:
    with open(path) as f:
        return json.load(f)


def save_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=False))


def read_csv_rows(path: Path) -> List[Dict[str, str]]:
    with open(path, newline='') as f:
        return list(csv.DictReader(f))


def write_csv_rows(path: Path, fieldnames: List[str], rows: List[Dict[str, Any]]) -> None:
    with open(path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, '') for k in fieldnames})


def log2(x: float) -> float:
    x = float(x)
    if x <= 0:
        raise ValueError(f'positive factor required, got {x}')
    return math.log2(x)


def require_columns(rows: List[Dict[str, str]], cols: List[str], csv_path: Path) -> None:
    if not rows:
        raise ValueError(f'{csv_path} has no rows')
    missing = [c for c in cols if c not in rows[0]]
    if missing:
        raise ValueError(f'{csv_path} missing required columns: {missing}')


def ratio_result_to_bits(csv_path: Path) -> Dict[str, Any]:
    rows = read_csv_rows(csv_path)
    require_columns(rows, ['factor_low', 'factor_base', 'factor_high'], csv_path)
    row = rows[0]
    lo = log2(float(row['factor_low']))
    mid = log2(float(row['factor_base']))
    hi = log2(float(row['factor_high']))
    if not (lo <= mid <= hi):
        raise ValueError(f'Expected factor_low <= factor_base <= factor_high after log2 conversion in {csv_path}')
    out = {
        'summary_type': 'ratio_bits',
        'assay_id': row.get('assay_id') or csv_path.stem,
        'center_bits': mid,
        'halfwidth_bits': max(mid - lo, hi - mid),
        'lower_bits': lo,
        'upper_bits': hi,
        'factor_low': float(row['factor_low']),
        'factor_base': float(row['factor_base']),
        'factor_high': float(row['factor_high']),
    }
    if row.get('n_current_pairs', '').strip():
        out['n_current_pairs'] = int(float(row['n_current_pairs']))
    if row.get('notes'):
        out['notes'] = row.get('notes')
    return out


def _wilson_interval(k: float, n: float, z: float = 1.96) -> Tuple[float, float]:
    if n <= 0:
        raise ValueError('n must be positive')
    phat = k / n
    denom = 1.0 + z*z/n
    center = (phat + z*z/(2*n)) / denom
    half = (z * math.sqrt((phat*(1-phat) + z*z/(4*n))/n)) / denom
    return max(1e-12, center-half), min(1-1e-12, center+half)


def count_result_to_bits(csv_path: Path) -> Dict[str, Any]:
    rows = read_csv_rows(csv_path)
    require_columns(rows, ['num_success', 'num_total', 'den_success', 'den_total'], csv_path)
    row = rows[0]
    a = float(row.get('alpha') or 0.5)
    b = float(row.get('beta') or 0.5)
    ns = float(row['num_success'])
    nt = float(row['num_total'])
    ds = float(row['den_success'])
    dt = float(row['den_total'])
    if not (0 <= ns <= nt and 0 <= ds <= dt and nt > 0 and dt > 0):
        raise ValueError('count result requires 0 <= success <= total and positive totals for numerator and denominator')
    p_num_mid = (ns + a) / (nt + a + b)
    p_den_mid = (ds + a) / (dt + a + b)
    if beta_dist is not None:
        p_num_low = beta_dist.ppf(0.025, ns + a, nt - ns + b)
        p_num_hi = beta_dist.ppf(0.975, ns + a, nt - ns + b)
        p_den_low = beta_dist.ppf(0.025, ds + a, dt - ds + b)
        p_den_hi = beta_dist.ppf(0.975, ds + a, dt - ds + b)
        interval_method = 'jeffreys_beta_quantile'
    else:
        p_num_low, p_num_hi = _wilson_interval(ns, nt)
        p_den_low, p_den_hi = _wilson_interval(ds, dt)
        interval_method = 'wilson_portable_no_scipy'
    lo = log2(p_num_low / p_den_hi)
    mid = log2(p_num_mid / p_den_mid)
    hi = log2(p_num_hi / p_den_low)
    return {
        'summary_type': 'count_ratio_bits',
        'assay_id': row.get('assay_id') or csv_path.stem,
        'center_bits': mid,
        'halfwidth_bits': max(mid - lo, hi - mid),
        'lower_bits': lo,
        'upper_bits': hi,
        'smoothed_ratio': p_num_mid / p_den_mid,
        'num_success': ns,
        'num_total': nt,
        'den_success': ds,
        'den_total': dt,
        'alpha': a,
        'beta': b,
        'interval_method': interval_method,
    }


def ws_replicate_result(csv_path: Path) -> Dict[str, Any]:
    rows = read_csv_rows(csv_path)
    require_columns(rows, ['dataset_id', 'context', 'replicate_id', 'winner_route'], csv_path)
    return {
        'summary_type': 'ws_single_replicate_outcome',
        'n_rows': len(rows),
        'rows': rows,
        'contexts': sorted(set(r['context'] for r in rows)),
        'routes': sorted(set(r['winner_route'] for r in rows)),
    }


def get_manifest_stage(manifest: Dict[str, Any], stage_index: int) -> Dict[str, Any]:
    stages = manifest.get('stages') or []
    if not stages:
        raise ValueError('manifest has no stages')
    matches = [s for s in stages if int(s.get('stage', -1)) == stage_index]
    if not matches:
        raise ValueError(f'manifest has no stage {stage_index}; available stages: {[s.get("stage") for s in stages]}')
    return matches[0]


def reduce_by_assay_type(stage: Dict[str, Any], result_csv: Path) -> Dict[str, Any]:
    assay_type = stage.get('assay_type')
    if assay_type == 'ratio_summary':
        return ratio_result_to_bits(result_csv)
    if assay_type == 'count_summary':
        return count_result_to_bits(result_csv)
    if assay_type == 'single_replicate_outcome':
        return ws_replicate_result(result_csv)
    raise ValueError(f'Unsupported assay_type {assay_type!r}')


def ensure_component_summaries(spec: Dict[str, Any]) -> Dict[str, Any]:
    spec.setdefault('component_summaries', {})
    spec['component_summaries'].setdefault('H482R', {})
    spec['component_summaries'].setdefault('S487', {})
    spec['component_summaries'].setdefault('WS', {})
    return spec


def append_ws_outcomes(spec: Dict[str, Any], summary: Dict[str, Any], outdir: Path) -> Tuple[Dict[str, Any], str, str]:
    """Append WS winner outcomes without corrupting WS.counts_csv.

    v0.1 wrote the replicate-outcome CSV into WS.counts_csv, but the WS scheduler
    expects counts_csv rows shaped as context,route,count. v0.2 keeps replicate
    outcomes in WS.replicate_outcomes_csv and also emits a count-shaped companion
    CSV for audit/optional downstream use. It deliberately leaves WS.counts_csv
    unchanged unless it already pointed to a count-shaped file.
    """
    ws_cfg = spec.setdefault('WS', {})
    existing_outcomes = ws_cfg.get('replicate_outcomes_csv') or ws_cfg.get('outcomes_csv')
    outcome_rows: List[Dict[str, Any]] = []
    outcome_fields = ['dataset_id', 'context', 'replicate_id', 'winner_route']
    if existing_outcomes:
        existing_path = Path(existing_outcomes)
        if not existing_path.is_absolute():
            existing_path = (Path.cwd() / existing_path).resolve()
        if existing_path.exists():
            old = read_csv_rows(existing_path)
            outcome_rows.extend(old)
            if old:
                outcome_fields = list(dict.fromkeys(outcome_fields + list(old[0].keys())))
    outcome_rows.extend(summary['rows'])
    outcome_fields = list(dict.fromkeys(outcome_fields + [k for r in summary['rows'] for k in r.keys()]))
    outcomes_csv = outdir / 'updated_WS_replicate_outcomes.csv'
    write_csv_rows(outcomes_csv, outcome_fields, outcome_rows)

    # Build count-shaped CSV expected by the scheduler, but do not force runtime to
    # use it unless a count-shaped counts_csv was already configured.
    counter: Dict[Tuple[str, str], int] = {}
    for r in outcome_rows:
        ctx = r.get('context', '')
        route = r.get('winner_route') or r.get('route', '')
        if ctx and route:
            counter[(ctx, route)] = counter.get((ctx, route), 0) + 1
    count_rows = [{'context': ctx, 'route': route, 'count': count} for (ctx, route), count in sorted(counter.items())]
    counts_csv = outdir / 'updated_WS_counts_from_replicate_outcomes.csv'
    write_csv_rows(counts_csv, ['context', 'route', 'count'], count_rows)

    ws_cfg['replicate_outcomes_csv'] = str(outcomes_csv)
    ws_cfg['outcome_counts_csv'] = str(counts_csv)

    # Preserve an existing proper counts_csv, but repair it if it points to an outcome-shaped file.
    existing_counts = ws_cfg.get('counts_csv')
    if existing_counts:
        ep = Path(existing_counts)
        if not ep.is_absolute():
            ep = (Path.cwd() / ep).resolve()
        if ep.exists():
            try:
                old_rows = read_csv_rows(ep)
                if old_rows and all(k in old_rows[0] for k in ('context','route','count')):
                    ws_cfg['counts_csv'] = str(ep)
                else:
                    # Remove malformed counts_csv so the OS falls back to default_current_gains_bits.
                    ws_cfg.pop('counts_csv', None)
            except Exception:
                ws_cfg.pop('counts_csv', None)
        else:
            ws_cfg.pop('counts_csv', None)
    return spec, str(outcomes_csv), str(counts_csv)

def patch_spec(spec: Dict[str, Any], manifest: Dict[str, Any], stage: Dict[str, Any], summary: Dict[str, Any], outdir: Path) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    updated = deepcopy(spec)
    updated = ensure_component_summaries(updated)
    action = manifest.get('recommended_action')
    branch = stage.get('branch') or manifest.get('recommended_branch')
    stage_name = stage.get('name', '')
    patch_report: Dict[str, Any] = {'action': action, 'branch': branch, 'stage_name': stage_name, 'runtime_patch_applied': False, 'component_recorded': None}

    # Runtime-consumed primary-state patches.
    if branch == 'H' and stage_name == 'one_more_H482R_development_pair' and summary['summary_type'] == 'ratio_bits':
        updated.setdefault('H482R', {})
        updated['H482R']['input_mode'] = 'direct'
        updated['H482R']['center_bits'] = summary['center_bits']
        updated['H482R']['halfwidth_bits'] = summary['halfwidth_bits']
        old_n = int(spec.get('H482R', {}).get('n_current_pairs', 0))
        updated['H482R']['n_current_pairs'] = int(summary.get('n_current_pairs', old_n + 1))
        patch_report['runtime_patch_applied'] = True
        patch_report['patched_field'] = 'H482R primary development summary'
        return updated, patch_report

    if branch == 'S487' and stage_name.lower().startswith('s487') and 'pairwise' in stage_name.lower() and summary['summary_type'] == 'ratio_bits':
        updated.setdefault('S487', {})
        updated['S487']['input_mode'] = 'direct'
        updated['S487']['center_bits'] = summary['center_bits']
        updated['S487']['halfwidth_bits'] = summary['halfwidth_bits']
        old_n = int(spec.get('S487', {}).get('n_current_pairs', 0))
        updated['S487']['n_current_pairs'] = int(summary.get('n_current_pairs', old_n + 1))
        patch_report['runtime_patch_applied'] = True
        patch_report['patched_field'] = 'S487 primary pairwise summary'
        return updated, patch_report

    if branch == 'WS' and summary['summary_type'] == 'ws_single_replicate_outcome':
        updated, outcomes_csv, counts_csv = append_ws_outcomes(updated, summary, outdir)
        patch_report['runtime_patch_applied'] = True
        patch_report['patched_field'] = 'WS replicate_outcomes_csv (counts_csv preserved)'
        patch_report['updated_ws_replicate_outcomes_csv'] = outcomes_csv
        patch_report['updated_ws_outcome_counts_csv'] = counts_csv
        patch_report['ws_counts_csv_policy'] = 'preserve valid existing counts_csv; otherwise fall back to default_current_gains_bits'
        return updated, patch_report

    # Component summaries: recorded but not automatically substituted into primary runtime state.
    component_key = stage_name
    if branch in ('H', 'H482R'):
        updated['component_summaries']['H482R'][component_key] = summary
        patch_report['component_recorded'] = f'H482R::{component_key}'
    elif branch == 'S487':
        updated['component_summaries']['S487'][component_key] = summary
        patch_report['component_recorded'] = f'S487::{component_key}'
    elif branch == 'WS':
        updated['component_summaries']['WS'][component_key] = summary
        patch_report['component_recorded'] = f'WS::{component_key}'
    else:
        updated['component_summaries'].setdefault(str(branch), {})[component_key] = summary
        patch_report['component_recorded'] = f'{branch}::{component_key}'
    return updated, patch_report


def reduce_and_patch(spec_path: Path, manifest_path: Path, result_csv: Path, stage_index: int, outdir: Path) -> Dict[str, Any]:
    outdir.mkdir(parents=True, exist_ok=True)
    spec = load_json(spec_path)
    manifest = load_json(manifest_path)
    stage = get_manifest_stage(manifest, stage_index)
    summary = reduce_by_assay_type(stage, result_csv)
    updated_spec, patch_report = patch_spec(spec, manifest, stage, summary, outdir)
    updated_path = outdir / 'updated_raw_input_spec_v0_1.json'
    save_json(updated_path, updated_spec)
    report = {
        'status': 'feedback_reduced',
        'inputs': {
            'spec_path': str(spec_path),
            'manifest_path': str(manifest_path),
            'result_csv': str(result_csv),
            'stage_index': stage_index,
        },
        'sha256': {
            'spec': sha256_file(spec_path),
            'manifest': sha256_file(manifest_path),
            'result_csv': sha256_file(result_csv),
        },
        'manifest_action': manifest.get('recommended_action'),
        'manifest_branch': manifest.get('recommended_branch'),
        'stage': stage,
        'reduced_summary': summary,
        'patch_report': patch_report,
        'updated_raw_input_spec': str(updated_path),
        'next_step': 'Run the raw-input/autonomous TMD supervisor on updated_raw_input_spec_v0_1.json. If runtime_patch_applied=false, interpret component_summaries before expecting the current runtime branch state to change.',
    }
    save_json(outdir / 'feedback_reduction_report_v0_1.json', report)
    return report


def main() -> None:
    ap = argparse.ArgumentParser(description='Reduce a filled TMD next-step result file and patch the raw-input spec.')
    ap.add_argument('--spec', required=True, help='Current raw-input spec JSON')
    ap.add_argument('--manifest', required=True, help='Next-step manifest JSON')
    ap.add_argument('--result-csv', required=True, help='Filled result CSV for one manifest stage')
    ap.add_argument('--stage', type=int, default=1, help='Manifest stage number, default 1')
    ap.add_argument('--outdir', required=True, help='Output directory')
    args = ap.parse_args()
    report = reduce_and_patch(Path(args.spec).resolve(), Path(args.manifest).resolve(), Path(args.result_csv).resolve(), args.stage, Path(args.outdir).resolve())
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
