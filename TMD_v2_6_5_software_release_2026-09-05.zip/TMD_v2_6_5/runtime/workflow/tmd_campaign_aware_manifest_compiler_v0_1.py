#!/usr/bin/env python3
"""TMD campaign-aware manifest compiler v0.1.

Maps an adaptive-DAG campaign executor output to an executable next-step manifest.
Unlike the older manifest compiler, this handles campaign actions directly, not only runtime actions.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path

DEFAULT_WS_CONTEXT = "Pf_WS_routes_v1"

def stage_ratio(stage, name, branch, minimal="(center_bits, halfwidth_bits)", completion=None):
    return {
        "stage": stage,
        "name": name,
        "branch": branch,
        "assay_type": "ratio_summary",
        "template_file": "TMD_next_step_ratio_summary_template_v0_1.csv",
        "minimal_summary": minimal,
        "completion_condition": completion or "ratio summary reduced to updated bit interval",
        "rerun_after_stage": "tmd_campaign_closed_loop_runner_v0_1.py or raw-input runtime + adaptive DAG executor"
    }

def stage_count(stage, name, branch, completion=None):
    return {
        "stage": stage,
        "name": name,
        "branch": branch,
        "assay_type": "count_summary",
        "template_file": "TMD_next_step_count_summary_template_v0_1.csv",
        "minimal_summary": "(num_success,num_total,den_success,den_total,alpha,beta)",
        "completion_condition": completion or "count summary reduced to updated bit interval",
        "rerun_after_stage": "tmd_campaign_closed_loop_runner_v0_1.py or raw-input runtime + adaptive DAG executor"
    }

def stage_ws(context):
    return {
        "stage": 1,
        "name": f"WS_next_replicate_in_{context}",
        "branch": "WS",
        "assay_type": "single_replicate_outcome",
        "template_file": "TMD_WS_single_replicate_outcome_template_v0_1.csv",
        "minimal_summary": "(dataset_id, context, replicate_id, winner_route) or equivalent count increment",
        "completion_condition": "one new winner-route outcome recorded for the named context",
        "rerun_after_stage": "tmd_campaign_closed_loop_runner_v0_1.py or raw-input runtime + adaptive DAG executor",
        "context": context
    }

CAMPAIGN_MANIFESTS = {
    "H482R_developmental_entry_proxy": [stage_ratio(1, "one_more_H482R_development_pair", "H", "(center_bits, halfwidth_bits, n_current_pairs)", "one additional developmental-entry replicate pair recorded and reduced to updated (d,h,n)")],
    "H482_family_mu_bias_count_assay": [stage_count(1, "H482_family_mu_bias_count_assay", "H", "H482-family mu-bias count summary reduced to updated count interval")],
    "S487L_pairwise_competition": [stage_ratio(1, "S487L_pairwise_competition", "S487", "(center_bits, halfwidth_bits, n_current_pairs)", "S487L pairwise competition summary reduced to updated S487 pairwise (d,h,n)")],
    "S487_Asn_homeostasis_perturbation": [stage_ratio(1, "S487_Asn_homeostasis_assay", "S487", "(center_bits, halfwidth_bits)", "Asn-homeostasis top-up summary reduced to updated A-side ratio interval")],
    "S487_mutation_spectrum_assay": [stage_count(1, "S487_mutation_spectrum_assay", "S487", "S487 mutation-spectrum summary reduced to updated mu-side count interval")],
    "Q469_block_exploratory_pairwise": [stage_ratio(1, "Q469_block_exploratory_pairwise", "Q469", "(center_bits, halfwidth_bits)", "Q469 exploratory pairwise summary reduced to route/block bit interval")],
}

def compile_manifest(campaign_output: dict, runtime_summary: dict | None = None):
    rec = campaign_output.get("recommended_action")
    runtime_action = campaign_output.get("runtime_original_action") or campaign_output.get("runtime_action") or None
    runtime_summary = runtime_summary or {}
    manifest = {
        "status": campaign_output.get("status", "ok"),
        "campaign_executor_reason": campaign_output.get("reason"),
        "campaign_action": rec,
        # Compatibility fields consumed by the feedback reducer and replay ledger.
        # The selected campaign action is distinct from the runtime proposal below.
        "recommended_action": rec,
        "runtime_action": runtime_action,
        "runtime_mapped_action": campaign_output.get("runtime_mapped_action"),
        "completed_actions": campaign_output.get("completed_actions", []),
        "budget_remaining": campaign_output.get("budget_remaining"),
        "frontier_equivalent_first_actions": campaign_output.get("frontier_equivalent_first_actions", []),
        "optimal_completion_bundle": campaign_output.get("optimal_completion_bundle", []),
        "warnings": campaign_output.get("warnings", []),
        "stages": []
    }
    if rec is None:
        manifest["status"] = "unresolved_no_campaign_action"
        manifest["notes"] = "Adaptive campaign executor did not return a campaign action."
        return manifest
    if rec == "WS_new_context_flagship_replication":
        context = DEFAULT_WS_CONTEXT
        if runtime_action and isinstance(runtime_action, str) and runtime_action.startswith("sample_next_replicate_in::"):
            context = runtime_action.split("::", 1)[1]
        manifest["stages"] = [stage_ws(context)]
        manifest["recommended_branch"] = manifest["stages"][0]["branch"]
        return manifest
    if rec in CAMPAIGN_MANIFESTS:
        manifest["stages"] = CAMPAIGN_MANIFESTS[rec]
        manifest["recommended_branch"] = manifest["stages"][0]["branch"]
        return manifest
    manifest["status"] = "unmapped_campaign_action"
    manifest["notes"] = f"No campaign-aware manifest mapping found for {rec}."
    return manifest

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--campaign-output", required=True)
    ap.add_argument("--runtime-summary", default=None)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    campaign_output = json.load(open(args.campaign_output))
    runtime_summary = json.load(open(args.runtime_summary)) if args.runtime_summary else None
    Path(args.out).write_text(json.dumps(compile_manifest(campaign_output, runtime_summary), indent=2))
