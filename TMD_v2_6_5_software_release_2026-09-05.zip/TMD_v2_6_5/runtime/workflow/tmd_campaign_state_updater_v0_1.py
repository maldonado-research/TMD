#!/usr/bin/env python3
"""TMD campaign state updater v0.1.

Closes the campaign loop after a manifest/result/ledger transition is verified.

Usage examples:
  python tmd_campaign_state_updater_v0_1.py \
    --campaign-state campaign_state.json \
    --manifest next_step_manifest.json \
    --verification-certificate TMD_replay_ledger_campaign_certificate_v0_1.json \
    --final-event-hash <hash> \
    --outdir campaign_update

  python tmd_campaign_state_updater_v0_1.py \
    --campaign-state campaign_state.json \
    --executor-output adaptive_campaign_executor_output_v0_1.json \
    --allow-unverified \
    --outdir campaign_update

The script validates that the completed campaign action is:
  * known in the current campaign slate,
  * not already completed,
  * unlocked by prerequisites,
  * affordable under the remaining budget,
  * verified by a replay-ledger certificate unless --allow-unverified is set.

It then emits:
  * updated_campaign_state_v0_1.json
  * campaign_state_update_report_v0_1.json
  * campaign_state_update_summary_v0_1.csv
"""
from __future__ import annotations

import argparse
import csv
import datetime as _dt
import hashlib
import json
from pathlib import Path
from typing import Any

ACTIONS = [
    "H482R_developmental_entry_proxy",
    "S487L_pairwise_competition",
    "WS_new_context_flagship_replication",
    "S487_Asn_homeostasis_perturbation",
    "H482_family_mu_bias_count_assay",
    "S487_mutation_spectrum_assay",
    "Q469_block_exploratory_pairwise",
]
META = {
    "H482R_developmental_entry_proxy": {"cost": 5, "score": 15},
    "S487L_pairwise_competition": {"cost": 5, "score": 14},
    "WS_new_context_flagship_replication": {"cost": 6, "score": 14},
    "S487_Asn_homeostasis_perturbation": {"cost": 7, "score": 13},
    "H482_family_mu_bias_count_assay": {"cost": 8, "score": 11},
    "S487_mutation_spectrum_assay": {"cost": 7, "score": 9},
    "Q469_block_exploratory_pairwise": {"cost": 5, "score": 7},
}
REQS = {
    "H482R_developmental_entry_proxy": set(),
    "S487L_pairwise_competition": set(),
    "WS_new_context_flagship_replication": set(),
    "S487_Asn_homeostasis_perturbation": {"S487L_pairwise_competition"},
    "H482_family_mu_bias_count_assay": {"H482R_developmental_entry_proxy"},
    "S487_mutation_spectrum_assay": {"S487L_pairwise_competition", "S487_Asn_homeostasis_perturbation"},
    "Q469_block_exploratory_pairwise": {"H482R_developmental_entry_proxy", "S487L_pairwise_competition"},
}
RUNTIME_MAP = {
    "continue_one_more_primary_pair": "H482R_developmental_entry_proxy",
    "H482R_developmental_entry_proxy": "H482R_developmental_entry_proxy",
    "transport_homeostasis_then_counts_300": "H482_family_mu_bias_count_assay",
    "transport_homeostasis_then_counts_350": "H482_family_mu_bias_count_assay",
    "H482_family_mu_bias_count_assay": "H482_family_mu_bias_count_assay",
    "run_mu": "S487_mutation_spectrum_assay",
    "S487_mutation_spectrum_assay": "S487_mutation_spectrum_assay",
    "Asn_homeostasis_topup_then_run_mu": "S487_Asn_homeostasis_perturbation",
    "S487_Asn_homeostasis_perturbation": "S487_Asn_homeostasis_perturbation",
    "S487L_pairwise_competition": "S487L_pairwise_competition",
    "sample_next_replicate_in::Pf_WS_routes_v1": "WS_new_context_flagship_replication",
    "sample_next_replicate_in::Pf5_2021_WspAwsMws": "WS_new_context_flagship_replication",
    "sample_next_replicate_in::WS_2019_fluct_WspAwsMws": "WS_new_context_flagship_replication",
    "WS_new_context_flagship_replication": "WS_new_context_flagship_replication",
    "Q469_block_exploratory_pairwise": "Q469_block_exploratory_pairwise",
}


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_obj(obj: Any) -> str:
    return hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_json(path: str | None) -> Any | None:
    if not path:
        return None
    return json.loads(Path(path).read_text())


def cost(actions: set[str]) -> int:
    return sum(META[a]["cost"] for a in actions)


def score(actions: set[str]) -> int:
    return sum(META[a]["score"] for a in actions)


def is_ideal(actions: set[str]) -> bool:
    return all(REQS[a].issubset(actions) for a in actions)


def action_from_inputs(args: argparse.Namespace) -> tuple[str | None, str]:
    if args.completion_action:
        return args.completion_action, "--completion-action"
    manifest = load_json(args.manifest)
    if isinstance(manifest, dict):
        if manifest.get("campaign_action"):
            return manifest.get("campaign_action"), "manifest.campaign_action"
        if manifest.get("action"):
            mapped = RUNTIME_MAP.get(manifest.get("action"))
            return mapped, "manifest.action_mapped"
    ex = load_json(args.executor_output)
    if isinstance(ex, dict):
        if ex.get("recommended_action"):
            return ex.get("recommended_action"), "executor_output.recommended_action"
        ra = ex.get("runtime_action") or ex.get("runtime_next_action")
        if ra:
            return RUNTIME_MAP.get(ra), "executor_output.runtime_action_mapped"
    return None, "none"


def verification_status(args: argparse.Namespace) -> dict[str, Any]:
    """Return a normalized verification object.

    A completion is considered verified if --allow-unverified is set, or the supplied
    final_event_hash is present in a certificate's valid_final_event_hashes_sorted.
    """
    out = {
        "allow_unverified": bool(args.allow_unverified),
        "verified": False,
        "final_event_hash": args.final_event_hash,
        "campaign_root": None,
        "verification_source": None,
        "warnings": [],
    }
    if args.allow_unverified:
        out["verified"] = True
        out["verification_source"] = "allow_unverified"
        out["warnings"].append("Completion accepted with --allow-unverified; use only for dry runs/tests.")
        return out
    cert = load_json(args.verification_certificate)
    if cert:
        out["verification_source"] = args.verification_certificate
        out["campaign_root"] = cert.get("merkle_root_valid_final_event_hashes") or cert.get("campaign_root")
        valid_hashes = set(cert.get("valid_final_event_hashes_sorted", []))
        if args.final_event_hash:
            out["verified"] = args.final_event_hash in valid_hashes
            if not out["verified"]:
                out["warnings"].append("final_event_hash not found in certificate valid_final_event_hashes_sorted")
        elif len(valid_hashes) == 1:
            out["final_event_hash"] = next(iter(valid_hashes))
            out["verified"] = True
        else:
            out["warnings"].append("No --final-event-hash supplied and certificate contains zero or multiple valid hashes.")
        return out
    out["warnings"].append("No verification certificate supplied and --allow-unverified not set.")
    return out


def optimal_completion(completed: set[str], budget: int) -> tuple[set[str], int, int]:
    rem = [a for a in ACTIONS if a not in completed]
    best_T: set[str] = set()
    best_cost = 0
    best_score = -1
    for mask in range(1 << len(rem)):
        T = {rem[i] for i in range(len(rem)) if (mask >> i) & 1}
        U = completed | T
        if is_ideal(U):
            C = cost(T)
            P = score(T)
            if C <= budget and (P > best_score or (P == best_score and C < best_cost)):
                best_T, best_cost, best_score = T, C, P
    return best_T, best_cost, best_score


def update_state(state: dict[str, Any], action: str, verification: dict[str, Any], action_source: str) -> tuple[dict[str, Any], dict[str, Any]]:
    completed = set(state.get("completed_actions", []))
    budget = int(state.get("budget_remaining", 0))
    errors: list[str] = []
    warnings: list[str] = []

    unknown_completed = sorted([a for a in completed if a not in ACTIONS])
    if unknown_completed:
        errors.append(f"unknown completed action(s): {unknown_completed}")
    if action not in ACTIONS:
        errors.append(f"unknown completion action: {action}")
    if not is_ideal(completed):
        errors.append("current completed_actions are not DAG-feasible")
    if action in completed:
        errors.append(f"action already completed: {action}")
    if action in ACTIONS and not REQS[action].issubset(completed):
        errors.append(f"action prerequisites not completed: {sorted(REQS[action] - completed)}")
    if action in ACTIONS and META[action]["cost"] > budget:
        errors.append(f"insufficient budget: action cost {META[action]['cost']} > budget {budget}")
    if not verification.get("verified"):
        errors.append("completion is not verified; supply valid certificate/hash or use --allow-unverified for dry runs")
    warnings.extend(verification.get("warnings", []))

    old_state_hash = sha256_obj(state)
    history = list(state.get("campaign_history", []))
    prev_hash = state.get("campaign_event_hash") or (history[-1].get("campaign_event_hash") if history else "GENESIS")

    if errors:
        report = {
            "status": "error",
            "errors": errors,
            "warnings": warnings,
            "action": action,
            "action_source": action_source,
            "state_hash_before": old_state_hash,
            "verified": verification.get("verified"),
        }
        return state, report

    new_completed = sorted(completed | {action})
    new_budget = budget - META[action]["cost"]
    frontier_T, frontier_C, frontier_P = optimal_completion(set(new_completed), new_budget)

    event_payload = {
        "event_type": "campaign_action_completed",
        "timestamp_utc": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"),
        "previous_campaign_event_hash": prev_hash,
        "state_hash_before": old_state_hash,
        "completed_action": action,
        "action_cost": META[action]["cost"],
        "action_priority_score": META[action]["score"],
        "budget_before": budget,
        "budget_after": new_budget,
        "completed_actions_before": sorted(completed),
        "completed_actions_after": new_completed,
        "verification": verification,
    }
    event_hash = sha256_obj(event_payload)
    event_payload["campaign_event_hash"] = event_hash

    new_state = dict(state)
    new_state["completed_actions"] = new_completed
    new_state["budget_remaining"] = new_budget
    new_state["campaign_event_hash"] = event_hash
    new_state["campaign_history"] = history + [event_payload]
    new_state["last_completed_action"] = action
    new_state["last_verified_final_event_hash"] = verification.get("final_event_hash")
    new_state["last_campaign_root"] = verification.get("campaign_root")
    new_state["next_optimal_completion_bundle"] = sorted(frontier_T)
    new_state["next_optimal_additional_cost"] = frontier_C
    new_state["next_optimal_additional_score"] = frontier_P
    new_state_hash = sha256_obj(new_state)

    report = {
        "status": "updated",
        "warnings": warnings,
        "completed_action": action,
        "action_source": action_source,
        "action_cost": META[action]["cost"],
        "action_priority_score": META[action]["score"],
        "budget_before": budget,
        "budget_after": new_budget,
        "completed_actions_before": sorted(completed),
        "completed_actions_after": new_completed,
        "state_hash_before": old_state_hash,
        "state_hash_after": new_state_hash,
        "campaign_event_hash": event_hash,
        "verified_final_event_hash": verification.get("final_event_hash"),
        "campaign_root": verification.get("campaign_root"),
        "DAG_feasible_after": is_ideal(set(new_completed)),
        "next_optimal_completion_bundle": sorted(frontier_T),
        "next_optimal_additional_cost": frontier_C,
        "next_optimal_additional_score": frontier_P,
    }
    return new_state, report


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--campaign-state", required=True)
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--executor-output", default=None)
    ap.add_argument("--completion-action", default=None)
    ap.add_argument("--verification-certificate", default=None)
    ap.add_argument("--final-event-hash", default=None)
    ap.add_argument("--allow-unverified", action="store_true")
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    state = json.loads(Path(args.campaign_state).read_text())
    action, source = action_from_inputs(args)
    if not action:
        report = {"status": "error", "errors": ["could not infer completion action"], "action_source": source}
        (outdir / "campaign_state_update_report_v0_1.json").write_text(json.dumps(report, indent=2))
        raise SystemExit(2)
    verification = verification_status(args)
    new_state, report = update_state(state, action, verification, source)

    (outdir / "updated_campaign_state_v0_1.json").write_text(json.dumps(new_state, indent=2))
    (outdir / "campaign_state_update_report_v0_1.json").write_text(json.dumps(report, indent=2))
    with open(outdir / "campaign_state_update_summary_v0_1.csv", "w", newline="") as f:
        fields = [
            "status", "completed_action", "action_cost", "budget_before", "budget_after",
            "DAG_feasible_after", "campaign_event_hash", "verified_final_event_hash", "campaign_root",
            "next_optimal_additional_cost", "next_optimal_additional_score", "next_optimal_completion_bundle",
            "warnings", "errors"
        ]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        row = {k: report.get(k) for k in fields}
        row["warnings"] = " | ".join(report.get("warnings", [])) if isinstance(report.get("warnings"), list) else report.get("warnings")
        row["errors"] = " | ".join(report.get("errors", [])) if isinstance(report.get("errors"), list) else report.get("errors")
        if isinstance(row.get("next_optimal_completion_bundle"), list):
            row["next_optimal_completion_bundle"] = " | ".join(row["next_optimal_completion_bundle"])
        w.writerow(row)
    print(json.dumps(report, indent=2))
    if report.get("status") == "error":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
