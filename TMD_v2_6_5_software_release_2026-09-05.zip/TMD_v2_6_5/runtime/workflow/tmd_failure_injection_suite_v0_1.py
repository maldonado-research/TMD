#!/usr/bin/env python3
"""TMD failure-injection suite v0.1.

Runs positive and negative controls for the TMD multi-cycle campaign stack.
No third-party packages required. Designed for external labs to prove the stack
not only succeeds on happy paths but rejects invalid campaign/ledger/schema states.
"""
from __future__ import annotations
import argparse, csv, glob, importlib.util, json, shutil, subprocess, sys
from pathlib import Path
from typing import Any

EXPECTED_SEQUENCE = [
    "H482R_developmental_entry_proxy",
    "S487L_pairwise_competition",
    "WS_new_context_flagship_replication",
    "S487_Asn_homeostasis_perturbation",
]


def load_json(p: Path) -> Any:
    with open(p, encoding='utf-8') as f: return json.load(f)

def save_json(p: Path, obj: Any) -> None:
    p.write_text(json.dumps(obj, indent=2, sort_keys=False), encoding='utf-8')

def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text('', encoding='utf-8'); return
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields: fields.append(k)
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for r in rows: w.writerow({k:r.get(k,'') for k in fields})

def import_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod

def run_multicycle(stack_dir: Path, outdir: Path) -> dict[str, Any]:
    runner = stack_dir/'workflow'/'tmd_multicycle_campaign_runner_v0_1.py'
    raw = stack_dir/'templates'/'TMD_raw_input_spec_template_v0_3_campaign_loop.json'
    camp = stack_dir/'templates'/'TMD_campaign_state_template_v0_2.json'
    cmd = [sys.executable, '-S', str(runner), '--raw-spec', str(raw), '--campaign-state', str(camp), '--outdir', str(outdir), '--max-cycles', '8', '--run-prefix', 'FAILINJ']
    proc = subprocess.run(cmd, text=True, capture_output=True)
    if proc.returncode != 0:
        return {'ok': False, 'stdout': proc.stdout, 'stderr': proc.stderr, 'error': 'multicycle runner failed'}
    cert = load_json(outdir/'TMD_multicycle_campaign_certificate_v0_1.json')
    return {'ok': True, 'certificate': cert, 'stdout': proc.stdout, 'stderr': proc.stderr}

def contains_error(report: dict[str, Any], needle: str) -> bool:
    return any(needle in str(e) for e in report.get('errors', []))

def main() -> None:
    ap = argparse.ArgumentParser(description='Run TMD failure-injection controls.')
    ap.add_argument('--stack-dir', default=str(Path(__file__).resolve().parent))
    ap.add_argument('--outdir', required=True)
    args = ap.parse_args()
    stack_dir = Path(args.stack_dir).resolve()
    outdir = Path(args.outdir).resolve(); outdir.mkdir(parents=True, exist_ok=True)
    workflow = stack_dir/'workflow'
    rows=[]

    # 1. Happy path multicycle validation
    happy_dir = outdir/'positive_multicycle'
    happy = run_multicycle(stack_dir, happy_dir)
    if happy.get('ok'):
        cert = happy['certificate']
        seq_ok = cert.get('cycle_completed_actions') == EXPECTED_SEQUENCE
        budget_ok = int(cert.get('final_budget_after')) == 0
        root_ok = bool(cert.get('campaign_merkle_root'))
        rows.append({'test_id':'positive_multicycle_root23','expected':'accept','observed':'accept' if seq_ok and budget_ok and root_ok else 'unexpected','pass':seq_ok and budget_ok and root_ok,'details':f"actions={cert.get('cycle_completed_actions')}; budget={cert.get('final_budget_after')}; root={cert.get('campaign_merkle_root','')[:12]}"})
    else:
        rows.append({'test_id':'positive_multicycle_root23','expected':'accept','observed':'error','pass':False,'details':happy.get('error','') + ' ' + happy.get('stderr','')[:400]})
        write_csv(outdir/'TMD_failure_injection_summary_v0_1.csv', rows); return

    updater = import_module(workflow/'tmd_campaign_state_updater_v0_1.py','campaign_updater')
    verifier = import_module(workflow/'tmd_replay_ledger_verifier_v0_1.py','ledger_verifier')

    verified = {'verified': True, 'final_event_hash': 'TEST_HASH', 'campaign_root': 'TEST_ROOT', 'warnings': []}
    root_state = load_json(stack_dir/'templates'/'TMD_campaign_state_template_v0_2.json')

    def update_case(test_id: str, state: dict[str, Any], action: str, expected_error_substring: str):
        _, report = updater.update_state(state, action, verified, 'failure_injection')
        ok = report.get('status') == 'error' and contains_error(report, expected_error_substring)
        rows.append({'test_id': test_id, 'expected':'reject', 'observed':report.get('status'), 'pass':ok, 'details':' | '.join(report.get('errors', []))})
        save_json(outdir/f'{test_id}_report.json', report)

    # 2. Duplicate completion must be rejected
    duplicate_state = dict(root_state)
    duplicate_state['completed_actions'] = ['H482R_developmental_entry_proxy']
    duplicate_state['budget_remaining'] = 18
    update_case('reject_duplicate_completed_action', duplicate_state, 'H482R_developmental_entry_proxy', 'already completed')

    # 3. Prerequisite violation must be rejected
    update_case('reject_premature_S487_mu_prerequisite', root_state, 'S487_mutation_spectrum_assay', 'prerequisites')

    # 4. Budget overrun must be rejected
    low_budget_state = dict(root_state); low_budget_state['budget_remaining'] = 4
    update_case('reject_budget_overrun', low_budget_state, 'H482R_developmental_entry_proxy', 'insufficient budget')

    # 5. Unknown action must be rejected
    update_case('reject_unknown_campaign_action', root_state, 'NOT_A_REAL_TMD_ACTION', 'unknown completion action')

    # 6. Unverified completion must be rejected
    unverified = {'verified': False, 'final_event_hash': 'NOPE', 'campaign_root': None, 'warnings': []}
    _, report = updater.update_state(root_state, 'H482R_developmental_entry_proxy', unverified, 'failure_injection')
    ok = report.get('status') == 'error' and contains_error(report, 'not verified')
    rows.append({'test_id':'reject_unverified_completion','expected':'reject','observed':report.get('status'),'pass':ok,'details':' | '.join(report.get('errors', []))})
    save_json(outdir/'reject_unverified_completion_report.json', report)

    # 7. Tampered ledger must be rejected.
    ledgers = sorted((happy_dir).glob('cycle_01/04_replay_ledger/*_event_sourced_replay_ledger_v0_1.json'))
    if ledgers:
        valid_ledger = ledgers[0]
        tampered = load_json(valid_ledger)
        # Modify manifest action inside event payload but do not recompute hash.
        for ev in tampered.get('events', []):
            if ev.get('event_type') == 'manifest_issued':
                ev.setdefault('payload', {})['tampered_action'] = 'ILLEGAL_CHANGE_WITHOUT_REHASH'
                break
        tampered_path = outdir/'tampered_ledger_event_hash_mismatch.json'
        save_json(tampered_path, tampered)
        row = verifier.verify_ledger(tampered_path, check_filesystem=False, allow_warning=True)
        ok = row.get('status') == 'invalid' and any('event_hash mismatch' in e for e in row.get('errors', []))
        rows.append({'test_id':'reject_tampered_ledger_event_hash_mismatch','expected':'reject','observed':row.get('status'),'pass':ok,'details':' | '.join(row.get('errors', []))})
        save_json(outdir/'tampered_ledger_verifier_report.json', row)
    else:
        rows.append({'test_id':'reject_tampered_ledger_event_hash_mismatch','expected':'reject','observed':'no_ledger_found','pass':False,'details':'happy path did not emit a ledger'})

    # 8. WS schema patch regression: final raw spec must not overwrite WS.counts_csv with replicate-outcome CSV.
    cert = happy['certificate']
    final_raw = Path(cert['final_raw_spec'])
    raw = load_json(final_raw)
    ws = raw.get('WS', {})
    has_replicates = 'replicate_outcomes_csv' in ws
    has_counts_from_outcomes = 'outcome_counts_csv' in ws
    counts_csv = ws.get('counts_csv')
    counts_not_replicate = True
    if counts_csv:
        p = Path(counts_csv)
        if p.exists():
            header = p.read_text(encoding='utf-8').splitlines()[0]
            counts_not_replicate = ('winner_route' not in header and 'replicate_id' not in header)
    ok = has_replicates and has_counts_from_outcomes and counts_not_replicate
    rows.append({'test_id':'preserve_WS_counts_schema_after_replicate_feedback','expected':'accept','observed':'accept' if ok else 'schema_regression','pass':ok,'details':f"replicate_outcomes_csv={has_replicates}; outcome_counts_csv={has_counts_from_outcomes}; counts_csv={counts_csv}"})

    # 9. Campaign event hash should change after accepted action.
    initial_state = root_state
    new_state, report = updater.update_state(root_state, 'H482R_developmental_entry_proxy', verified, 'failure_injection')
    ok = report.get('status') == 'updated' and new_state.get('campaign_event_hash') and new_state.get('campaign_event_hash') != initial_state.get('campaign_event_hash')
    rows.append({'test_id':'accepted_action_advances_campaign_event_hash','expected':'accept','observed':report.get('status'),'pass':ok,'details':f"event_hash={new_state.get('campaign_event_hash','')[:16]} budget={report.get('budget_before')}->{report.get('budget_after')}"})

    write_csv(outdir/'TMD_failure_injection_summary_v0_1.csv', rows)
    passed = sum(1 for r in rows if str(r.get('pass')).lower() in ['true','1'])
    certificate = {
        'certificate_version':'TMD_failure_injection_suite_v0_1',
        'n_tests':len(rows),
        'n_passed':passed,
        'all_passed':passed == len(rows),
        'tests':rows,
        'positive_multicycle_certificate': str(happy_dir/'TMD_multicycle_campaign_certificate_v0_1.json'),
        'notes':'Positive and negative controls for DAG campaign validity, ledger tamper detection, verification, budget, duplicates, prerequisites, and WS schema preservation.'
    }
    save_json(outdir/'TMD_failure_injection_certificate_v0_1.json', certificate)
    print(json.dumps({'status':'ok' if certificate['all_passed'] else 'failed','n_tests':len(rows),'n_passed':passed,'summary_csv':str(outdir/'TMD_failure_injection_summary_v0_1.csv'),'certificate_json':str(outdir/'TMD_failure_injection_certificate_v0_1.json')}, indent=2))

if __name__ == '__main__':
    main()
