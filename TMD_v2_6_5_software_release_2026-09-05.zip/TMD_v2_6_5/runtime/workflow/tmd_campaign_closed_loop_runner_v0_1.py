#!/usr/bin/env python3
"""TMD campaign closed-loop runner v0.1.

Composes:
  raw summaries -> raw supervisor -> adaptive DAG campaign executor -> campaign-aware manifest.

This does not run feedback/replay; it emits the manifest that the existing feedback/ledger stack consumes.
"""
from __future__ import annotations
import argparse, json, shutil, subprocess, sys, shlex
from pathlib import Path

DEPS = [
    'tmd_raw_input_compiled_supervisor_v0_2.py',
    'tmd_multi_uncertainty_compiled_supervisor_v0_1.py',
    'tmd_operating_system_v0_1.py',
    'TMD_H482R_generic_threshold_bellman_params_v0_1.json',
    'TMD_S487_generic_threshold_params_cost025_v0_1.json',
    'TMD_coherent_automaton_thresholds_current_v0_1.json',
    'TMD_recommended_switch_costs_current_v0_1.json',
    'tmd_adaptive_dag_campaign_executor_v0_1.py',
    'tmd_campaign_aware_manifest_compiler_v0_1.py',
    'TMD_next_step_ratio_summary_template_v0_1.csv',
    'TMD_next_step_count_summary_template_v0_1.csv',
    'TMD_WS_single_replicate_outcome_template_v0_1.csv',
]

def load_json(p):
    with open(p) as f: return json.load(f)

def save_json(p, obj):
    Path(p).write_text(json.dumps(obj, indent=2))

def normalize_raw_spec(raw_spec_path: Path, workdir: Path, script_dir: Path):
    spec = load_json(raw_spec_path)
    raw_base = raw_spec_path.parent
    # Convert relative CSV paths to absolute paths so the copied working spec can still see them.
    for branch in ['H482R', 'S487']:
        cfg = spec.get(branch, {})
        for key in ['ratio_csv', 'count_csv']:
            if key in cfg and cfg[key] and not str(cfg[key]).startswith('/'):
                cfg[key] = str((raw_base / cfg[key]).resolve())
        # Use dependency filenames copied into workdir for params_json.
        if branch == 'H482R': cfg.setdefault('params_json', 'TMD_H482R_generic_threshold_bellman_params_v0_1.json')
        if branch == 'S487': cfg.setdefault('params_json', 'TMD_S487_generic_threshold_params_cost025_v0_1.json')
    spec.setdefault('top', {})
    spec['top'].setdefault('thresholds_json', 'TMD_coherent_automaton_thresholds_current_v0_1.json')
    spec.setdefault('recommended_costs_json', 'TMD_recommended_switch_costs_current_v0_1.json')
    # WS counts, if present, may be relative.
    ws = spec.get('WS', {})
    if ws.get('counts_csv') and not str(ws['counts_csv']).startswith('/'):
        ws['counts_csv'] = str((raw_base / ws['counts_csv']).resolve())
    dst = workdir / 'working_raw_input_spec.json'
    save_json(dst, spec)
    for fname in DEPS:
        src = script_dir / fname
        if src.exists(): shutil.copy2(src, workdir / fname)
    return dst

def extract_runtime_action(raw_summary: dict):
    d = raw_summary.get('decision_summary') or raw_summary.get('decision') or {}
    return d.get('recommended_action') or d.get('top_level_recommended_action')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--raw-spec', required=True)
    ap.add_argument('--campaign-state', required=True)
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--python', default=sys.executable + ' -S')
    args = ap.parse_args()
    script_dir = Path(__file__).resolve().parent
    outdir = Path(args.outdir).resolve(); outdir.mkdir(parents=True, exist_ok=True)
    workdir = outdir / 'workdir'; workdir.mkdir(exist_ok=True)
    working_spec = normalize_raw_spec(Path(args.raw_spec).resolve(), workdir, script_dir)
    raw_out = outdir / '01_raw_supervisor'
    subprocess.run(shlex.split(args.python) + [str(workdir/'tmd_raw_input_compiled_supervisor_v0_2.py'), '--spec', str(working_spec), '--outdir', str(raw_out)], check=True)
    raw_summary_path = raw_out / 'raw_compiler_summary_v0_2.json'
    raw_summary = load_json(raw_summary_path)
    runtime_action = extract_runtime_action(raw_summary)
    campaign_state = load_json(args.campaign_state)
    override = campaign_state.get('runtime_action_override')
    chosen_runtime_action = override if override not in [None, ''] else runtime_action
    campaign_state['runtime_next_action'] = chosen_runtime_action
    campaign_state['runtime_original_action'] = runtime_action
    campaign_state_path = outdir / '02_campaign_state_with_runtime.json'
    save_json(campaign_state_path, campaign_state)
    camp_out = outdir / '02_adaptive_campaign'
    subprocess.run(shlex.split(args.python) + [str(workdir/'tmd_adaptive_dag_campaign_executor_v0_1.py'), '--state', str(campaign_state_path), '--outdir', str(camp_out)], check=True)
    campaign_output_path = camp_out / 'adaptive_campaign_executor_output_v0_1.json'
    campaign_output = load_json(campaign_output_path)
    campaign_output['runtime_original_action'] = runtime_action
    campaign_output['runtime_action'] = chosen_runtime_action
    save_json(campaign_output_path, campaign_output)
    manifest_path = outdir / '03_next_step_manifest_campaign_aware_v0_1.json'
    subprocess.run(shlex.split(args.python) + [str(workdir/'tmd_campaign_aware_manifest_compiler_v0_1.py'), '--campaign-output', str(campaign_output_path), '--runtime-summary', str(raw_summary_path), '--out', str(manifest_path)], check=True)
    manifest = load_json(manifest_path)
    summary = {
        'status': 'ok',
        'raw_summary_path': str(raw_summary_path),
        'runtime_original_action': runtime_action,
        'runtime_action_used_for_campaign': chosen_runtime_action,
        'campaign_state_path': str(campaign_state_path),
        'adaptive_campaign_output_path': str(campaign_output_path),
        'campaign_recommended_action': campaign_output.get('recommended_action'),
        'campaign_reason': campaign_output.get('reason'),
        'manifest_path': str(manifest_path),
        'manifest_status': manifest.get('status'),
        'manifest_stage_names': [s.get('name') for s in manifest.get('stages', [])],
        'warnings': campaign_output.get('warnings', [])
    }
    save_json(outdir / 'campaign_closed_loop_summary_v0_1.json', summary)
    print(json.dumps(summary, indent=2))

if __name__ == '__main__': main()
