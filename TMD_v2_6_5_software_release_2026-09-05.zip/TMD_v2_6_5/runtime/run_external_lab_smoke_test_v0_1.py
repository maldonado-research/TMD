#!/usr/bin/env python3
"""TMD external-lab smoke test runner v0.1.

Runs the portable full campaign-cycle runner across four representative cases:
1. root/default H482R action,
2. root/WS runtime override,
3. root/premature S487 mutation-spectrum override (should be blocked),
4. rpoB core complete + S487 Asn-homeostasis top-up.

No third-party packages are required. Recommended invocation:
  python -S run_external_lab_smoke_test_v0_1.py --outdir smoke_test_run
"""
from __future__ import annotations
import argparse, csv, hashlib, json, os, subprocess, sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
WORKFLOW = ROOT / "workflow"
TEMPLATES = ROOT / "templates"
RUNNER = WORKFLOW / "tmd_full_campaign_cycle_runner_v0_2_portable.py"
RAW_TEMPLATE = TEMPLATES / "TMD_raw_input_spec_template_v0_3_campaign_loop.json"
CAMPAIGN_TEMPLATE = TEMPLATES / "TMD_campaign_state_template_v0_2.json"


def load_json(p: Path) -> Any:
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def save_json(p: Path, obj: Any) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, sort_keys=False), encoding="utf-8")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    fields = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


def make_campaign_state(case: dict[str, Any], case_dir: Path) -> Path:
    st = load_json(CAMPAIGN_TEMPLATE)
    st["completed_actions"] = case.get("completed_actions", [])
    st["budget_remaining"] = case.get("budget_remaining", st.get("budget_remaining", 23))
    if case.get("runtime_action_override"):
        st["runtime_action_override"] = case["runtime_action_override"]
    st["smoke_test_case"] = case["case_id"]
    path = case_dir / "campaign_state.json"
    save_json(path, st)
    return path


def run_case(case: dict[str, Any], outdir: Path) -> dict[str, Any]:
    case_dir = outdir / case["case_id"]
    case_dir.mkdir(parents=True, exist_ok=True)
    campaign_state = make_campaign_state(case, case_dir)
    cmd = [
        sys.executable,
        "-S",
        str(RUNNER),
        "--raw-spec", str(RAW_TEMPLATE),
        "--campaign-state", str(campaign_state),
        "--run-id", case["run_id"],
        "--outdir", str(case_dir / "cycle"),
        "--allow-verifier-warning",
    ]
    proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    summary_path = case_dir / "cycle" / "full_campaign_cycle_summary_v0_2_portable.json"
    result: dict[str, Any] = {
        "case_id": case["case_id"],
        "run_id": case["run_id"],
        "returncode": proc.returncode,
        "stdout_tail": proc.stdout[-500:].replace("\n", " | "),
        "stderr_tail": proc.stderr[-500:].replace("\n", " | "),
        "summary_path": str(summary_path),
        "summary_exists": summary_path.exists(),
    }
    if summary_path.exists():
        summ = load_json(summary_path)
        result.update({
            "status": summ.get("status"),
            "completed_action": summ.get("completed_action"),
            "expected_completed_action": case.get("expected_completed_action"),
            "budget_before": summ.get("budget_before"),
            "budget_after": summ.get("budget_after"),
            "expected_budget_after": case.get("expected_budget_after"),
            "runtime_original_action": summ.get("runtime_original_action"),
            "runtime_action_used_for_campaign": summ.get("runtime_action_used_for_campaign"),
            "campaign_recommended_action": summ.get("campaign_recommended_action"),
            "manifest_status": summ.get("manifest_status"),
            "feedback_status": summ.get("feedback_status"),
            "campaign_update_status": summ.get("campaign_update_status"),
            "final_event_hash": summ.get("final_event_hash"),
            "next_optimal_completion_bundle": " | ".join(summ.get("next_optimal_completion_bundle") or []),
        })
        result["pass_completed_action"] = (summ.get("completed_action") == case.get("expected_completed_action"))
        result["pass_budget_after"] = (summ.get("budget_after") == case.get("expected_budget_after"))
        result["pass_status"] = (summ.get("status") == "ok" and summ.get("campaign_update_status") == "updated")
        result["pass_hash_present"] = bool(summ.get("final_event_hash"))
    else:
        result.update({
            "status": "missing_summary",
            "completed_action": "",
            "expected_completed_action": case.get("expected_completed_action"),
            "budget_after": "",
            "expected_budget_after": case.get("expected_budget_after"),
            "pass_completed_action": False,
            "pass_budget_after": False,
            "pass_status": False,
            "pass_hash_present": False,
        })
    result["case_pass"] = all(bool(result.get(k)) for k in ["pass_completed_action", "pass_budget_after", "pass_status", "pass_hash_present"]) and proc.returncode == 0
    return result


def main() -> None:
    ap = argparse.ArgumentParser(description="TMD external-lab smoke-test runner v0.1")
    ap.add_argument("--outdir", default="TMD_external_lab_smoke_test_run")
    args = ap.parse_args()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    cases = [
        {
            "case_id": "01_root_default_H482R",
            "run_id": "SMOKE_ROOT_H482R_001",
            "completed_actions": [],
            "budget_remaining": 23,
            "runtime_action_override": None,
            "expected_completed_action": "H482R_developmental_entry_proxy",
            "expected_budget_after": 18,
        },
        {
            "case_id": "02_root_WS_override",
            "run_id": "SMOKE_ROOT_WS_001",
            "completed_actions": [],
            "budget_remaining": 23,
            "runtime_action_override": "sample_next_replicate_in::Pf_WS_routes_v1",
            "expected_completed_action": "WS_new_context_flagship_replication",
            "expected_budget_after": 17,
        },
        {
            "case_id": "03_root_premature_S487_mu_blocked",
            "run_id": "SMOKE_PREMATURE_S487_MU_001",
            "completed_actions": [],
            "budget_remaining": 23,
            "runtime_action_override": "run_mu",
            "expected_completed_action": "H482R_developmental_entry_proxy",
            "expected_budget_after": 18,
        },
        {
            "case_id": "04_rpob_core_Asn_topup",
            "run_id": "SMOKE_RPOB_CORE_ASN_001",
            "completed_actions": ["H482R_developmental_entry_proxy", "S487L_pairwise_competition"],
            "budget_remaining": 13,
            "runtime_action_override": "Asn_homeostasis_topup_then_run_mu",
            "expected_completed_action": "S487_Asn_homeostasis_perturbation",
            "expected_budget_after": 6,
        },
    ]
    results = [run_case(c, outdir) for c in cases]
    write_csv(outdir / "TMD_external_lab_smoke_test_results_v0_1.csv", results)

    manifest = []
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and "__pycache__" not in str(p):
            manifest.append({"relative_path": str(p.relative_to(ROOT)), "sha256": sha256_file(p), "bytes": p.stat().st_size})
    write_csv(outdir / "TMD_external_lab_smoke_test_file_manifest_v0_1.csv", manifest)

    summary = {
        "smoke_test_version": "TMD_external_lab_smoke_test_v0_1",
        "n_cases": len(results),
        "n_pass": sum(1 for r in results if r.get("case_pass")),
        "all_cases_pass": all(r.get("case_pass") for r in results),
        "results_csv": str(outdir / "TMD_external_lab_smoke_test_results_v0_1.csv"),
        "case_ids": [r["case_id"] for r in results],
        "final_event_hashes": {r["case_id"]: r.get("final_event_hash") for r in results},
    }
    save_json(outdir / "TMD_external_lab_smoke_test_summary_v0_1.json", summary)
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
