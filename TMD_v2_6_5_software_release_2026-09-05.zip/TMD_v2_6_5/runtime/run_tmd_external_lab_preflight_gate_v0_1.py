#!/usr/bin/env python3
"""TMD external-lab preflight gate v0.1.

Runs both:
  1) external-lab smoke test (positive closed-loop cases), and
  2) failure-injection hardening suite (negative controls).

No third-party packages required. Recommended:
  python -S run_tmd_external_lab_preflight_gate_v0_1.py --outdir runs/preflight
"""
from __future__ import annotations
import argparse, csv, hashlib, json, subprocess, sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
SMOKE = ROOT / "run_external_lab_smoke_test_v0_1.py"
FAILURE = ROOT / "workflow" / "tmd_failure_injection_suite_v0_1.py"


def load_json(path: Path) -> Any:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=False), encoding="utf-8")


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def merkle_like_root(values: list[str]) -> str:
    # Deterministic compact root for a set/list of transition hashes.
    # Sort for set-like stability, then hash the canonical JSON list.
    canonical = json.dumps(sorted([v for v in values if v]), separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def run_cmd(cmd: list[str], cwd: Path, stdout_path: Path, stderr_path: Path) -> int:
    proc = subprocess.run(cmd, cwd=str(cwd), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stdout_path.write_text(proc.stdout, encoding="utf-8")
    stderr_path.write_text(proc.stderr, encoding="utf-8")
    return proc.returncode


def main() -> None:
    ap = argparse.ArgumentParser(description="Run the TMD external-lab preflight gate.")
    ap.add_argument("--outdir", default="TMD_external_lab_preflight_run")
    ap.add_argument("--skip-smoke", action="store_true")
    ap.add_argument("--skip-failure", action="store_true")
    args = ap.parse_args()

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    rows: list[dict[str, Any]] = []
    final_hashes: list[str] = []

    # Smoke test
    smoke_summary = None
    if not args.skip_smoke:
        smoke_dir = outdir / "01_smoke_test"
        cmd = [sys.executable, "-S", str(SMOKE), "--outdir", str(smoke_dir)]
        rc = run_cmd(cmd, ROOT, outdir / "logs" / "smoke_stdout.txt", outdir / "logs" / "smoke_stderr.txt")
        summary_path = smoke_dir / "TMD_external_lab_smoke_test_summary_v0_1.json"
        if summary_path.exists():
            smoke_summary = load_json(summary_path)
            final_hashes.extend([h for h in (smoke_summary.get("final_event_hashes") or {}).values() if h])
        rows.append({
            "gate": "external_lab_smoke_test",
            "returncode": rc,
            "summary_exists": summary_path.exists(),
            "pass": bool(smoke_summary and smoke_summary.get("all_cases_pass") and rc == 0),
            "n_cases": (smoke_summary or {}).get("n_cases", ""),
            "n_pass": (smoke_summary or {}).get("n_pass", ""),
            "details": str(summary_path),
        })

    # Failure injection
    failure_cert = None
    if not args.skip_failure:
        failure_dir = outdir / "02_failure_injection"
        cmd = [sys.executable, "-S", str(FAILURE), "--stack-dir", str(ROOT), "--outdir", str(failure_dir)]
        rc = run_cmd(cmd, ROOT, outdir / "logs" / "failure_stdout.txt", outdir / "logs" / "failure_stderr.txt")
        cert_path = failure_dir / "TMD_failure_injection_certificate_v0_1.json"
        if cert_path.exists():
            failure_cert = load_json(cert_path)
            # Capture the positive multicycle root if present in details.
            pmc = failure_cert.get("positive_multicycle_certificate")
            if pmc and Path(pmc).exists():
                try:
                    pc = load_json(Path(pmc))
                    root = pc.get("campaign_merkle_root")
                    if root:
                        final_hashes.append(root)
                except Exception:
                    pass
        rows.append({
            "gate": "failure_injection_hardening",
            "returncode": rc,
            "summary_exists": cert_path.exists(),
            "pass": bool(failure_cert and failure_cert.get("all_passed") and rc == 0),
            "n_cases": (failure_cert or {}).get("n_tests", ""),
            "n_pass": (failure_cert or {}).get("n_passed", ""),
            "details": str(cert_path),
        })

    all_pass = all(bool(r.get("pass")) for r in rows) and bool(rows)
    preflight_root = merkle_like_root(final_hashes + [sha256_file(ROOT / "run_tmd_external_lab_preflight_gate_v0_1.py")])

    # Pack manifest for source files only, excluding run outputs.
    pack_manifest = []
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and "__pycache__" not in str(p) and "/runs/" not in str(p):
            if str(p).startswith(str(outdir)):
                continue
            pack_manifest.append({
                "relative_path": str(p.relative_to(ROOT)),
                "sha256": sha256_file(p),
                "bytes": p.stat().st_size,
            })
    write_csv(outdir / "TMD_external_lab_preflight_pack_manifest_v0_1.csv", pack_manifest)
    write_csv(outdir / "TMD_external_lab_preflight_gate_results_v0_1.csv", rows)

    certificate = {
        "certificate_version": "TMD_external_lab_preflight_gate_v0_1",
        "all_passed": all_pass,
        "n_gates": len(rows),
        "n_passed": sum(1 for r in rows if r.get("pass")),
        "gates": rows,
        "preflight_merkle_like_root": preflight_root,
        "component_hashes_or_roots": final_hashes,
        "smoke_summary": str((outdir / "01_smoke_test" / "TMD_external_lab_smoke_test_summary_v0_1.json")) if not args.skip_smoke else None,
        "failure_certificate": str((outdir / "02_failure_injection" / "TMD_failure_injection_certificate_v0_1.json")) if not args.skip_failure else None,
        "notes": "External-lab preflight gate: smoke test plus failure-injection controls. Passing means the portable TMD closed-loop stack accepts happy paths and rejects key invalid transitions in this environment.",
    }
    save_json(outdir / "TMD_external_lab_preflight_certificate_v0_1.json", certificate)
    print(json.dumps(certificate, indent=2))
    if not all_pass:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
