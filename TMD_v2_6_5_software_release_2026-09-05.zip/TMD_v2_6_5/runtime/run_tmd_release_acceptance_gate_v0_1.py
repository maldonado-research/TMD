#!/usr/bin/env python3
"""TMD release-acceptance gate v0.1.

Runs the portable external-lab preflight gate and the root-budget multicycle campaign
proof. Pure Python; intended to run with `python -S`.
"""
import argparse
import csv
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timezone


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode('utf-8')).hexdigest()


def load_json(path: Path):
    with path.open('r', encoding='utf-8') as f:
        return json.load(f)


def run_cmd(cmd, cwd: Path, stdout_path: Path, stderr_path: Path):
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    with stdout_path.open('w', encoding='utf-8') as out, stderr_path.open('w', encoding='utf-8') as err:
        p = subprocess.run(cmd, cwd=str(cwd), stdout=out, stderr=err, text=True)
    return p.returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--outdir', default='runs/release_acceptance', help='Output directory')
    ap.add_argument('--max-cycles', type=int, default=8)
    args = ap.parse_args()

    base = Path(__file__).resolve().parent
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    logs = outdir / 'logs'
    logs.mkdir(exist_ok=True)

    results = []

    # Gate 1: external-lab preflight (smoke + failure injection)
    preflight_dir = outdir / '01_external_lab_preflight'
    cmd1 = [sys.executable, '-S', str(base / 'run_tmd_external_lab_preflight_gate_v0_1.py'), '--outdir', str(preflight_dir)]
    rc1 = run_cmd(cmd1, base, logs / 'preflight_stdout.txt', logs / 'preflight_stderr.txt')
    preflight_cert = preflight_dir / 'TMD_external_lab_preflight_certificate_v0_1.json'
    preflight_pass = False
    preflight_root = None
    if preflight_cert.exists():
        cert = load_json(preflight_cert)
        preflight_pass = bool(cert.get('all_passed'))
        preflight_root = cert.get('preflight_merkle_like_root')
    results.append({
        'gate': 'external_lab_preflight_smoke_plus_failure',
        'returncode': rc1,
        'certificate': str(preflight_cert),
        'pass': preflight_pass,
        'root': preflight_root or '',
    })

    # Gate 2: root budget-23 multicycle campaign proof
    multicycle_dir = outdir / '02_root23_multicycle_campaign'
    cmd2 = [
        sys.executable, '-S', str(base / 'workflow' / 'tmd_multicycle_campaign_runner_v0_1.py'),
        '--raw-spec', str(base / 'templates' / 'TMD_raw_input_spec_template_v0_3_campaign_loop.json'),
        '--campaign-state', str(base / 'templates' / 'TMD_campaign_state_template_v0_2.json'),
        '--outdir', str(multicycle_dir),
        '--max-cycles', str(args.max_cycles),
        '--run-prefix', 'RELEASE_ACCEPTANCE_ROOT23'
    ]
    rc2 = run_cmd(cmd2, base, logs / 'multicycle_stdout.txt', logs / 'multicycle_stderr.txt')
    multicycle_cert = multicycle_dir / 'TMD_multicycle_campaign_certificate_v0_1.json'
    multi_pass = False
    multi_root = None
    expected_actions = [
        'H482R_developmental_entry_proxy',
        'S487L_pairwise_competition',
        'WS_new_context_flagship_replication',
        'S487_Asn_homeostasis_perturbation'
    ]
    if multicycle_cert.exists():
        cert = load_json(multicycle_cert)
        acts = cert.get('completed_actions') or cert.get('cycle_completed_actions') or []
        multi_pass = bool(acts == expected_actions and cert.get('final_budget_after') == 0 and cert.get('campaign_merkle_root'))
        multi_root = cert.get('campaign_merkle_root')
    results.append({
        'gate': 'root23_multicycle_campaign_proof',
        'returncode': rc2,
        'certificate': str(multicycle_cert),
        'pass': multi_pass,
        'root': multi_root or '',
    })

    all_passed = all(r['pass'] for r in results) and all(r['returncode'] == 0 for r in results)
    component_roots = [r['root'] for r in results if r['root']]
    acceptance_root = sha256_text(json.dumps(component_roots, sort_keys=True, separators=(',', ':')))

    cert = {
        'certificate_version': 'TMD_release_acceptance_gate_v0_1',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'all_passed': all_passed,
        'n_gates': len(results),
        'n_passed': sum(1 for r in results if r['pass'] and r['returncode'] == 0),
        'gates': results,
        'release_acceptance_root': acceptance_root,
        'component_roots': component_roots,
        'expected_multicycle_actions': expected_actions,
        'notes': 'Release acceptance = external-lab preflight plus root-budget multicycle campaign proof.'
    }

    cert_path = outdir / 'TMD_release_acceptance_certificate_v0_1.json'
    with cert_path.open('w', encoding='utf-8') as f:
        json.dump(cert, f, indent=2, sort_keys=True)
        f.write('\n')

    csv_path = outdir / 'TMD_release_acceptance_results_v0_1.csv'
    with csv_path.open('w', newline='', encoding='utf-8') as f:
        fieldnames = ['gate', 'returncode', 'pass', 'root', 'certificate']
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in results:
            w.writerow({k: r.get(k, '') for k in fieldnames})

    print(json.dumps(cert, indent=2, sort_keys=True))
    return 0 if all_passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
