# TMD failure-injection action memo v0.1 — 2026-05-04

## What this pack adds

This pack makes the external-lab workflow safer. A collaborator can now prove that the campaign stack not only follows the intended happy path, but also rejects invalid or tampered transitions.

## Recommended use

Run this suite before accepting a new external-lab installation as operational:

```bash
python -S workflow/tmd_failure_injection_suite_v0_1.py --stack-dir . --outdir runs/failure_injection
```

Acceptance criterion:

```text
TMD_failure_injection_certificate_v0_1.json :: all_passed == true
```

## Why it matters

The current TMD stack is now guarded by:

1. positive multi-cycle validation;
2. DAG-prerequisite rejection tests;
3. budget rejection tests;
4. replay-ledger tamper rejection;
5. WS schema-regression check;
6. event-hash advancement check.

This makes the v2.6 execution layer closer to an external validation harness rather than a chat-local prototype.
