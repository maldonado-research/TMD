# TMD v2.6.3 release-acceptance note — 2026-05-06

This patch adds a single release-acceptance gate above the lite external-lab preflight pack.

The new gate is intentionally small and portable. It runs under:

```bash
python -S
```

and combines two existing readiness checks:

- the external-lab preflight gate, which includes smoke tests and failure-injection controls;
- the root budget-23 multicycle campaign proof.

## The new practical invariant

A TMD release candidate is execution-ready for external-lab dry runs only if:

```text
external_lab_preflight == pass
root23_multicycle_campaign == pass
```

The first checks local transition validity and rejection of invalid states. The second checks that repeated campaign transitions can advance the DAG-valid campaign frontier.

## Current use

This pack should be the first artifact sent to a collaborator when they only need to test runtime compatibility.

For full source/provenance, use the larger current-stack bundles. For mobile or unreliable download environments, use this lite acceptance pack first.
