# START HERE — TMD failure-injection hardening suite v0.1

This pack extends the multi-cycle TMD campaign runner with negative-control tests.

Run:

```bash
python -S workflow/tmd_failure_injection_suite_v0_1.py \
  --stack-dir . \
  --outdir runs/failure_injection
```

Expected result:

```text
n_tests = 9
all_passed = true
```

The suite validates that the stack accepts the multi-cycle happy path and rejects:

- duplicate campaign completions;
- premature S487 mutation-spectrum assay before prerequisites;
- budget overrun;
- unknown campaign action;
- unverified completion;
- tampered replay ledger;
- WS feedback schema regression.

It also confirms that a valid accepted action advances the campaign event hash.
