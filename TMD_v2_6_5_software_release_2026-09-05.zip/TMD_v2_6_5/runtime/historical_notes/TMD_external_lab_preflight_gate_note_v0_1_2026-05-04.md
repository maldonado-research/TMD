# TMD external-lab preflight gate v0.1

## Purpose

The TMD closed-loop stack has positive execution tests, failure-injection tests, replay ledgers, and a campaign-state updater. The preflight gate composes those into one external-lab readiness check.

## Preflight invariant

Let `G_smoke` be the positive smoke-test gate and `G_fail` be the failure-injection hardening gate. The preflight passes iff:

\[
G_{smoke}=\text{pass}\quad\text{and}\quad G_{fail}=\text{pass}.
\]

The emitted preflight certificate commits to component transition hashes/campaign roots and the preflight script hash with a deterministic Merkle-like root.

## Interpretation

A passing preflight does not validate the biological claims of TMD. It validates that the portable execution stack can:

- run representative closed-loop dry-run transitions;
- enforce campaign DAG prerequisites;
- reject invalid transitions;
- detect replay-ledger tampering;
- preserve the WS feedback schema patch;
- generate auditable certificates.

## Recommended use

Run the preflight before accepting any external lab result bundle into the TMD campaign log.
