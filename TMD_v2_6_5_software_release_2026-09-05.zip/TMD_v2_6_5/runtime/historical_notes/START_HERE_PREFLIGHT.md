# START HERE — TMD external-lab preflight gate v0.1

This pack combines the TMD positive smoke test and the failure-injection hardening suite into one portable preflight gate.

Run from the pack root:

```bash
python -S run_tmd_external_lab_preflight_gate_v0_1.py --outdir runs/preflight
```

Acceptance criterion:

```text
runs/preflight/TMD_external_lab_preflight_certificate_v0_1.json :: all_passed == true
```

The preflight gate checks two things:

1. **Positive closed-loop behavior** — four representative dry-run transitions complete and update campaign budget as expected.
2. **Negative controls** — duplicate actions, premature actions, budget overruns, unknown actions, unverified completions, tampered ledgers, and WS feedback-schema regressions are rejected.

If the preflight passes, proceed to real data by filling the manifest result CSV and running the full portable campaign cycle.
