# Historical runtime notes

The other documents in this directory are unchanged notes inherited from the May 14, 2026 v2.6.4 source bundle. Their historical version names, paths and validation statements describe that earlier work. Run commands shown in them from the parent runtime directory, not from this notes directory.

Current release instructions and validation are provided by the new release at the package root. The active runtime includes a narrow UTC timestamp compatibility correction; the old documents are retained as technical provenance, not as new empirical evidence.
