# TMD v2.6.3 lite release-acceptance gate

This pack is a small, mobile-friendly external-lab entrypoint for the Theory of Mutation by Natural Dominance (TMD) closed-loop workflow.

Run:

```bash
python -S run_tmd_release_acceptance_gate_v0_1.py --outdir runs/release_acceptance
```

Acceptance criterion:

```text
runs/release_acceptance/TMD_release_acceptance_certificate_v0_1.json :: all_passed == true
```

The release-acceptance gate combines:

1. external-lab preflight: smoke test + failure-injection hardening;
2. root budget-23 multicycle campaign proof.

A pass means the portable stack can:

- run without scientific Python dependencies;
- accept valid closed-loop campaign transitions;
- reject key invalid transitions;
- preserve the WS feedback schema patch;
- advance the root budget-23 campaign through the expected DAG-valid sequence:
  - H482R developmental-entry proxy;
  - S487L pairwise competition;
  - WS new-context flagship replication;
  - S487 Asn-homeostasis perturbation.

This validates execution readiness, not biological truth.
