# TMD failure-injection theorem note v0.1 — 2026-05-04

## Purpose

The TMD v2.6 closed-loop campaign stack already had a positive multi-cycle validation path. The missing robustness layer was a negative-control suite that proves the same stack rejects invalid transitions.

## Invariant family

Let `S` be the completed campaign action set, `B` the remaining budget, `D(a)` the prerequisite set for action `a`, and `H` a verified replay-ledger final event hash.

A campaign completion is acceptable only if:

\[
a
otin S,\quad D(a)\subseteq S,\quad c(a)\le B,\quad H\in\mathcal H_{verified}.
\]

The accepted update is:

\[
S' = S\cup\{a\},\qquad B' = B-c(a).
\]

If any condition fails, the campaign state must remain unchanged and the updater must emit an error.

## Ledger tamper invariant

For replay-ledger events \(E_t\), every event hash is:

\[
H_t=\mathrm{SHA256}(\mathrm{canonical\_json}(E_t\setminus\{event\_hash\})).
\]

If any event payload is changed without recomputing the full downstream chain, the verifier must reject the ledger.

## WS schema invariant

A WS single-replicate result is an outcome record. It must not overwrite a count-shaped `WS.counts_csv` field. Instead, feedback writes:

```text
WS.replicate_outcomes_csv
WS.outcome_counts_csv
```

and preserves `WS.counts_csv` unless it is already count-shaped.

## Validation suite

The new failure-injection suite performs one positive multi-cycle run plus negative controls for duplicate completion, missing prerequisites, insufficient budget, unknown action, unverified completion, tampered ledger, and WS schema regression.
