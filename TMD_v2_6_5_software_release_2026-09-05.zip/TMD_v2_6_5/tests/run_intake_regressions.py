#!/usr/bin/env python3
"""Exercise real CLI results against malformed and inconsistent submissions."""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', action='store_true')
    parser.add_argument('--package-root', type=Path, default=None,
                        help='Release folder containing submission/ and intake/.')
    parser.add_argument('--outdir', type=Path, default=None,
                        help='Dedicated directory for generated test data and reports.')
    parser.add_argument('--runtime-validation', type=Path, default=None,
                        help='Fresh output of the release acceptance runner; also exercise all four generated cycles.')
    parser.add_argument('--runtime-root', type=Path, default=None,
                        help='Run this runtime directory\'s acceptance gate, then test all four generated cycles.')
    args = parser.parse_args()
    release_root = args.package_root
    if release_root is None and (ROOT.parent / 'submission').is_dir(): release_root = ROOT.parent
    pack = release_root / 'submission' if release_root else ROOT / 'tmd_submission_acceptance_2026_05_07'
    intake = release_root / 'intake' if release_root else ROOT / 'tmd_result_intake_2026_05_06'
    target = args.outdir or ROOT / ('regression_baseline' if args.baseline else 'regression_fixed')
    target.mkdir(exist_ok=True, parents=True)
    if args.runtime_root:
        if args.runtime_validation: raise ValueError('choose either --runtime-root or --runtime-validation')
        runtime_output = (target / 'fresh_runtime_acceptance').resolve()
        if runtime_output.exists(): shutil.rmtree(runtime_output)
        gate = (args.runtime_root / 'run_tmd_release_acceptance_gate_v0_1.py').resolve()
        command = [sys.executable, '-S', str(gate), '--outdir', str(runtime_output)]
        proc = subprocess.run(command, capture_output=True, text=True, timeout=180)
        (target / 'runtime_gate_stdout.txt').write_text(proc.stdout)
        (target / 'runtime_gate_stderr.txt').write_text(proc.stderr)
        if proc.returncode != 0: raise RuntimeError('fresh runtime acceptance failed; inspect runtime gate logs')
        args.runtime_validation = runtime_output
    rows = []
    cases = ['valid', 'tampered', 'empty_certificate_only', 'certificate_without_ledger', 'ledger_without_certificate',
             'empty_certificate', 'failed_hash_flag', 'missing_hash_flags',
             'top_level_action_mismatch', 'malformed_event', 'nonobject_ledger',
             'failed_ledger_status', 'contradictory_certificate_gate',
             'bad_campaign_root', 'missing_manifest_event', 'duplicate_json_key',
             'negative_action_cost', 'fractional_budget', 'explicit_action_mismatch',
             'duplicate_action', 'missing_prerequisite', 'insufficient_budget']
    for case in cases:
        submitted = target / case / 'submission'
        if submitted.parent.exists():
            shutil.rmtree(submitted.parent)
        source = pack / 'examples' / ('tampered_submission' if case == 'tampered' else 'valid_submission')
        shutil.copytree(source, submitted)
        ledger = next(submitted.glob('*replay_ledger*.json'))
        d = json.loads(ledger.read_text())
        cert = submitted / 'TMD_release_acceptance_certificate_v0_1.json'
        c = json.loads(cert.read_text())
        state = json.loads((pack / 'templates/TMD_campaign_state_template_v0_2.json').read_text())
        slate = (pack / 'templates/TMD_adaptive_campaign_action_slate_v0_1.csv').read_text()
        if case == 'empty_certificate_only':
            for p in submitted.iterdir(): p.unlink()
            cert.write_text('{}')
        elif case == 'certificate_without_ledger': ledger.unlink()
        elif case == 'ledger_without_certificate':
            for p in submitted.glob('*certificate*.json'): p.unlink()
        elif case == 'empty_certificate': cert.write_text('{}')
        elif case == 'failed_hash_flag': d['hash_checks']['result_matches_feedback'] = False
        elif case == 'missing_hash_flags': d.pop('hash_checks')
        elif case == 'top_level_action_mismatch': d['manifest_action'] = 'S487L_pairwise_competition'
        elif case == 'malformed_event': d['events'][0] = 'not an object'
        elif case == 'nonobject_ledger': d = []
        elif case == 'failed_ledger_status': d['status'] = 'invalid'
        elif case == 'contradictory_certificate_gate':
            c['gates'][0]['pass'] = False
            cert.write_text(json.dumps(c))
        elif case == 'bad_campaign_root':
            p = submitted / 'TMD_multicycle_campaign_certificate_v0_1.json'
            m = json.loads(p.read_text()); m['campaign_merkle_root'] = '0' * 64
            p.write_text(json.dumps(m))
        elif case == 'missing_manifest_event':
            import hashlib
            d['events'][1]['event_type'] = 'unrecognized'
            prev = 'GENESIS'
            for event in d['events']:
                event['previous_event_hash'] = prev
                payload = {k: event[k] for k in ['index','event_type','previous_event_hash','payload']}
                event['event_hash'] = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
                prev = event['event_hash']
            d['final_event_hash'] = prev
        elif case == 'negative_action_cost': slate = slate.replace('A/F,5,15', 'A/F,-5,15')
        elif case == 'fractional_budget': state['budget_remaining'] = 23.5
        elif case == 'duplicate_action': state['completed_actions'] = ['H482R_developmental_entry_proxy']
        elif case == 'insufficient_budget': state['budget_remaining'] = 4
        elif case == 'missing_prerequisite':
            slate = slate.replace('A/F,5,15,(none)', 'A/F,5,15,S487L_pairwise_competition')
        if case not in {'empty_certificate_only','certificate_without_ledger'}:
            ledger.write_text(json.dumps(d))
        if case == 'duplicate_json_key':
            cert.write_text('{"certificate_version":"test","all_passed":false,"all_passed":true}')
        state_path = target / case / 'state.json'
        state_path.write_text(json.dumps(state))
        slate_path = target / case / 'slate.csv'
        slate_path.write_text(slate)
        for kind in ['intake', 'acceptor']:
            if kind == 'intake' and case in {'negative_action_cost','fractional_budget','explicit_action_mismatch','duplicate_action','missing_prerequisite','insufficient_budget'}:
                continue
            script = intake / 'tmd_external_result_intake_validator_v0_1.py' if kind == 'intake' else pack / 'workflow/tmd_external_submission_acceptor_v0_1.py'
            if args.baseline: script = ROOT / 'baseline' / script.name
            outdir = target / case / kind
            if kind == 'intake':
                command = [sys.executable, '-S', str(script), str(submitted), '--outdir', str(outdir)]
                filename = 'TMD_external_result_intake_validation_summary_v0_1.json'
                field = 'all_passed'
            else:
                command = [sys.executable, '-S', str(script), '--submission-dir', str(submitted), '--campaign-state', str(state_path), '--action-slate', str(slate_path), '--runtime-map', str(pack / 'templates/TMD_runtime_to_campaign_action_map_v0_1.csv'), '--outdir', str(outdir)]
                if case == 'explicit_action_mismatch': command += ['--completion-action', 'S487L_pairwise_competition']
                filename = 'TMD_external_submission_acceptance_report_v0_1.json'
                field = 'accepted'
            proc = subprocess.run(command, capture_output=True, text=True, timeout=20)
            (outdir.parent / (kind + '_stderr.txt')).write_text(proc.stderr)
            report = json.loads((outdir / filename).read_text()) if (outdir / filename).exists() else {}
            expected = case == 'valid'
            observed = report.get(field)
            passed = observed is expected and proc.returncode == (0 if expected else 2)
            rows.append({'case':case,'tool':kind,'expected':expected,'observed':observed,'exit_code':proc.returncode,'pass':passed})
    # Rejection must neither expose stale success as a new result nor delete an input state.
    script = pack / 'workflow/tmd_external_submission_acceptor_v0_1.py'
    if args.baseline: script = ROOT / 'baseline' / script.name
    reused = target / 'output_reuse'
    if reused.exists(): shutil.rmtree(reused)
    common = [sys.executable, '-S', str(script), '--action-slate', str(pack / 'templates/TMD_adaptive_campaign_action_slate_v0_1.csv'), '--runtime-map', str(pack / 'templates/TMD_runtime_to_campaign_action_map_v0_1.csv'), '--outdir', str(reused)]
    initial = pack / 'templates/TMD_campaign_state_template_v0_2.json'
    good = pack / 'examples/valid_submission'
    bad = pack / 'examples/tampered_submission'
    first = subprocess.run(common + ['--submission-dir', str(good), '--campaign-state', str(initial)], capture_output=True, text=True, timeout=20)
    output_state = reused / 'updated_campaign_state_v0_1.json'
    before = output_state.read_bytes() if output_state.exists() else None
    second = subprocess.run(common + ['--submission-dir', str(good), '--campaign-state', str(output_state)], capture_output=True, text=True, timeout=20)
    unchanged = output_state.exists() and output_state.read_bytes() == before
    rows.append({'case':'rejection_preserves_campaign_input','tool':'acceptor','expected':'input retained','observed':'input retained' if unchanged else 'input missing/changed','exit_code':second.returncode,'pass':first.returncode == 0 and second.returncode == 2 and unchanged})
    third = subprocess.run(common + ['--submission-dir', str(bad), '--campaign-state', str(initial)], capture_output=True, text=True, timeout=20)
    rows.append({'case':'rejection_clears_stale_output','tool':'acceptor','expected':'stale output absent','observed':'stale output present' if output_state.exists() else 'stale output absent','exit_code':third.returncode,'pass':third.returncode == 2 and not output_state.exists()})
    # A truncated configuration row must replace the previous report with a rejection.
    subprocess.run(common + ['--submission-dir', str(good), '--campaign-state', str(initial)], capture_output=True, text=True, timeout=20)
    broken_slate = target / 'truncated_slate.csv'
    broken_slate.write_text('action,cost_units,priority_score,requires\nH482R_developmental_entry_proxy\n')
    broken_command = list(common)
    broken_command[broken_command.index('--action-slate') + 1] = str(broken_slate)
    broken = subprocess.run(broken_command + ['--submission-dir', str(good), '--campaign-state', str(initial)], capture_output=True, text=True, timeout=20)
    rejected = json.loads((reused / 'TMD_external_submission_acceptance_report_v0_1.json').read_text()).get('accepted') is False
    rows.append({'case':'truncated_slate_replaces_stale_success','tool':'acceptor','expected':'rejected with no generated state','observed':'rejected with no generated state' if rejected and not output_state.exists() else 'stale success remains','exit_code':broken.returncode,'pass':broken.returncode == 2 and rejected and not output_state.exists()})
    if args.runtime_validation:
        if args.baseline: raise ValueError('runtime integration requires the corrected package')
        runtime = args.runtime_validation
        cycle_root = runtime / '02_root23_multicycle_campaign'
        certificate_paths = [runtime / 'TMD_release_acceptance_certificate_v0_1.json',
                             runtime / '01_external_lab_preflight/TMD_external_lab_preflight_certificate_v0_1.json',
                             cycle_root / 'TMD_multicycle_campaign_certificate_v0_1.json']
        certificate = json.loads(certificate_paths[-1].read_text())
        integration = target / 'runtime_integration'
        if integration.exists(): shutil.rmtree(integration)
        integration.mkdir()
        expected_actions = ['H482R_developmental_entry_proxy', 'S487L_pairwise_competition',
                            'WS_new_context_flagship_replication', 'S487_Asn_homeostasis_perturbation']
        expected_budgets = [18, 13, 7, 0]
        current_state = pack / 'templates/TMD_campaign_state_template_v0_2.json'
        for cycle, (action, budget) in enumerate(zip(expected_actions, expected_budgets), 1):
            submitted = integration / f'cycle_{cycle:02}' / 'submission'
            submitted.mkdir(parents=True)
            ledgers = list((cycle_root / f'cycle_{cycle:02}' / '04_replay_ledger').glob('*event_sourced_replay_ledger*.json'))
            if len(ledgers) != 1: raise ValueError('expected exactly one generated ledger per cycle')
            for source in [ledgers[0]] + certificate_paths: shutil.copy2(source, submitted)
            ledger = json.loads(ledgers[0].read_text())
            leaf_is_recorded = ledger.get('final_event_hash') in certificate.get('final_event_hashes_sorted', [])
            intake_out = submitted.parent / 'intake'
            command = [sys.executable, '-S', str(intake / 'tmd_external_result_intake_validator_v0_1.py'), str(submitted), '--outdir', str(intake_out)]
            proc = subprocess.run(command, capture_output=True, text=True, timeout=20)
            report_path = intake_out / 'TMD_external_result_intake_validation_summary_v0_1.json'
            report = json.loads(report_path.read_text()) if report_path.exists() else {}
            passed = proc.returncode == 0 and report.get('all_passed') is True and leaf_is_recorded
            rows.append({'case':f'fresh_runtime_cycle_{cycle}_intake','tool':'intake','expected':True,'observed':report.get('all_passed'),'exit_code':proc.returncode,'ledger_hash_in_campaign_certificate':leaf_is_recorded,'pass':passed})
            accept_out = submitted.parent / 'acceptor'
            command = [sys.executable, '-S', str(script), '--submission-dir', str(submitted), '--campaign-state', str(current_state), '--outdir', str(accept_out)]
            proc = subprocess.run(command, capture_output=True, text=True, timeout=20)
            report_path = accept_out / 'TMD_external_submission_acceptance_report_v0_1.json'
            report = json.loads(report_path.read_text()) if report_path.exists() else {}
            passed = proc.returncode == 0 and report.get('accepted') is True and report.get('completion_action') == action and report.get('budget_after') == budget
            rows.append({'case':f'fresh_runtime_cycle_{cycle}_acceptance','tool':'acceptor','expected':True,'observed':report.get('accepted'),'expected_action':action,'observed_action':report.get('completion_action'),'expected_budget':budget,'observed_budget':report.get('budget_after'),'exit_code':proc.returncode,'pass':passed})
            current_state = accept_out / 'updated_campaign_state_v0_1.json'
    summary = {'suite':'TMD_intake_hardening_regressions_2026_09_05', 'baseline':args.baseline,
               'n_cases':len(rows),'n_passed':sum(r['pass'] for r in rows), 'all_passed':all(r['pass'] for r in rows),'cases':rows}
    (target / 'regression_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))
    return 0 if summary['all_passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
