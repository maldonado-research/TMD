#!/usr/bin/env python3
"""Verify distributed file bytes against this release's SHA-256 manifest."""
import hashlib
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
manifest = root / "SHA256SUMS.txt"
if not manifest.is_file():
    sys.exit("FAIL: SHA256SUMS.txt is missing")
failures = []
listed = set()
for line in manifest.read_text(encoding="utf-8").splitlines():
    expected, relative = line.split("  ", 1)
    path = (root / relative).resolve()
    if not path.is_relative_to(root) or relative in listed:
        failures.append(relative + ": unsafe or duplicate manifest entry")
        continue
    listed.add(relative)
    if not path.is_file():
        failures.append(relative + ": missing")
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        failures.append(relative + ": checksum mismatch")
if failures:
    print("FAIL\n" + "\n".join(failures))
    sys.exit(1)
print("PASS: verified %d distributed files" % len(listed))
print("Generated run files are not covered by the distribution manifest.")
