# Theory of Mutation by Natural Dominance (TMD) — v2.6.5: portable campaign execution and stricter result acceptance

Version 2.6.5 | 2026-09-05 | Ricardo Maldonado

This package advances the May 14 v2.6.4 software bundle with a Python compatibility repair, consistent campaign-action fields in new replay ledgers, and stricter validation of submitted evidence packages. It contains a portable analysis workflow, examples, validation tools, and reproducibility evidence. It adds no new biological measurements.

## In More Basic Terms

TMD studies why some evolutionary routes occur more often than others. Its models consider how often a change becomes available and how likely that change is to establish itself. Testing those models requires observations whose origin, processing, and uncertainty can be checked.

This software acts like a research notebook with a task planner. It selects an eligible next analysis, reads a result file, checks the record, updates the remaining budget, and records what happened. The included dry runs use examples and simulated results.

This update improves whether those steps run reliably and whether incomplete or inconsistent evidence is rejected. A passing software check is evidence about the program's behavior. It does not demonstrate biological truth, an independent laboratory replication, or a unified theory of everything.

## Quick start

The portable runtime was tested on Python 3.9.6 and 3.12.14 on the same Mac. No third-party Python packages are required for the portable checks.

From the extracted package root:

```bash
python3 -S runtime/run_tmd_release_acceptance_gate_v0_1.py --outdir runs/release_acceptance
```

Inspect `runs/release_acceptance/TMD_release_acceptance_certificate_v0_1.json`; the expected value of `all_passed` is `true`. This combines a smoke test, failure-injection controls, and a simulated campaign with four prerequisite-valid actions and an initial budget of 23.

Run the September regression and integration checks from the package root:

```bash
python3 -S tests/run_intake_regressions.py --runtime-root runtime --outdir runs/intake_regressions
```

The expected result is 49 of 49 checks passing. This includes 41 targeted controls and eight checks that pass four freshly generated campaign ledgers through intake and sequential state acceptance. Both Python 3.9.6 and 3.12.14 passed this suite from the final staged package. Use a dedicated output directory: the test suite recreates its named fixture folders.

The top-level SHA-256 manifest covers the distributed files and excludes itself. Verify it before running:

```bash
python3 -S verify_release.py
```

## Package layout

- `runtime/`: portable campaign workflow, example inputs, and acceptance gate.
- `intake/`: checks a returned result package before use.
- `submission/`: verifies a result package before applying a campaign-state transition.
- `tests/`: regression checks for the September changes.
- `evidence/`: compact reports from the local validation runs.
- `docs/`: release note, basic-terms explanation, provenance, and licensing.

Instructions inside historical source notes describe their original versions. This top-level README and the September release note identify the supported entry points for this release.

## Interpretation and limits

These checks exercise example inputs, simulated transitions, and intentionally invalid packages. They do not estimate performance on unseen biological data. The numerical model and experimental claims require separate scientific evaluation.

An internally consistent hash chain cannot authenticate its author or prove that a laboratory experiment occurred. These tools are consistency checks, not digital signatures. Source observations, independent provenance, suitable controls, and comparison models remain necessary for scientific validation.

The validators also do not reread the original raw files referenced inside historical ledgers or authenticate a link from a submitted certificate to a particular measurement. Their reports explicitly disclose these limits. See `docs/INTAKE_SCOPE_AND_CHANGES_2026-09-05.md` for the supported schemas and precise scope.

This release follows TMD v2.6.4, published 2026-05-14 at https://zenodo.org/records/20186340 . See `CITATION.cff` for this version's citation and `docs/LICENSING.md` for the applicable license notices.

Version DOI: https://doi.org/10.5281/zenodo.22398093 .

The next scientific step is an independent, preregistered evaluation: define predictions, comparison models, and analysis choices before examining new observations, preserve source data, and report both successes and failures.
