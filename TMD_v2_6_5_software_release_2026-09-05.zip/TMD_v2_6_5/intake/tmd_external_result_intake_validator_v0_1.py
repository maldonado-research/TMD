#!/usr/bin/env python3
"""TMD external result intake validator v0.2 (legacy filename retained).
Pure-Python checker for a submitted TMD result bundle.
Checks supported certificate fields and replay-ledger internal consistency.
Does not authenticate source artifacts, submitters, or empirical results.
"""
import argparse, csv, hashlib, json, os, sys
from pathlib import Path


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def sha256_file(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key: ' + key)
        result[key] = value
    return result


def _reject_constant(value):
    raise ValueError('non-finite JSON number: ' + value)


def read_json(path):
    with open(path, encoding='utf-8') as stream:
        return json.load(stream, object_pairs_hook=_unique_object,
                         parse_constant=_reject_constant)


def _is_hash(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def _positive_int(value):
    return type(value) is int and value > 0


def _merkle(leaves):
    levels = [sorted(leaves)]
    while len(levels[-1]) > 1:
        level = levels[-1]
        levels.append([sha256_text(level[i] + (level[i+1] if i+1 < len(level) else level[i]))
                       for i in range(0, len(level), 2)])
    return levels[-1][0], levels


def verify_ledger(path):
    out = {'file': str(path), 'type': 'ledger', 'status': 'invalid', 'errors': [], 'warnings': []}
    try:
        d = read_json(path)
    except (ValueError, OSError) as error:
        out['errors'].append('json_parse_error: ' + str(error)); return out
    if not isinstance(d, dict):
        out['errors'].append('ledger must be a JSON object'); return out
    events = d.get('events')
    if not isinstance(events, list) or not events:
        out['errors'].append('missing_or_empty_events'); return out
    if d.get('status') != 'valid': out['errors'].append('ledger status is not valid')
    if d.get('ledger_version') != 'TMD_event_sourced_replay_ledger_v0_1':
        out['errors'].append('unsupported or missing ledger_version')
    required = ['state_before', 'manifest_issued', 'result_observed', 'feedback_reduced', 'state_after']
    if [e.get('event_type') if isinstance(e, dict) else None for e in events] != required:
        out['errors'].append('ledger must contain the five supported events in order')
    by_type = {}
    previous = 'GENESIS'
    for index, event in enumerate(events, start=1):
        if not isinstance(event, dict):
            out['errors'].append(f'event {index}: must be an object'); continue
        if type(event.get('index')) is not int or event['index'] != index:
            out['errors'].append(f'event {index}: index mismatch')
        if event.get('previous_event_hash') != previous:
            out['errors'].append(f'event {index}: previous_event_hash mismatch')
        payload = event.get('payload')
        if not isinstance(payload, dict):
            out['errors'].append(f'event {index}: payload must be an object')
        elif isinstance(event.get('event_type'), str):
            by_type[event['event_type']] = payload
        committed = {k: event.get(k) for k in ['index', 'event_type', 'previous_event_hash', 'payload']}
        if not _is_hash(event.get('event_hash')) or sha256_text(canonical(committed)) != event.get('event_hash'):
            out['errors'].append(f'event {index}: event_hash mismatch')
        previous = event.get('event_hash')
    if not _is_hash(d.get('final_event_hash')) or d.get('final_event_hash') != previous:
        out['errors'].append('final_event_hash does not match last event')
    checks = d.get('hash_checks')
    required_checks = ['state_before_matches_feedback_spec', 'manifest_matches_feedback',
                       'result_matches_feedback', 'state_after_exists']
    if not isinstance(checks, dict) or any(checks.get(key) is not True for key in required_checks):
        out['errors'].append('missing or failed required hash_checks')
    elif any(value is not True for value in checks.values()):
        out['errors'].append('hash_checks contains a non-passing value')
    artifacts = d.get('artifact_hashes')
    if not isinstance(artifacts, dict):
        out['errors'].append('missing artifact_hashes')
    else:
        for key, event_type in [('state_before','state_before'), ('manifest','manifest_issued'),
                                ('result_csv','result_observed'), ('feedback_report','feedback_reduced'),
                                ('state_after','state_after')]:
            digest = artifacts.get(key)
            if not _is_hash(digest) or digest != by_type.get(event_type, {}).get('sha256'):
                out['errors'].append('artifact hash does not match committed event: ' + key)
    manifest = by_type.get('manifest_issued', {})
    action = manifest.get('recommended_action')
    if not isinstance(action, str) or not action or action != d.get('manifest_action'):
        out['errors'].append('manifest_action differs from committed manifest event')
    if manifest.get('recommended_branch') != d.get('manifest_branch'):
        out['errors'].append('manifest_branch differs from committed manifest event')
    feedback = by_type.get('feedback_reduced', {})
    if feedback.get('status') != d.get('feedback_status'):
        out['errors'].append('feedback_status differs from committed feedback event')
    patch = feedback.get('patch_report', {})
    if not isinstance(patch, dict) or patch.get('action') != action:
        out['errors'].append('feedback action differs from committed manifest event')
    out.update({'run_id': d.get('run_id'), 'manifest_action': action,
                'manifest_branch': manifest.get('recommended_branch'),
                'final_event_hash': d.get('final_event_hash'), 'ledger_status_field': d.get('status'),
                'verification_scope': 'internal consistency only; source artifacts and submitter identity not authenticated'})
    out['status'] = 'valid' if not out['errors'] else 'invalid'
    return out


def check_certificate(path):
    out = {'file': str(path), 'type': 'certificate', 'status': 'invalid', 'errors': [], 'warnings': []}
    try:
        d = read_json(path)
    except (ValueError, OSError) as error:
        out['errors'].append('json_parse_error: ' + str(error)); return out
    if not isinstance(d, dict):
        out['errors'].append('certificate must be a JSON object'); return out
    version = d.get('certificate_version')
    out['certificate_version'] = version
    known = {'TMD_external_lab_preflight_gate_v0_1', 'TMD_release_acceptance_gate_v0_1',
             'TMD_multicycle_campaign_runner_v0_1'}
    if not isinstance(version, str) or version not in known:
        out['errors'].append('unsupported or missing certificate_version'); return out
    if 'all_passed' in d and d['all_passed'] is not True:
        out['errors'].append('all_passed is not true')
    if 'status' in d and d['status'] not in ('valid', 'ok'):
        out['errors'].append('certificate status is not passing')
    if version == 'TMD_multicycle_campaign_runner_v0_1':
        leaves = d.get('final_event_hashes_sorted')
        actions = d.get('cycle_completed_actions')
        count = d.get('n_cycles')
        if not _positive_int(count) or not isinstance(leaves, list) or not leaves or not all(_is_hash(x) for x in leaves):
            out['errors'].append('missing or invalid campaign cycle/hash fields')
        else:
            root, levels = _merkle(leaves)
            if len(leaves) != count or leaves != sorted(leaves) or len(set(leaves)) != len(leaves):
                out['errors'].append('campaign hash count/order/uniqueness mismatch')
            if d.get('campaign_merkle_root') != root or d.get('merkle_levels') != levels:
                out['errors'].append('campaign Merkle root/levels mismatch')
        if not isinstance(actions, list) or not all(isinstance(a, str) and a for a in actions) or len(actions) != count:
            out['errors'].append('campaign action count/type mismatch')
        elif len(set(actions)) != len(actions): out['errors'].append('duplicate campaign actions')
        if type(d.get('final_budget_after')) is not int or d['final_budget_after'] < 0:
            out['errors'].append('invalid final_budget_after')
    else:
        gates = d.get('gates')
        if d.get('all_passed') is not True: out['errors'].append('missing passing all_passed flag')
        if not isinstance(gates, list) or not gates or not all(isinstance(g, dict) for g in gates):
            out['errors'].append('missing or invalid certificate gates')
        else:
            if type(d.get('n_gates')) is not int or d['n_gates'] != len(gates) or type(d.get('n_passed')) is not int or d['n_passed'] != len(gates):
                out['errors'].append('certificate gate counts disagree')
            for gate in gates:
                if gate.get('pass') is not True or type(gate.get('returncode')) is not int or gate['returncode'] != 0:
                    out['errors'].append('certificate contains a failed/malformed gate')
                if 'summary_exists' in gate and gate['summary_exists'] is not True:
                    out['errors'].append('gate summary is missing')
                if 'n_cases' in gate and (not _positive_int(gate['n_cases']) or gate.get('n_pass') != gate['n_cases']):
                    out['errors'].append('gate case/pass counts disagree')
        if version == 'TMD_release_acceptance_gate_v0_1':
            roots = d.get('component_roots')
            if not isinstance(roots, list) or not roots or not all(_is_hash(root) for root in roots):
                out['errors'].append('missing or invalid component_roots')
            elif d.get('release_acceptance_root') != sha256_text(canonical(roots)):
                out['errors'].append('release acceptance root mismatch')
            if isinstance(gates, list) and all(isinstance(g, dict) for g in gates) and roots != [g.get('root') for g in gates]:
                out['errors'].append('gate roots disagree with component_roots')
        else:
            if not _is_hash(d.get('preflight_merkle_like_root')):
                out['errors'].append('missing or invalid preflight root')
            components = d.get('component_hashes_or_roots')
            if not isinstance(components, list) or not components or not all(_is_hash(x) for x in components):
                out['errors'].append('missing or invalid preflight components')
            # Legacy certificates omit the runner-file hash included in their root.
            out['preflight_root_recomputed'] = False
    for key in ['release_acceptance_root', 'preflight_merkle_like_root', 'campaign_merkle_root']:
        if key in d: out[key] = d[key]
    out['verification_scope'] = 'schema and internal consistency only; no independent execution or issuer authentication'
    out['status'] = 'valid' if not out['errors'] else 'invalid'
    return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('submission_dir')
    ap.add_argument('--outdir', default='intake_validation')
    args=ap.parse_args()
    root=Path(args.submission_dir)
    outdir=Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    results=[]
    for p in sorted(root.rglob('*.json')):
        name=p.name.lower()
        if 'event_sourced_replay_ledger' in name or 'replay_ledger' in name and 'certificate' not in name:
            results.append(verify_ledger(p))
        elif 'certificate' in name or 'preflight' in name or 'acceptance' in name:
            results.append(check_certificate(p))
    if not any(r.get('type') == 'ledger' for r in results):
        results.append({'file':str(root),'type':'bundle','status':'invalid','errors':['no replay ledger found'],'warnings':[]})
    if not any(r.get('type') == 'certificate' for r in results):
        results.append({'file':str(root),'type':'bundle','status':'invalid','errors':['no supported certificate found'],'warnings':[]})
    n_valid=sum(1 for r in results if r.get('status')=='valid')
    n_invalid=sum(1 for r in results if r.get('status')=='invalid')
    all_passed=(n_invalid==0 and n_valid>0)
    summary={
        'validator_version':'TMD_external_result_intake_validator_v0_2',
        'verification_scope':'internal consistency only; not authenticated provenance or empirical validation',
        'source_artifacts_verified': False,
        'submitter_identity_authenticated': False,
        'certificate_to_ledger_binding_verified': False,
        'submission_dir':str(root),
        'all_passed':all_passed,
        'n_checked':len(results),
        'n_valid':n_valid,
        'n_invalid':n_invalid,
        'results':results
    }
    (outdir/'TMD_external_result_intake_validation_summary_v0_1.json').write_text(json.dumps(summary,indent=2), encoding='utf-8')
    with open(outdir/'TMD_external_result_intake_validation_summary_v0_1.csv','w',newline='',encoding='utf-8') as f:
        fieldnames=['file','type','status','certificate_version','run_id','manifest_action','final_event_hash','errors','warnings']
        w=csv.DictWriter(f, fieldnames=fieldnames); w.writeheader()
        for r in results:
            w.writerow({k: (json.dumps(r.get(k,'')) if k in ['errors','warnings'] else r.get(k,'')) for k in fieldnames})
    print(json.dumps({'all_passed':all_passed,'n_checked':len(results),'n_valid':n_valid,'n_invalid':n_invalid}, indent=2))
    return 0 if all_passed else 2

if __name__=='__main__':
    sys.exit(main())
