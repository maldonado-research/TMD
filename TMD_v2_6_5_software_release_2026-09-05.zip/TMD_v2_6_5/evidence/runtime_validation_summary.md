# Clean runtime packaging verification — 2026-09-05

The final clean runtime contains 46 files (201,852 bytes): active launchers, workflow sources, templates/configuration and explicitly labeled historical technical notes. It excludes old generated validation runs, Python caches, Finder metadata, stale hash manifests and obsolete Zenodo metadata. No required examples or dependencies were missing.

| Interpreter on this Mac | Acceptance gates | Smoke cases | Failure controls | Root campaign |
|---|---:|---:|---:|---|
| CPython 3.9.6 | 2/2 pass | 4/4 pass | 9/9 pass | 4 cycles; budget 0 |
| CPython 3.12.14 | 2/2 pass | 4/4 pass | 9/9 pass | 4 cycles; budget 0 |

Both runs used `-S`, so scientific site packages were not initialized. The exact runtime file inventory remained unchanged across both runs. Its SHA-256 digest is `cb17808b9c8814c1ed824e583eb388b0f347aa3e5d7cae1162f720a6c89b920d` (SHA-256 of the canonical JSON file inventory, as defined in `runtime_source_inventory.json`).

Two active source modules differ from the May 14 baseline. The campaign updater uses `datetime.timezone.utc` for Python 3.9 compatibility. The campaign-aware manifest compiler now emits `recommended_action` as an explicit alias of the selected `campaign_action`, and `recommended_branch` from the mapped assay stage. The initial runtime proposal remains separately recorded as `runtime_action`. These aliases ensure that the existing feedback reducer and replay ledger record the actual selected campaign action, allowing the strict intake validator to check the action commitment. All numerical assumptions and campaign priorities remain inherited from the earlier stack.

Compact interpreter-specific evidence is in `runtime_validation_python39.json` and `runtime_validation_python312.json`; raw logs and certificates remain in `runtime_python39_acceptance_final/` and `runtime_python312_acceptance_final/`, outside the candidate. These are synthetic software tests on one Mac, not new laboratory findings or cross-platform certification. Fresh runtime-to-intake integration evidence is separately supplied by the intake review.
